======================================================================
BURP APPLICATION MAPPER — MASTER ENGINEERING SPECIFICATION
======================================================================

You are the primary coding/repository agent for this workspace:

    ~/Downloads/burp/application_mapper/

The workspace contains:

    BurpMax/
    montoya-api_examples/
    montoya-api-2026.7.jar
    mapper.kts

The objective is to build a production-quality, long-running,
provenance-rich BURP SUITE APPLICATION MAPPING / RECORDING extension.

The project is for authorized security testing.

This is NOT an automated exploitation engine.

======================================================================
0. NON-NEGOTIABLE PRINCIPLE
======================================================================

Do NOT build a second Burp.

Do NOT unnecessarily rebuild Burp functionality.

Do NOT unnecessarily rebuild BurpMax functionality.

Do NOT throw away useful information simply because multiple components
provide overlapping information.

The final system is:

    BURP PROFESSIONAL
          +
    MONTOYA API 2026.7
          +
    BURPMAX
          +
    OFFICIAL MONTOYA EXAMPLES
          +
    OUR CORRELATION / DEDUP / JSONL LAYER

                    |
                    v

        ONE CANONICAL APPLICATION DATASET

                    |
                    v

             ONE JSONL FILE / HOST

The mapper is therefore primarily:

    orchestrator
    collector
    correlator
    deduplicator
    provenance tracker
    host-frontier manager
    JSONL persistence layer
    UI

Burp and BurpMax should perform the functionality they already provide.

The mapper should integrate and correlate those capabilities instead of
reimplementing them.

======================================================================
1. WORKSPACE RULE
======================================================================

Treat the repositories as separate source/reference projects.

DO NOT flatten them into one directory.

DO NOT blindly copy every source file.

DO NOT blindly merge every example.

Treat:

    montoya-api-2026.7.jar

as the authoritative compile-time API.

Treat:

    montoya-api_examples/

as authoritative examples of actual Montoya usage.

Treat:

    BurpMax/

as an existing implementation containing reusable discovery/mapping
functionality.

Treat:

    mapper.kts

as the current mapper implementation/prototype.

Before implementation, inspect all four completely.

======================================================================
2. PHASE 0 — COMPLETE REPOSITORY AUDIT
======================================================================

BEFORE WRITING OR MODIFYING SOURCE CODE:

inspect:

    mapper.kts
    all relevant BurpMax source
    all relevant Montoya examples
    Montoya 2026.7 JAR API
    all Gradle/build configuration
    Java/Kotlin versions
    dependencies
    licensing
    existing persistence
    existing crawler/discovery logic
    existing request execution logic
    existing authentication/session logic
    existing UI
    existing tests

Build a capability inventory.

For every capability determine:

    A. Burp-native functionality
    B. Montoya API exposure
    C. BurpMax functionality
    D. Official Montoya example implementation
    E. Directly exposed
    F. Indirectly observable
    G. Extension-derived
    H. Unavailable
    I. Exact class/method/API
    J. Data available
    K. Provenance available
    L. Limitations
    M. Existing implementation that can be reused
    N. Whether it should be integrated
    O. Whether it overlaps another subsystem

DO NOT assume:

    "Burp UI feature exists"
    =
    "Montoya extension can control it."

Whenever something is unavailable, say exactly:

    NOT EXPOSED BY CURRENT MONTOYA API

Do not invent APIs.

======================================================================
3. PHASE 1 — ARCHITECTURE AUDIT ONLY
======================================================================

Do NOT implement source code yet.

Create:

    ARCHITECTURE_AUDIT.md

It must contain:

    1. Exact Montoya API version
    2. Build/dependency architecture
    3. Complete Burp capability inventory
    4. Complete Montoya capability inventory
    5. Complete BurpMax capability inventory
    6. Relevant Montoya examples
    7. Overlapping capabilities
    8. Missing capabilities
    9. Directly exposed capabilities
    10. Indirectly observable capabilities
    11. Extension-derived capabilities
    12. Unavailable capabilities
    13. Provenance capabilities
    14. Authentication/browser capabilities
    15. Crawl/discovery capabilities
    16. Content Discovery capabilities
    17. Site Map capabilities
    18. HTTP capabilities
    19. Scanner/passive capabilities
    20. Request execution capabilities
    21. WebSocket capabilities
    22. API/OpenAPI/GraphQL capabilities
    23. HTML/JS/resource extraction capabilities
    24. Technology detection capabilities
    25. BurpMax Smart Crawler capabilities
    26. BurpMax probes/discovery capabilities
    27. JSONL schema proposal
    28. Canonical identity proposal
    29. Deduplication proposal
    30. Provenance aggregation proposal
    31. Line-number aggregation proposal
    32. Dynamic subdomain frontier proposal
    33. Long-running persistence architecture
    34. Host lifecycle architecture
    35. UI architecture
    36. Build/migration plan
    37. Tests
    38. Risks
    39. Decisions requiring approval

STOP after producing the audit.

Do not modify the current implementation yet.

======================================================================
4. PRIMARY OUTPUT — JSONL
======================================================================

The PRIMARY and ONLY unauthenticated mapping output is JSONL.

For every processed hostname:

    burp_unauth/<hostname>.jsonl

Exactly one file per processed hostname.

The directory:

    burp_unauth/

must contain ONLY:

    <hostname>.jsonl

Do NOT generate inside burp_unauth/:

    CSV
    manifests
    provenance files
    JS files
    API files
    passive finding files
    metadata files
    auxiliary files

Temporary runtime state may exist elsewhere.

======================================================================
5. JSONL SEMANTICS
======================================================================

Each line is exactly ONE JSON object.

Never:

    JSON array
    one giant JSON document
    CSV

The dataset must remain readable if interrupted.

Previously completed records must remain valid.

Do not hold the complete application's dataset in memory.

Use incremental persistence.

======================================================================
6. CORE SCHEMA
======================================================================

The following CORE fields MUST exist in every canonical mapping record:

    host
    url
    scheme
    port
    method
    status
    mime_type
    content_length
    redirect_location
    redirect_chain
    parameter_names
    parameter_locations
    form_action
    form_method
    cookie_names
    content_type
    source
    discovered_from
    parent_url
    js_source
    api_source
    resource_type
    burp_tags
    passive_findings
    notes

These are the CORE fields.

======================================================================
7. IMPORTANT — EXTENDED SCHEMA IS ALLOWED
======================================================================

DO NOT artificially stop at the core fields.

The final mapper should preserve ALL genuinely useful, structured,
Burp-derived, Montoya-derived, BurpMax-derived, and mapper-derived
application mapping information that can be represented safely.

Therefore:

    CORE SCHEMA
          +
    EXTENDED VERIFIED SCHEMA

is allowed.

However:

    DO NOT INVENT DATA
    DO NOT ADD IMPLEMENTATION-DETAIL FIELDS
    DO NOT ADD FIELDS JUST FOR CONVENIENCE
    DO NOT DUPLICATE THE SAME INFORMATION UNDER MULTIPLE NAMES

Every additional field must have a documented source:

    Burp native
    Montoya
    BurpMax
    official Montoya example
    mapper-derived

The architecture audit must first determine which additional fields are
actually justified.

The final JSONL may therefore legitimately contain many more than
25–35 useful fields/sections if those fields are genuinely supported.

======================================================================
8. SCHEMA DESIGN PHILOSOPHY
======================================================================

DO NOT think:

    "How many columns do we have?"

Think:

    "What complete application evidence can we reliably preserve?"

The final schema should be machine-readable and compact.

Prefer structured objects/arrays for related metadata instead of dozens
of repetitive scalar fields.

Potential categories to investigate include:

    HTTP identity
    HTTP request metadata
    HTTP response metadata
    transport metadata
    URL metadata
    parameters
    cookies
    headers where useful
    redirects
    resource classification
    provenance
    source relationships
    crawl relationships
    browser relationships
    JS relationships
    API relationships
    WebSocket relationships
    forms
    content discovery
    Site Map evidence
    Scanner findings
    passive findings
    technology detection
    version detection
    framework detection
    authentication/session evidence
    tags/annotations
    request execution metadata
    content fingerprints
    API-definition metadata
    GraphQL metadata
    resource relationships
    dynamic discovery metadata
    source-line metadata
    subdomain relationship metadata
    BurpMax discovery metadata

Only include fields that the audited APIs actually support or that the
mapper can safely derive.

======================================================================
9. ONE CANONICAL OBSERVATION PIPELINE
======================================================================

Every source must feed ONE correlation pipeline.

Sources may include:

    Burp HTTP handler
    Site Map
    Scanner
    AuditIssueHandler
    Proxy
    Repeater
    Intruder where exposed
    Collaborator where relevant
    WebSocket handlers
    RequestExecutionEngine
    Burp crawler
    Content Discovery
    browser-generated traffic
    BurpMax Smart Crawler
    BurpMax LinkExtractor
    BurpMax JSON/XML processing
    BurpMax technology detection
    BurpMax hidden-parameter discovery
    BurpMax sensitive-resource discovery
    HTML extraction
    JS extraction
    API-definition extraction
    GraphQL extraction
    OpenAPI extraction
    redirects
    forms
    resources
    discovered subdomains

Pipeline:

    OBSERVATION
         |
         v
    NORMALIZATION
         |
         v
    CANONICAL IDENTITY
         |
         v
    CORRELATION
         |
         v
    DEDUPLICATION
         |
         v
    MERGE
         |
         v
    PROVENANCE AGGREGATION
         |
         v
    LINE/LOCATION AGGREGATION
         |
         v
    JSONL PERSISTENCE

No subsystem should maintain a competing final result store.

======================================================================
10. CANONICAL IDENTITY
======================================================================

DO NOT use URL as the sole identity.

At minimum inspect:

    host
    normalized URL
    method
    resource type

Potential additional identity dimensions may be required after the
capability audit.

Preserve meaningful distinctions.

Example:

    GET /api/users
    POST /api/users

are different canonical records.

But:

    Burp Proxy
    Site Map
    Browser
    JavaScript
    BurpMax
    Scanner

discovering the same:

    GET /api/users

should normally correlate into one canonical application record.

======================================================================
11. DEDUPLICATION REQUIREMENTS
======================================================================

Deduplication must occur AFTER normalization.

Do not prematurely throw away observations.

Do not let separate collectors silently discard information before the
canonical engine sees it.

Every observation should be allowed into the correlation engine unless it
is provably irrelevant/duplicate at the observation level.

When duplicate observations are merged:

    preserve richer data
    preserve provenance
    preserve discovery relationships
    preserve source locations
    preserve tags
    preserve findings
    preserve relevant technology evidence
    preserve API relationships
    preserve resource relationships

======================================================================
12. MULTIPLE DISCOVERY PATHS
======================================================================

The same application item may be discovered by:

    crawl
    proxy
    browser
    JavaScript
    resource
    form
    redirect
    content-discovery
    site-map
    openapi
    graphql
    passive-analysis
    BurpMax
    mapper-derived extraction

Do NOT discard discovery paths.

Because the core schema has a single:

    source

field, the architecture must define a deterministic, machine-readable
way to preserve all additional provenance without making the dataset
unnecessarily repetitive.

Do not silently decide this.

Document the representation in the architecture audit.

======================================================================
13. BURP-NATIVE VS MAPPER-DERIVED PROVENANCE
======================================================================

These are two distinct concepts.

A.

BURP-NATIVE PROVENANCE

Information explicitly exposed by Montoya.

Examples:

    ToolType.PROXY
    ToolType.SCANNER
    Site Map
    official API event

B.

MAPPER-DERIVED PROVENANCE

Information established by the extension by parsing or correlating
material already exposed by Burp/Montoya.

Example:

HTML:

    <script src="/static/app.js">

The relationship is mapper-derived.

JavaScript:

    "/api/users"

The relationship is mapper-derived.

Do NOT claim either relationship is a native Burp discovery event unless
Montoya actually exposes it as such.

======================================================================
14. PROXY IS NOT BROWSER
======================================================================

ABSOLUTE RULE:

    ToolType.PROXY == Burp Proxy.

Never infer:

    browser

from:

    ToolType.PROXY.

Browser provenance may only be recorded when the actual Montoya API
explicitly exposes browser origin.

If Burp internally uses its embedded browser but Montoya only gives:

    ToolType.SCANNER

then use the reliable scanner/crawl provenance and explicitly document:

    browser-vs-non-browser provenance unavailable.

======================================================================
15. HTTP INFORMATION
======================================================================

Capture everything the actual Montoya API exposes that is useful and
relevant to application mapping.

Investigate:

    URL
    scheme
    host
    port
    method
    status
    MIME type
    content length
    content type
    request metadata
    response metadata
    parameters
    cookies
    redirects
    request/response relationships
    tool provenance
    Site Map provenance
    Scanner provenance
    execution provenance
    resource classification

Do not invent unsupported data.

======================================================================
16. SITE MAP
======================================================================

Use native Site Map information whenever Montoya exposes it.

Investigate:

    domains
    subdomains
    directories
    files
    parameterized URLs
    requested content
    discovered content
    likely content
    resources
    links
    requests
    responses
    methods
    relationships
    issues
    Site Map metadata
    unrequested/discovered content

Preserve the difference between:

    actually requested

and:

    merely identified/discovered

where the API allows that distinction.

======================================================================
17. CRAWLING
======================================================================

Prefer Burp-native crawling/application mapping whenever available.

Do not make a competing crawler simply because it is easier.

BurpMax Smart Crawler may supplement Burp.

The final mapper must correlate both.

======================================================================
18. BURPMAX — COMPLETE INVENTORY
======================================================================

Do NOT assume BurpMax only contains a crawler.

Inspect the entire repository.

Identify every module/functionality relevant to:

    mapping
    crawling
    endpoint discovery
    resource extraction
    technology detection
    version detection
    hidden parameters
    sensitive resources
    authentication/session state
    checkpointing
    Site Map integration
    Proxy integration
    request execution
    body parsing
    JSON traversal
    XML traversal
    link extraction
    API discovery
    other passive/recon capabilities

Retain useful functionality from BurpMax.

Do not discard working functionality merely because Burp has a
different but overlapping implementation.

======================================================================
19. BURPMAX ACTIVE PROBES
======================================================================

The mapper itself is NOT an automatic exploitation engine.

Do not automatically run:

    SQL injection probes
    XSS probes
    SSRF attacks
    command injection
    IDOR attacks
    JWT exploitation
    request smuggling attacks
    race attacks
    destructive tests
    exploit payloads

However:

    if BurpMax produces mapping-relevant metadata,
    discovery evidence,
    passive observations,
    technology information,
    endpoint metadata,
    parameter metadata,
    or other legitimate mapping evidence,

that information may be retained.

======================================================================
20. MONTOYA EXAMPLES — COMPLETE INVENTORY
======================================================================

Inspect all official Montoya examples.

Determine which examples map to:

    HTTP
    Proxy
    WebSockets
    Scanner
    AuditIssueHandler
    RequestExecutionEngine
    Site Map
    persistence
    session handling
    Intruder
    Repeater
    Collaborator
    custom editors
    context menus
    settings
    AI
    traffic redirection
    custom logging
    other useful capabilities

Do NOT integrate everything blindly.

Only integrate functionality relevant to the mapping/recording objective.

AI must remain optional.

======================================================================
21. BROWSER / DYNAMIC APPLICATION MAPPING
======================================================================

Investigate whether Montoya 2026.7 can:

    start/control Burp browser mapping
    control embedded browser
    observe browser-generated requests
    distinguish browser-generated requests
    capture XHR/fetch
    capture dynamic navigation
    capture dynamically generated routes
    preserve browser provenance

If unavailable:

    NOT EXPOSED BY CURRENT MONTOYA API

Do not invent browser-control APIs.

If traffic can still be observed through HTTP handlers:

    record the traffic

but do not falsely claim browser provenance.

======================================================================
22. AUTHENTICATED MAPPING
======================================================================

The eventual mapper must support authenticated mapping wherever Burp/
Montoya allows it.

Capture traffic caused by:

    login
    session initialization
    authenticated navigation
    forms
    button actions
    XHR/fetch
    authenticated API traffic
    session changes
    dynamic resources

Where Burp can perform the function natively:

    use Burp.

Where the operator must manually perform browser interaction because
Montoya cannot control the embedded browser:

    observe/record the resulting traffic.

Do not pretend manual browser control is programmatically available.

======================================================================
23. HTML / RESOURCE DISCOVERY
======================================================================

Integrate lightweight extraction:

    HTML links
    forms
    form actions
    form methods
    scripts
    stylesheets
    images
    fonts
    manifests
    comments
    data-url
    data-href
    resource references
    dynamically loaded resources
    CSS URL references where practical

These are mapping relationships.

Not AST analysis.

======================================================================
24. JAVASCRIPT DISCOVERY
======================================================================

For every JavaScript resource that can be legitimately observed:

record the JS resource itself.

Also investigate lightweight extraction of:

    absolute URLs
    relative URLs
    routes
    fetch
    XHR
    axios
    imports
    requires
    GraphQL references
    API references
    resource URLs
    comments

Do not implement:

    AST analysis
    source-map analysis
    deep reverse engineering
    advanced deobfuscation

Those belong to later stages.

======================================================================
25. SOURCE LINE AGGREGATION
======================================================================

This requirement is CRITICAL.

If the SAME endpoint appears on multiple lines in one JS/source file:

    /api/users

    line 120
    line 184
    line 317

preserve one endpoint record with aggregated source locations.

Example concept:

    endpoint A:
        source_file = app.js
        lines = [120,184,317]

But if another endpoint exists:

    /api/admin
        line 411

DO NOT merge it with /api/users.

Different endpoint = different mapping resource.

Apply the same principle wherever source-location information exists.

======================================================================
26. API DISCOVERY
======================================================================

Investigate:

    OpenAPI
    Swagger
    GraphQL
    API definitions
    API endpoints
    API parameters
    API references in JS
    API definitions found during crawl
    API definitions returned by browser traffic

If Burp exposes native parsed API information:

    use it.

If only the definition response is observable:

    observe it.

If lightweight parsing by the mapper is necessary:

    clearly mark that provenance as mapper-derived.

Do not claim native Burp API parsing where it is not exposed.

======================================================================
27. TECHNOLOGY DETECTION
======================================================================

Integrate BurpMax and/or verified Montoya-compatible technology
detection.

Capture, where reliably available:

    technology
    technology category
    version
    framework
    library
    runtime
    server
    database hints
    CDN
    WAF
    hosting/platform hints

ONLY when there is evidence.

Do not turn guesses into facts.

Preserve evidence/source where useful.

======================================================================
28. TECHNOLOGY-SPECIFIC DISCOVERY
======================================================================

Where technically justified:

    detect technology
        |
    select technology-specific discovery candidates
        |
    exclude already known resources
        |
    perform bounded mapping/content-discovery
        |
    record observations
        |
    correlate
        |
    deduplicate
        |
    JSONL

Prefer native Burp Content Discovery where available.

Do not create a competing unrestricted wordlist scanner.

======================================================================
29. CONTENT DISCOVERY
======================================================================

Use Burp Professional native Content Discovery when Montoya exposes the
required functionality.

If BurpMax provides complementary discovery:

    integrate it.

Do NOT duplicate already known resources.

Preserve:

    discovered
    requested
    returned
    added to Site Map

where the API exposes those distinctions.

Use:

    source = content-discovery

where appropriate.

======================================================================
30. FORMS
======================================================================

Capture:

    form_action
    form_method
    parent_url
    parameters
    provenance

where exposed or derived.

======================================================================
31. REDIRECTS
======================================================================

Capture:

    redirect_location
    redirect_chain
    source
    parent_url

Do not automatically begin mapping another host merely because of a
cross-host redirect.

======================================================================
32. PARAMETERS
======================================================================

Capture all useful parameter metadata exposed by Burp/Montoya.

Investigate:

    query
    body
    path
    cookie
    headers when meaningfully represented
    multipart
    JSON
    XML
    other exposed parameter types

Preserve meaningful distinctions.

======================================================================
33. COOKIES
======================================================================

Record cookie names and other safe cookie metadata where exposed.

Never store sensitive cookie values merely because they are available.

The mapper records application structure and evidence.

======================================================================
34. PASSIVE FINDINGS
======================================================================

Do NOT assume:

    registerPassiveScanCheck()

means:

    all native Burp passive findings.

Audit exactly how native Burp findings are exposed.

Distinguish:

    own passive scanner
    native Scanner findings
    AuditIssueHandler
    Site Map issues
    other Burp findings

Record native findings when actually exposed.

Do not implement a fake replacement scanner merely for parity.

======================================================================
35. TAGS / ANNOTATIONS
======================================================================

Preserve Burp tags, annotations, classifications, and related metadata
where Montoya exposes them.

Do not invent tags.

======================================================================
36. WEBSOCKETS
======================================================================

Use official Montoya WebSocket examples where appropriate.

Record WebSocket mapping information into the SAME canonical JSONL
pipeline.

Do not build a separate WebSocket datastore.

======================================================================
37. REQUEST EXECUTION ENGINE
======================================================================

Use the actual Montoya RequestExecutionEngine where useful.

Potential uses include:

    bounded mapper-side validation
    controlled follow-up requests
    Burp-native request execution
    technology-aware discovery
    future mapping workflows

Do not introduce another HTTP execution stack unnecessarily.

Execution results must flow into the same observation/correlation layer.

======================================================================
38. REQUEST / RESPONSE PROVENANCE
======================================================================

For every meaningful observation determine:

    where it came from
    whether Burp reported the origin
    whether it was mapper-derived
    what parent produced it
    what resource produced it
    what source file produced it
    what request execution produced it
    what Burp subsystem produced it

Do not confuse correlation with native provenance.

======================================================================
39. DYNAMIC SUBDOMAIN FRONTIER
======================================================================

Input:

    subdomains.txt

These are initial seeds.

During mapping, new in-scope application hostnames may be discovered.

When a new hostname is legitimately discovered and is in Burp target
scope:

    record it
    preserve its parent/discovery relationship
    append it to the END of the FIFO frontier
    process it once

Do not duplicate work.

Do not silently include third-party infrastructure.

Maintain:

    initialHosts
    discoveredHosts
    queuedHosts
    activeHosts
    processedHosts

separately.

======================================================================
40. STRICT HOST ISOLATION
======================================================================

Every host has independent state.

Lifecycle:

    START HOST
       |
    initialize host state
       |
    map
       |
    continuously write records
       |
    finish
       |
    flush
       |
    close
       |
    release temporary state
       |
    reset
       |
    NEXT HOST

Never mix records.

Never let one broken host terminate the overall operation.

======================================================================
41. LONG-RUNNING OPERATION
======================================================================

The mapper can run for:

    hours
    days

Design for:

    bounded memory
    incremental JSONL writing
    crash-safe persistence
    incremental flushing
    pause
    resume
    cancellation
    retries
    graceful shutdown
    host isolation
    progress
    record counts
    failure recovery

Do not maintain the entire application's canonical dataset forever in
RAM.

If an internal index is required, use a scalable disk-backed or
bounded strategy.

======================================================================
42. JSONL PERSISTENCE ARCHITECTURE
======================================================================

The final per-host JSONL is the authoritative external dataset.

Requirements:

    one file / host
    valid line-oriented JSON
    incremental writes
    recoverable after interruption
    no giant JSON serialization
    no array wrapper
    safe append/replace behavior
    deterministic ordering where practical
    atomic recovery where practical

IMPORTANT:

Do not repeatedly rewrite millions of records on every small merge.

Design a scalable persistence mechanism.

The final file must remain a single JSONL file per host.

======================================================================
43. RECORD MERGING
======================================================================

The merger must be intelligent.

For each canonical record:

    preserve the richest known value
    union lists
    union provenance
    union parameters
    union tags
    union findings
    union source locations
    preserve redirect chain
    preserve API source
    preserve JS source
    preserve parent relationships
    preserve resource relationships
    preserve technology evidence

Do not overwrite useful values with null or less informative values.

======================================================================
44. MULTI-VALUED DATA
======================================================================

Where one resource can legitimately have multiple values, use arrays or
structured collections.

Examples:

    multiple discovery paths
    multiple source files
    multiple source lines
    multiple technologies
    multiple API sources
    multiple parents
    multiple observed URLs
    multiple parameter locations
    multiple findings
    multiple Burp tags

Avoid repetitive records when one canonical resource can safely contain
the combined information.

======================================================================
45. RECORD SIZE / COMPACTNESS
======================================================================

The user explicitly wants the dataset comprehensive WITHOUT useless
repetition.

Therefore:

    do not repeat identical metadata unnecessarily;
    aggregate related data into one record where semantically correct;
    keep repeated line numbers together;
    keep multiple URLs together where they refer to the same canonical
    resource;
    preserve distinct endpoints separately.

The JSONL should be compact enough for downstream AI/SAST/DAST use.

======================================================================
46. DOWNSTREAM COMPATIBILITY
======================================================================

The resulting JSONL is intended to become the primary input to later
stages such as:

    AST analysis
    SAST
    DAST
    source-map analysis
    JavaScript semantic analysis
    CodeQL
    Semgrep
    custom database enrichment
    AI-assisted security analysis

Therefore preserve as much legitimate provenance and application
structure as possible.

Do not perform downstream AST/SAST analysis inside the mapper itself.

======================================================================
47. AI
======================================================================

Keep Burp/Montoya AI capabilities available if they are exposed.

Do NOT automatically invoke AI during baseline mapping.

The mapper must produce complete output without AI.

======================================================================
48. SECURITY BOUNDARY
======================================================================

Authorized application mapping only.

Do NOT automatically implement:

    exploit generation
    active vulnerability exploitation
    destructive requests
    credential theft
    arbitrary scope expansion

The mapper can:

    crawl
    observe
    discover
    fingerprint
    correlate
    deduplicate
    record
    preserve passive/native Burp findings

======================================================================
49. FINAL JSONL CONTRACT
======================================================================

The final record architecture must support:

    CORE FIELDS
        +
    VERIFIED EXTENDED FIELDS
        +
    PROVENANCE
        +
    RELATIONSHIPS
        +
    FINDINGS
        +
    TECHNOLOGY
        +
    RESOURCE METADATA
        +
    SOURCE LOCATIONS

while keeping each application resource as a meaningful canonical
record.

The JSONL should answer:

    What is this?
    Where is it?
    What method is it?
    What parameters does it have?
    What resources relate to it?
    What technologies are associated with it?
    What API definition relates to it?
    What JS produced it?
    What page produced it?
    What browser/request produced it?
    What Burp subsystem discovered it?
    Was it requested?
    Was it merely discovered?
    What findings exist?
    What source lines contain it?
    What host/application does it belong to?
    Why does this record exist?

======================================================================
50. TESTING
======================================================================

Create tests for:

    duplicate URL
    duplicate endpoint across Burp + BurpMax
    different HTTP methods
    same endpoint multiple JS lines
    different endpoints different lines
    multiple discovery paths
    native + derived provenance
    Proxy vs browser distinction
    Site Map + HTTP duplicate
    Scanner issue + HTTP record
    Content Discovery
    OpenAPI
    GraphQL
    JavaScript-derived endpoint
    HTML-derived endpoint
    form
    redirect
    cross-host redirect
    WebSocket
    technology detection
    technology-specific discovery
    discovered subdomain
    duplicate discovered subdomain
    third-party host rejection
    host isolation
    malformed response
    huge response
    interruption
    resume
    retry
    pause
    cancellation
    final JSONL validity
    JSONL deduplication
    line aggregation
    provenance aggregation
    schema validation

======================================================================
51. IMPLEMENTATION STRATEGY
======================================================================

DO NOT perform a giant speculative rewrite.

Use this sequence AFTER approval of the architecture audit:

    Phase A
        build/Gradle normalization

    Phase B
        canonical schema + observation model

    Phase C
        canonical identity + deduplication

    Phase D
        provenance engine

    Phase E
        JSONL persistence

    Phase F
        Burp HTTP/Site Map/Scanner integration

    Phase G
        RequestExecutionEngine

    Phase H
        WebSockets

    Phase I
        BurpMax Smart Crawler and discovery

    Phase J
        HTML/JS/API extraction

    Phase K
        Content Discovery

    Phase L
        technology detection

    Phase M
        dynamic subdomain frontier

    Phase N
        authenticated/browser-observed mapping

    Phase O
        UI

    Phase P
        testing and hardening

After every major phase:

    compile
    run tests
    inspect diff
    continue

======================================================================
52. CURRENT MAPPER IS NOT ASSUMED CORRECT
======================================================================

Audit mapper.kts carefully.

Preserve its useful work.

But verify:

    compilation
    Montoya 2026.7 compatibility
    nested-class correctness
    host lifecycle
    crawl completion
    RequestExecutionEngine lifecycle
    Site Map harvest
    Scanner provenance
    canonical identity
    deduplication
    provenance aggregation
    line aggregation
    JSONL durability
    memory behavior
    dynamic host discovery

Do not treat comments in the existing mapper as proof that an API exists.

Verify against the actual 2026.7 JAR.

======================================================================
53. FIRST ACTION
======================================================================

DO NOT MODIFY SOURCE CODE.

DO NOT CREATE IMPLEMENTATION CLASSES.

DO NOT BUILD A JAR.

DO NOT START IMPLEMENTATION.

First:

    inspect all workspace components completely;
    inventory all capabilities;
    inventory all useful fields;
    inventory all overlapping functionality;
    inventory all provenance;
    design the complete canonical JSONL schema;
    design deduplication;
    design line aggregation;
    design provenance aggregation;
    design host lifecycle;
    design persistence.

Then create:

    ARCHITECTURE_AUDIT.md

The audit must include a dedicated:

    COMPLETE CANONICAL JSONL SCHEMA

section listing:

    CORE FIELDS
    EXTENDED FIELDS
    STRUCTURED NESTED OBJECTS
    ARRAYS
    PROVENANCE
    RELATIONSHIPS
    SOURCE LOCATIONS
    FINDINGS
    TECHNOLOGY DATA
    API DATA
    BROWSER DATA
    CRAWL DATA
    CONTENT DISCOVERY DATA
    WEBSOCKET DATA
    REQUEST EXECUTION DATA

For EVERY additional field identify:

    source
    exact API/class if applicable
    whether native or derived
    why it is useful
    merge behavior
    deduplication behavior

Do not invent unsupported fields.

STOP after the audit.

Wait for approval before implementation.
======================================================================
