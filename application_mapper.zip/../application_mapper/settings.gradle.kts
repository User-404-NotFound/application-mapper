rootProject.name = "application-mapper"

include("mapper-core")