package com.user404.applicationmapper

import burp.api.montoya.BurpExtension
import burp.api.montoya.MontoyaApi
import burp.api.montoya.core.ToolSource
import burp.api.montoya.core.ToolType
import burp.api.montoya.http.handler.HttpHandler
import burp.api.montoya.http.handler.HttpRequestToBeSent
import burp.api.montoya.http.handler.HttpResponseReceived
import burp.api.montoya.http.handler.RequestToBeSentAction
import burp.api.montoya.http.handler.ResponseReceivedAction
import burp.api.montoya.http.message.HttpRequestResponse
import burp.api.montoya.http.message.requests.HttpRequest
import burp.api.montoya.http.message.responses.HttpResponse
import burp.api.montoya.http.execution.RequestEngineOptions
import burp.api.montoya.http.execution.RequestExecution
import burp.api.montoya.http.execution.RequestExecutionEngine
import burp.api.montoya.http.execution.RequestResult
import burp.api.montoya.http.execution.RequestStatus
import burp.api.montoya.http.execution.ResourcePool
import burp.api.montoya.http.execution.Retention
import burp.api.montoya.scanner.Crawl
import burp.api.montoya.scanner.CrawlConfiguration
import burp.api.montoya.scanner.Scanner
import burp.api.montoya.scanner.audit.AuditIssueHandler
import burp.api.montoya.scanner.audit.issues.AuditIssue
import burp.api.montoya.scope.Scope
import burp.api.montoya.sitemap.SiteMap
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.BufferedWriter
import java.io.Closeable
import java.io.IOException
import java.net.URI
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardOpenOption
import java.time.Duration
import java.time.Instant
import java.util.ArrayDeque
import java.util.Collections
import java.util.LinkedHashMap
import java.util.LinkedHashSet
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Application Mapper
 *
 * Foundation block:
 *  - Burp extension entry point
 *  - host lifecycle
 *  - strict scope isolation
 *  - durable per-host JSONL writer
 *  - native Burp tool provenance
 *  - HTTP observation
 *  - compact record construction
 *
 * Higher-level modules are added in later blocks:
 *  - native crawl orchestration
 *  - authenticated mapping
 *  - RequestExecutionEngine
 *  - Site Map
 *  - Scanner / AuditIssueHandler
 *  - Content Discovery
 *  - browser/dynamic mapping
 *  - HTML/JS/API relationship extraction
 *  - technology detection
 *  - WebSocket mapping
 */
class ApplicationMapperExtension : BurpExtension {

    private lateinit var api: MontoyaApi
    private lateinit var core: MapperCore

    override fun initialize(api: MontoyaApi) {
        this.api = api

        api.extension().setName("Application Mapper")

        core = MapperCore(api)

        runCatching {
            api.scanner().registerAuditIssueHandler(core)
        }.onFailure { error ->
            api.logging().logToError(
                "[Application Mapper] Scanner AuditIssueHandler registration " +
                    "failed: ${error.message}"
            )
        }

        /*
         * HTTP observation is the central recorder.
         *
         * Important:
         * ToolType.PROXY == Burp Proxy.
         * It is NEVER translated to browser provenance.
         */
        api.http().registerHttpHandler(core)

        api.logging().logToOutput(
            "[Application Mapper] initialized with Montoya API."
        )
    }


    /**
     * One application mapper core.
     *
     * All host-specific state is isolated below this object.
     */
    class MapperCore(
        private val api: MontoyaApi
    ) : HttpHandler, AuditIssueHandler {

        private val gson: Gson = GsonBuilder()
            .disableHtmlEscaping()
            .create()

        /*
         * Default output location.
         *
         * The UI block will later allow the operator to change this.
         */
        @Volatile
        private var outputRoot: Path =
            Path.of(System.getProperty("user.home"), ".burp_app_mapper")

        /*
         * Only hosts explicitly started by the mapper are active.
         *
         * Traffic from any other host is ignored.
         */
        private val activeHosts =
            CopyOnWriteArraySet<String>()

        /*
         * Each hostname owns exactly one runtime state object.
         */
        private val hostStates =
            ConcurrentHashMap<String, HostState>()

        /*
         * ================================================================
         * DYNAMIC APPLICATION SUBDOMAIN FRONTIER
         * ================================================================
         */
        private val initialHosts =
            CopyOnWriteArraySet<String>()

        private val discoveredHosts =
            CopyOnWriteArraySet<String>()

        private val queuedHosts =
            CopyOnWriteArraySet<String>()

        private val processedHosts =
            CopyOnWriteArraySet<String>()

        private val hostQueue =
            ArrayDeque<String>()

        private val hostQueueLock =
            Any()

        /*
         * ================================================================
         * BLOCK 3 — NATIVE BURP MAPPING STATE
         * ================================================================
         */

        private val scanner: Scanner? =
            runCatching {
                api.scanner()
            }.getOrNull()

        private val siteMap: SiteMap =
            api.siteMap()

        /*
         * One native Burp crawl task per active host.
         */
        private val crawlTasks =
            ConcurrentHashMap<String, Crawl>()

        /*
         * Prevent repeatedly harvesting the same Site Map item from
         * multiple mapping events.
         */
        private val harvestedSiteMapKeys =
            ConcurrentHashMap.newKeySet<String>()

        /*
         * Tracks URLs already associated with an AuditIssue so that the
         * same issue is not repeatedly appended.
         */
        private val harvestedIssueKeys =
            ConcurrentHashMap.newKeySet<String>()

        /*
         * ================================================================
         * BLOCK 4 — BURP TARGET SCOPE
         * ================================================================
         *
         * Burp's configured target scope is authoritative.
         *
         * We do not use a homemade "last two DNS labels" rule as the
         * final security boundary.
         */
        private val burpScope: Scope =
            api.scope()

        /*
         * ================================================================
         * BLOCK 5 — REQUEST EXECUTION ENGINE
         * ================================================================
         *
         * This is Burp's native managed request execution engine.
         *
         * It is NOT a replacement HTTP client.
         *
         * It is used for controlled mapper-side request execution such as:
         *
         * - validating discovered application resources;
         * - controlled follow-up requests;
         * - later technology-aware discovery;
         * - bounded recon workflows;
         * - future mapper expansion without introducing another HTTP stack.
         *
         * One engine instance is single-use, so each execution batch gets
         * its own engine.
         */

        private val requestExecutions =
            ConcurrentHashMap<String, RequestExecution>()

        private val requestEngines =
            ConcurrentHashMap<String, RequestExecutionEngine>()


        /**
         * Change the output root.
         *
         * Existing writers are closed safely before switching.
         */
        @Synchronized
        fun setOutputDirectory(path: String) {
            val normalized = Path.of(path).toAbsolutePath().normalize()

            if (normalized == outputRoot) {
                return
            }

            hostStates.values.forEach { state ->
                runCatching { state.close() }
            }

            hostStates.clear()
            activeHosts.clear()

            outputRoot = normalized
        }

        /**
         * Add an initial hostname from subdomains.txt to the mapper queue.
         *
         * The same hostname is accepted only once.
         */
        fun startHost(hostInput: String) {
            val host = normalizeHostname(hostInput) ?: return

            if (!initialHosts.add(host)) {
                api.logging().logToOutput(
                    "[Application Mapper] DUPLICATE INITIAL HOST: $host"
                )
                return
            }

            enqueueHostOnce(host)

            api.logging().logToOutput(
                "[Application Mapper] INITIAL HOST QUEUED: $host"
            )
        }

        /**
         * Add a hostname to the END of the FIFO queue exactly once.
         *
         * IMPORTANT:
         * Queuing a host does NOT activate it.
         *
         * A host becomes active only when beginHost() is called by the
         * mapping worker.
         */
        fun enqueueHostOnce(
            hostInput: String
        ) {
            val host = normalizeHostname(hostInput) ?: return

            synchronized(hostQueueLock) {
                if (queuedHosts.contains(host)) {
                    return
                }

                if (processedHosts.contains(host)) {
                    return
                }

                if (activeHosts.contains(host)) {
                    return
                }

                queuedHosts.add(host)
                discoveredHosts.add(host)

                /*
                 * FIFO:
                 * newly discovered hosts go to the BACK.
                 */
                hostQueue.addLast(host)
            }

            api.logging().logToOutput(
                "[Application Mapper] QUEUED: $host"
            )
        }

        /**
         * Begin mapping a host.
         */
        fun beginHost(
            hostInput: String
        ): Boolean {
            val host = normalizeHostname(hostInput) ?: return false

            synchronized(hostQueueLock) {
                if (processedHosts.contains(host)) {
                    return false
                }

                if (!activeHosts.add(host)) {
                    return false
                }

                queuedHosts.remove(host)
            }

            hostStates.computeIfAbsent(host) {
                HostState(
                    host = host,
                    outputRoot = outputRoot,
                    gson = gson
                )
            }

            api.logging().logToOutput(
                "[Application Mapper] START HOST: $host"
            )

            return true
        }

        /**
         * Finish one host, flush its JSONL, and make it impossible to
         * process the same hostname again during this run.
         */
        fun finishHost(
            hostInput: String
        ) {
            val host = normalizeHostname(hostInput) ?: return

            activeHosts.remove(host)
            queuedHosts.remove(host)
            processedHosts.add(host)

            hostStates.remove(host)?.let { state ->
                runCatching {
                    state.close()
                }.onFailure { error ->
                    api.logging().logToError(
                        "[Application Mapper] Failed closing host=$host: " +
                            "${error.message}"
                    )
                }
            }

            api.logging().logToOutput(
                "[Application Mapper] FINISHED HOST: $host"
            )
        }

        fun queuedHostCount(): Int {
            synchronized(hostQueueLock) {
                return hostQueue.size
            }
        }

        fun processedHostCount(): Int {
            return processedHosts.size
        }

        fun discoveredHostCount(): Int {
            return discoveredHosts.size
        }

        fun knownHosts(): List<String> {
            return discoveredHosts
                .toList()
                .sorted()
        }

        /**
         * Discover a new subdomain and queue it if eligible.
         */
        fun discoverSubdomain(
            applicationHostInput: String,
            discoveredHostInput: String,
            source: String?,
            discoveredFrom: String?
        ) {
            val applicationHost = normalizeHostname(applicationHostInput) ?: return
            val discoveredHost = normalizeHostname(discoveredHostInput) ?: return

            if (discoveredHost.isBlank()) {
                return
            }

            if (!discoveredHosts.contains(applicationHost) &&
                !initialHosts.contains(applicationHost)
            ) {
                return
            }

            if (!isEligibleApplicationSubdomain(applicationHost, discoveredHost)) {
                api.logging().logToOutput(
                    "[Application Mapper] THIRD-PARTY / OUT-OF-SCOPE " +
                        "IGNORED: $discoveredHost " +
                        "from=$applicationHost"
                )
                return
            }

            val isNew = discoveredHosts.add(discoveredHost)

            if (!isNew) {
                api.logging().logToOutput(
                    "[Application Mapper] KNOWN SUBDOMAIN: " +
                        "$discoveredHost"
                )
                return
            }

            enqueueHostOnce(discoveredHost)

            api.logging().logToOutput(
                "[Application Mapper] NEW SUBDOMAIN DISCOVERED: " +
                    "$discoveredHost " +
                    "source=${source ?: "unknown"} " +
                    "from=${discoveredFrom ?: "unknown"}"
            )
        }

        /**
         * Determine whether a discovered hostname may become a new
         * application mapping seed.
         *
         * Burp target scope is authoritative.
         *
         * A hostname does NOT become a seed merely because it shares the
         * same parent domain.
         */
        private fun isEligibleApplicationSubdomain(
            applicationHostInput: String,
            discoveredHostInput: String
        ): Boolean {

            val applicationHost =
                normalizeHostname(applicationHostInput)
                    ?: return false

            val discoveredHost =
                normalizeHostname(discoveredHostInput)
                    ?: return false

            /*
             * The source application itself must already belong to the
             * mapper's active discovery frontier.
             */
            if (!initialHosts.contains(applicationHost) &&
                !discoveredHosts.contains(applicationHost)
            ) {
                return false
            }

            /*
             * Build a stable URL for Burp scope evaluation.
             *
             * The discovered hostname itself is what we are testing.
             */
            val httpsUrl =
                "https://$discoveredHost/"

            val httpUrl =
                "http://$discoveredHost/"

            /*
             * Either protocol being in scope is sufficient.
             *
             * Burp scope remains authoritative.
             */
            if (isBurpInScope(httpsUrl)) {
                return true
            }

            if (isBurpInScope(httpUrl)) {
                return true
            }

            /*
             * The host is not in Burp's configured target scope.
             */
            return false
        }

        /**
         * Check whether Burp considers a URL to be in target scope.
         *
         * This is the authoritative scope decision for the mapper.
         */
        private fun isBurpInScope(
            url: String
        ): Boolean {

            return runCatching {
                burpScope.isInScope(url)
            }.onFailure { error ->

                api.logging().logToError(
                    "[Application Mapper] Burp scope check failed: " +
                        "${error.message}"
                )
            }.getOrDefault(false)
        }

        /**
         * Stop every active host.
         */
        fun stopAll() {
            activeHosts.toList().forEach { finishHost(it) }
        }

        /**
         * Returns whether a hostname is currently mapped.
         */
        fun isHostActive(hostInput: String): Boolean {
            val host = normalizeHostname(hostInput) ?: return false
            return activeHosts.contains(host)
        }

        override fun handleHttpRequestToBeSent(
            requestToBeSent: HttpRequestToBeSent
        ): RequestToBeSentAction {
            return RequestToBeSentAction.continueWith(requestToBeSent)
        }

        override fun handleHttpResponseReceived(
            responseReceived: HttpResponseReceived
        ): ResponseReceivedAction {

            runCatching {
                processObservedResponse(responseReceived)
            }.onFailure { error ->
                api.logging().logToError(
                    "[Application Mapper] HTTP processing failure: ${error.message}"
                )
            }

            return ResponseReceivedAction.continueWith(responseReceived)
        }

        private fun processObservedResponse(
            responseReceived: HttpResponseReceived
        ) {


            val request =
                responseReceived.initiatingRequest()


            val response =
                responseReceived


            val parsed =
                parseRequestUri(request.url())
                    ?: return


            val observedHost =
                normalizeHostname(parsed.host)
                    ?: return


            val state =
                hostStates[observedHost]
                    ?: return


            if (!activeHosts.contains(observedHost)) {
                return
            }


            val toolSource =
                responseReceived.toolSource()


            val record =
                buildHttpRecord(
                    host = observedHost,
                    request = request,
                    response = response,
                    toolSource = toolSource
                )


            state.upsert(record)
        }

        private fun buildHttpRecord(
            host: String,
            request: HttpRequest,
            response: HttpResponse,
            toolSource: ToolSource
        ): MutableMap<String, Any?> {

            val uri = parseRequestUri(request.url())
            val record = linkedMapOf<String, Any?>()

            record["host"] = host
            record["url"] = request.url()
            record["scheme"] = uri?.scheme
            record["port"] = effectivePort(uri)
            record["method"] = request.method()
            record["status"] = response.statusCode().takeIf { it > 0 }

            val contentTypeHeader =
                response.header("Content-Type")?.value()

            record["mime_type"] = normalizeMimeType(contentTypeHeader)
            record["content_length"] =
                response.header("Content-Length")?.value()?.toLongOrNull()
            record["content_type"] = contentTypeHeader

            record["redirect_location"] =
                response.header("Location")?.value()
            record["redirect_chain"] = emptyList<String>()

            val parameters = request.parameters()
            val parameterNames = LinkedHashSet<String>()
            val parameterLocations = LinkedHashMap<String, MutableSet<String>>()

            parameters.forEach { parameter ->
                val name = parameter.name()
                if (name.isBlank()) return@forEach
                parameterNames.add(name)
                val location = parameter.type().name.lowercase(Locale.ROOT)
                parameterLocations.getOrPut(name) { LinkedHashSet() }.add(location)
            }

            record["parameter_names"] = parameterNames.toList()
            record["parameter_locations"] = parameterLocations.mapValues { (_, values) -> values.toList() }

            record["form_action"] = null
            record["form_method"] = null

            record["cookie_names"] = collectCookieNames(request, response)

            val nativeToolType = toolSource.toolType()
            record["source"] = sourceForNativeTool(nativeToolType)
            record["discovered_from"] = null
            record["parent_url"] = null
            record["js_source"] = null
            record["api_source"] = null

            record["burp_tool"] = nativeToolType.name.lowercase(Locale.ROOT)
            record["provenance_origin"] = "burp-native"
            record["resource_type"] = classifyHttpResource(contentTypeHeader)
            record["burp_tags"] = emptyList<String>()
            record["passive_findings"] = emptyList<Any>()
            record["notes"] = null

            return record
        }

        private fun sourceForNativeTool(toolType: ToolType): String? {
            return when (toolType) {
                ToolType.PROXY -> "proxy"
                ToolType.SCANNER -> null
                ToolType.REPEATER -> null
                ToolType.EXTENSIONS -> null
                else -> null
            }
        }

        private fun classifyHttpResource(contentType: String?): String {
            val type =
                contentType
                    ?.lowercase(Locale.ROOT)
                    ?.substringBefore(';')
                    ?.trim()
                    ?: return "http"

            return when {
                type.contains("javascript") -> "javascript"
                type == "text/html" || type == "application/xhtml+xml" -> "html"
                type.contains("json") -> "json"
                type.contains("graphql") -> "graphql"
                type.contains("xml") -> "xml"
                type.contains("css") -> "stylesheet"
                type.startsWith("image/") -> "image"
                type.startsWith("font/") -> "font"
                else -> "http"
            }
        }

        private fun normalizeMimeType(contentType: String?): String? {
            return contentType
                ?.substringBefore(';')
                ?.trim()
                ?.takeIf { it.isNotBlank() }
        }

        private fun collectRequestCookieNames(
            request: HttpRequest
        ): List<String> {
            val names = LinkedHashSet<String>()

            request.headers()
                .filter { it.name().equals("Cookie", ignoreCase = true) }
                .forEach { header ->
                    header.value()
                        .split(';')
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }
                        .forEach { pair ->
                            val name = pair.substringBefore('=').trim()
                            if (name.isNotEmpty()) {
                                names.add(name)
                            }
                        }
                }
            return names.toList()
        }

        private fun collectCookieNames(
            request: HttpRequest,
            response: HttpResponse
        ): List<String> {
            val names = LinkedHashSet<String>()
            names.addAll(collectRequestCookieNames(request))

            response.cookies().forEach { cookie ->
                val name = cookie.name()
                if (name.isNotBlank()) {
                    names.add(name)
                }
            }
            return names.toList()
        }

        private fun effectivePort(uri: ParsedUri?): Int? {
            if (uri == null) return null
            if (uri.port > 0) return uri.port
            return when (uri.scheme.lowercase(Locale.ROOT)) {
                "https", "wss" -> 443
                "http", "ws" -> 80
                else -> null
            }
        }

        private fun parseRequestUri(url: String?): ParsedUri? {
            if (url.isNullOrBlank()) return null

            return runCatching {
                val uri = URI(url)
                val host = uri.host ?: return@runCatching null
                val scheme = uri.scheme ?: return@runCatching null
                ParsedUri(scheme = scheme, host = host, port = uri.port)
            }.getOrNull()
        }

        private fun normalizeHostname(input: String?): String? {
            if (input.isNullOrBlank()) return null

            var host = input.trim().lowercase(Locale.ROOT)
            host = host.removePrefix("https://").removePrefix("http://")
            host = host.substringBefore('/')

            if (host.count { it == ':' } == 1) {
                host = host.substringBefore(':')
            }

            host = host.trim('.')

            return host.takeIf { it.isNotBlank() && !it.contains(' ') }
        }

        /*
         * ================================================================
         * BLOCK 3 — NATIVE BURP MAPPING IMPLEMENTATION
         * ================================================================
         */

        /**
         * Start Burp's native Scanner crawl for one admitted host.
         */
        fun startNativeCrawl(
            hostInput: String
        ): Crawl? {
            val host = normalizeHostname(hostInput) ?: return null

            if (!activeHosts.contains(host)) {
                api.logging().logToOutput(
                    "[Application Mapper] Cannot start crawl; " +
                        "host is not active: $host"
                )
                return null
            }

            val existing = crawlTasks[host]
            if (existing != null) {
                return existing
            }

            val seedUrl = "https://$host/"

            val configuration =
                CrawlConfiguration.crawlConfiguration(seedUrl)

            val scannerInstance = scanner ?: run {
                api.logging().logToError(
                    "[Application Mapper] Burp Scanner API " +
                        "is unavailable."
                )
                return null
            }

            val crawl = runCatching {
                scannerInstance.startCrawl(configuration)
            }.onFailure { error ->
                api.logging().logToError(
                    "[Application Mapper] Failed to start native crawl " +
                        "for $host: ${error.message}"
                )
            }.getOrNull() ?: return null

            crawlTasks[host] = crawl

            api.logging().logToOutput(
                "[Application Mapper] NATIVE CRAWL STARTED: " +
                    "host=$host seed=$seedUrl"
            )

            /*
             * Initial snapshot only.
             *
             * The crawl-completion lifecycle will perform the final
             * Site Map harvest.
             */
            harvestSiteMapForHost(host)

            return crawl
        }

        /**
         * Return native Burp crawl statistics for a host.
         */
        fun nativeCrawlStats(
            hostInput: String
        ): Map<String, Any?> {
            val host = normalizeHostname(hostInput) ?: return emptyMap()
            val crawl = crawlTasks[host] ?: return emptyMap()

            return linkedMapOf(
                "requests" to crawl.requestCount(),
                "errors" to crawl.errorCount(),
                "status_message" to runCatching {
                    crawl.statusMessage()
                }.getOrNull()
            )
        }

        /**
         * Harvest native Site Map items for one host.
         */
        fun harvestSiteMapForHost(
            hostInput: String
        ) {
            val host = normalizeHostname(hostInput) ?: return
            val state = hostStates[host] ?: return

            val items = runCatching {
                siteMap.requestResponses()
            }.onFailure { error ->
                api.logging().logToError(
                    "[Application Mapper] Site Map harvest failed: ${error.message}"
                )
            }.getOrNull() ?: return

            var added = 0

            items.forEach { item ->
                val request = item.request()
                val itemHost = parseRequestUri(request.url())?.host?.let(::normalizeHostname) ?: return@forEach

                if (itemHost != host) {
                    return@forEach
                }

                val key = siteMapIdentity(request.url(), request.method())

                if (!harvestedSiteMapKeys.add(key)) {
                    return@forEach
                }

                val response = item.response()
                val toolSource = request.toolSource()

                val record = buildSiteMapRecord(
                    host = host,
                    request = request,
                    response = response,
                    nativeToolSource = toolSource
                )

                state.upsert(record)
                added++
            }

            api.logging().logToOutput(
                "[Application Mapper] SITE MAP HARVEST: " +
                    "host=$host added=$added"
            )

            harvestSiteMapIssuesForHost(host)
        }

        /**
         * Deterministic Site Map identity.
         */
        private fun siteMapIdentity(
            url: String,
            method: String
        ): String {
            return method.uppercase(Locale.ROOT) + "|" + url
        }

        /**
         * Build a record representing a Site Map item.
         */
        private fun buildSiteMapRecord(
            host: String,
            request: HttpRequest,
            response: HttpResponse?,
            nativeToolSource: ToolSource
        ): MutableMap<String, Any?> {
            val uri = parseRequestUri(request.url())
            val record = linkedMapOf<String, Any?>()

            record["host"] = host
            record["url"] = request.url()
            record["scheme"] = uri?.scheme
            record["port"] = effectivePort(uri)
            record["method"] = request.method()
            record["status"] = response?.statusCode()?.takeIf { it > 0 }

            val contentTypeHeader = response?.header("Content-Type")?.value()
            record["mime_type"] = normalizeMimeType(contentTypeHeader)
            record["content_length"] = response?.header("Content-Length")?.value()?.toLongOrNull()
            record["redirect_location"] = response?.header("Location")?.value()
            record["redirect_chain"] = emptyList<String>()

            val parameters = request.parameters()
            val names = LinkedHashSet<String>()
            val locations = LinkedHashMap<String, MutableSet<String>>()

            parameters.forEach { parameter ->
                val name = parameter.name()
                if (name.isBlank()) return@forEach
                names.add(name)
                locations.getOrPut(name) { LinkedHashSet() }.add(parameter.type().name.lowercase(Locale.ROOT))
            }

            record["parameter_names"] = names.toList()
            record["parameter_locations"] = locations.mapValues { (_, values) -> values.toList() }

            record["form_action"] = null
            record["form_method"] = null

            record["cookie_names"] = if (response != null) {
                collectCookieNames(request = request, response = response)
            } else {
                collectRequestCookieNames(request)
            }

            record["content_type"] = contentTypeHeader

            /*
             * Site Map itself is a Burp-native mapping source.
             */
            record["source"] = "site-map"
            record["discovered_from"] = null
            record["parent_url"] = null
            record["js_source"] = null
            record["api_source"] = null
            record["resource_type"] = classifyHttpResource(contentTypeHeader)
            record["burp_tags"] = emptyList<String>()
            record["passive_findings"] = emptyList<Any>()
            record["notes"] = null

            return record
        }

        /**
         * Harvest native Site Map issues for one host.
         */
        fun harvestSiteMapIssuesForHost(
            hostInput: String
        ) {
            val host = normalizeHostname(hostInput) ?: return
            val state = hostStates[host] ?: return

            val issues = runCatching {
                siteMap.issues()
            }.onFailure { error ->
                api.logging().logToError(
                    "[Application Mapper] Site Map issue read failed: " +
                        "${error.message}"
                )
            }.getOrNull() ?: return

            issues.forEach { issue ->
                val baseUrl = issue.baseUrl()
                val issueHost = parseRequestUri(baseUrl)?.host?.let(::normalizeHostname) ?: return@forEach

                if (issueHost != host) {
                    return@forEach
                }

                recordAuditIssue(
                    state = state,
                    issue = issue,
                    source = "passive-analysis"
                )
            }
        }

        /**
         * Native Burp Scanner AuditIssueHandler callback.
         */
        override fun handleNewAuditIssue(
            auditIssue: AuditIssue
        ) {
            val baseUrl = auditIssue.baseUrl()
            val issueHost = parseRequestUri(baseUrl)?.host?.let(::normalizeHostname) ?: return

            val state = hostStates[issueHost] ?: return

            if (!activeHosts.contains(issueHost)) {
                return
            }

            recordAuditIssue(
                state = state,
                issue = auditIssue,
                source = "passive-analysis"
            )
        }

        /**
         * Serialize an AuditIssue to JSONL.
         */
        private fun recordAuditIssue(
            state: HostState,
            issue: AuditIssue,
            source: String
        ) {
            val baseUrl = issue.baseUrl()
            val uri = parseRequestUri(baseUrl)

            val key = baseUrl + "|" + issue.name()
            if (!harvestedIssueKeys.add(key)) return

            val finding = linkedMapOf<String, Any?>()
            finding["name"] = issue.name()
            finding["severity"] = issue.severity().name.lowercase(Locale.ROOT)
            finding["confidence"] = issue.confidence().name.lowercase(Locale.ROOT)
            finding["detail"] = issue.detail()
            finding["remediation"] = issue.remediation()
            finding["source"] = source
            finding["base_url"] = baseUrl
            finding["burp_tool"] = "scanner"
            finding["burp_issue"] = true

            val record = linkedMapOf<String, Any?>()
            record["host"] = state.host
            record["url"] = baseUrl
            record["scheme"] = uri?.scheme
            record["port"] = effectivePort(uri)
            record["method"] = null
            record["status"] = null
            record["mime_type"] = null
            record["content_length"] = null
            record["redirect_location"] = null
            record["redirect_chain"] = emptyList<String>()
            record["parameter_names"] = emptyList<String>()
            record["parameter_locations"] = emptyMap<String, Any>()
            record["form_action"] = null
            record["form_method"] = null
            record["cookie_names"] = emptyList<String>()
            record["content_type"] = null
            record["source"] = source
            record["discovered_from"] = null
            record["parent_url"] = null
            record["js_source"] = null
            record["api_source"] = null
            record["resource_type"] = "audit-issue"
            record["burp_tags"] = emptyList<String>()
            record["passive_findings"] = listOf(finding)
            record["notes"] = null

            state.upsert(record)
        }

        /*
         * ================================================================
         * QUEUE WORKER INTEGRATION
         * ================================================================
         */

        /**
         * Start the next queued host.
         *
         * The native Burp crawl runs asynchronously.
         *
         * The host is NOT marked finished here.
         */
        fun processNextQueuedHost(): Boolean {
            val host = nextHost() ?: return false

            if (!beginHost(host)) {
                return false
            }

            val crawl = startNativeCrawl(host)

            if (crawl == null) {
                finishHost(host)
                return false
            }

            return true
        }

        /**
         * Return the current crawl task for a host.
         */
        fun currentCrawl(
            hostInput: String
        ): Crawl? {
            val host = normalizeHostname(hostInput) ?: return null
            return crawlTasks[host]
        }

        /**
         * Check whether the native crawl has completed.
         *
         * Montoya 2026.7 does not expose an isRunning() method on Crawl.
         * Therefore completion is handled by polling the task message/state
         * only through APIs that actually exist, and the final host close
         * will later be driven by the native task lifecycle integration.
         *
         * For now this method performs a final harvest only when the caller
         * explicitly declares the crawl complete.
         */
        fun finalizeCompletedCrawl(
            hostInput: String
        ): Boolean {

            val host =
                normalizeHostname(hostInput)
                    ?: return false

            val crawl =
                crawlTasks[host]
                    ?: return false

            /*
             * We do NOT invent an isRunning() API.
             *
             * Until the worker layer is added, this method is an explicit
             * finalization hook rather than an automatic state detector.
             */
            harvestSiteMapForHost(host)
            harvestSiteMapIssuesForHost(host)

            api.logging().logToOutput(
                "[Application Mapper] FINAL CRAWL HARVEST: " +
                    "host=$host " +
                    "requests=${crawl.requestCount()} " +
                    "errors=${crawl.errorCount()}"
            )

            crawlTasks.remove(host)

            finishHost(host)

            return true
        }

        private fun nextHost(): String? {
            synchronized(hostQueueLock) {
                return if (hostQueue.isEmpty()) null else hostQueue.pollFirst()
            }
        }

        /*
         * ================================================================
         * BLOCK 5 — REQUEST EXECUTION ENGINE IMPLEMENTATION
         * ================================================================
         */

        /**
         * Verify that the CURRENT Burp runtime actually exposes and can
         * initialize the Montoya 2026.7 RequestExecutionEngine.
         *
         * Compile-time availability alone is not sufficient because the
         * extension is compiled against Montoya 2026.7 while the currently
         * installed Burp runtime may expose an older implementation.
         */
        fun isRequestExecutionEngineAvailable(): Boolean {

            return try {

                api.http().createRequestEngine()

                api.logging().logToOutput(
                    "[Application Mapper] RequestExecutionEngine AVAILABLE"
                )

                true

            } catch (error: NoSuchMethodError) {

                api.logging().logToError(
                    "[Application Mapper] RequestExecutionEngine is NOT " +
                        "available in the current Burp runtime. " +
                        "A Montoya 2026.7-compatible Burp runtime is required."
                )

                false

            } catch (error: UnsupportedOperationException) {

                api.logging().logToError(
                    "[Application Mapper] RequestExecutionEngine is not " +
                        "supported by the current Burp runtime: " +
                        "${error.message}"
                )

                false

            } catch (error: RuntimeException) {

                api.logging().logToError(
                    "[Application Mapper] RequestExecutionEngine exists in " +
                        "the API but failed to initialize in the current " +
                        "runtime: ${error.message}"
                )

                false
            }
        }

        /**
         * Create a native Burp RequestExecutionEngine for one application
         * scope.
         *
         * The ResourcePool is private to this mapper run so our settings do
         * not silently change Burp's global/default execution pool.
         */
        private fun createMapperRequestEngine(
            host: String,
            concurrency: Int,
            throttleMillis: Long,
            maxRetries: Int
        ): RequestExecutionEngine? {

            if (concurrency !in 1..999) {
                throw IllegalArgumentException(
                    "concurrency must be between 1 and 999"
                )
            }

            if (throttleMillis < 0L) {
                throw IllegalArgumentException(
                    "throttleMillis cannot be negative"
                )
            }

            if (maxRetries < 0) {
                throw IllegalArgumentException(
                    "maxRetries cannot be negative"
                )
            }

            if (!isRequestExecutionEngineAvailable()) {
                return null
            }

            val resourcePool =
                ResourcePool.resourcePool()
                    .withConcurrentRequestLimit(concurrency)
                    .withMaxRetries(maxRetries)
                    .withThrottle(
                        Duration.ofMillis(throttleMillis)
                    )

            val options =
                RequestEngineOptions
                    .requestEngineOptions()
                    .withName(
                        "Application Mapper - $host"
                    )
                    .withResourcePool(resourcePool)

            return try {

                api.http().createRequestEngine(options)

            } catch (error: NoSuchMethodError) {

                api.logging().logToError(
                    "[Application Mapper] Current Burp runtime does not " +
                        "provide RequestExecutionEngine(RequestEngineOptions)."
                )

                null

            } catch (error: RuntimeException) {

                api.logging().logToError(
                    "[Application Mapper] Failed to create " +
                        "RequestExecutionEngine for $host: " +
                        "${error.message}"
                )

                null
            }
        }

        /**
         * Queue one request into a native Burp RequestExecutionEngine.
         *
         * Scope rule:
         *
         * request host MUST already be an admitted mapper host.
         *
         * Third-party requests are rejected before entering the engine.
         */
        fun queueMapperRequest(
            hostInput: String,
            request: HttpRequest,
            label: String = ""
        ): Boolean {

            val host =
                normalizeHostname(hostInput)
                    ?: return false

            if (!isHostActive(host)) {
                api.logging().logToOutput(
                    "[Application Mapper] REQUEST REJECTED: " +
                        "host is not active: $host"
                )

                return false
            }

            val requestHost =
                parseRequestUri(request.url())
                    ?.host
                    ?.let(::normalizeHostname)
                    ?: return false

            /*
             * The request must belong to the admitted application scope.
             */
            val requestScopeUrl =
                "https://$requestHost/"

            if (!isBurpInScope(requestScopeUrl)) {

                api.logging().logToOutput(
                    "[Application Mapper] THIRD-PARTY REQUEST REJECTED: " +
                        "${request.url()}"
                )

                return false
            }

            /*
             * Create a per-host engine if one does not already exist.
             *
             * Default mapper settings are deliberately conservative.
             */
            val engine =
                requestEngines.computeIfAbsent(host) {

                    createMapperRequestEngine(
                        host = host,
                        concurrency = 10,
                        throttleMillis = 0L,
                        maxRetries = 1
                    )
                        ?: return@computeIfAbsent null
                }

            if (engine == null) {
                return false
            }

            runCatching {

                engine.queue(
                    request,
                    label
                )

            }.onFailure { error ->

                api.logging().logToError(
                    "[Application Mapper] Failed to queue request: " +
                        "${error.message}"
                )

            }.getOrElse {
                return false
            }

            api.logging().logToOutput(
                "[Application Mapper] REQUEST QUEUED: " +
                    "host=$host label=$label url=${request.url()}"
            )

            return true
        }

        /**
         * Start the currently queued requests for one host.
         *
         * RequestExecutionEngine.sendAll() runs asynchronously and returns
         * immediately with a RequestExecution handle.
         *
         * The HttpHandler remains the main HTTP observation path, while the
         * ResponseHandler is used for execution bookkeeping and controlled
         * follow-up queuing.
         */
        fun startMapperRequestExecution(
            hostInput: String,
            timeoutMillis: Long = 30_000L
        ): RequestExecution? {

            val host =
                normalizeHostname(hostInput)
                    ?: return null

            if (!isHostActive(host)) {
                return null
            }

            val engine =
                requestEngines[host]
                    ?: return null

            if (timeoutMillis <= 0L) {
                throw IllegalArgumentException(
                    "timeoutMillis must be positive"
                )
            }

            val execution =
                try {

                    engine.sendAll(
                        { result, liveExecution ->

                            handleMapperRequestResult(
                                host = host,
                                result = result,
                                execution = liveExecution
                            )

                            /*
                             * Retain the RequestResult so the completed
                             * execution can report what actually happened.
                             *
                             * The durable application dataset still comes
                             * from the HTTP observation pipeline; retaining
                             * the execution result here is only bounded
                             * execution bookkeeping.
                             */
                            Retention.KEEP
                        },
                        Duration.ofMillis(timeoutMillis)
                    )

                } catch (error: IllegalStateException) {

                    api.logging().logToError(
                        "[Application Mapper] RequestExecutionEngine " +
                            "for host=$host has already been started: " +
                            "${error.message}"
                    )

                    requestEngines.remove(host)

                    return null

                } catch (error: RuntimeException) {

                    api.logging().logToError(
                        "[Application Mapper] RequestExecutionEngine failed " +
                            "for host=$host: ${error.message}"
                    )

                    requestEngines.remove(host)

                    return null
                }

            requestExecutions[host] =
                execution

            /*
             * Automatically observe completion.
             */
            execution.lifetime().onComplete { finalResult ->

                api.logging().logToOutput(
                    "[Application Mapper] REQUEST ENGINE FINISHED: " +
                        "host=$host " +
                        "results=${finalResult.results().size}"
                )

                requestExecutions.remove(host)
                requestEngines.remove(host)
            }

            return execution
        }

        /**
         * Execution-level bookkeeping.
         *
         * This does NOT replace the HTTP recorder.
         *
         * The result lets us preserve execution state while the canonical
         * request/response record is still produced by HttpHandler.
         */
        private fun handleMapperRequestResult(
            host: String,
            result: RequestResult,
            execution: RequestExecution
        ) {

            val status =
                result.status()

            val label =
                result.label()

            when (status) {

                RequestStatus.RESPONDED -> {

                    api.logging().logToOutput(
                        "[Application Mapper] REQUEST COMPLETED: " +
                            "host=$host " +
                            "label=$label"
                    )
                }

                else -> {

                    api.logging().logToOutput(
                        "[Application Mapper] REQUEST RESULT: " +
                            "host=$host " +
                            "label=$label " +
                            "status=$status"
                    )
                }
            }

            /*
             * Keep the live execution reference available for future
             * reactive expansion.
             */
            @Suppress("UNUSED_VARIABLE")
            val liveExecution =
                execution
        }

        /**
         * Pause one active RequestExecutionEngine run.
         */
        fun pauseMapperRequestExecution(
            hostInput: String
        ): Boolean {

            val host =
                normalizeHostname(hostInput)
                    ?: return false

            val execution =
                requestExecutions[host]
                    ?: return false

            execution.lifetime().pause()

            api.logging().logToOutput(
                "[Application Mapper] REQUEST ENGINE PAUSED: host=$host"
            )

            return true
        }

        /**
         * Resume one paused RequestExecutionEngine run.
         */
        fun resumeMapperRequestExecution(
            hostInput: String
        ): Boolean {

            val host =
                normalizeHostname(hostInput)
                    ?: return false

            val execution =
                requestExecutions[host]
                    ?: return false

            execution.lifetime().resume()

            api.logging().logToOutput(
                "[Application Mapper] REQUEST ENGINE RESUMED: host=$host"
            )

            return true
        }

        /**
         * Cancel one running RequestExecutionEngine run.
         */
        fun cancelMapperRequestExecution(
            hostInput: String
        ): Boolean {

            val host =
                normalizeHostname(hostInput)
                    ?: return false

            val execution =
                requestExecutions[host]
                    ?: return false

            execution.lifetime().cancel()

            api.logging().logToOutput(
                "[Application Mapper] REQUEST ENGINE CANCELLED: host=$host"
            )

            return true
        }

        /**
         * Determine whether a mapper RequestExecution run has finished.
         */
        fun mapperRequestExecutionFinished(
            hostInput: String
        ): Boolean {

            val host =
                normalizeHostname(hostInput)
                    ?: return true

            val execution =
                requestExecutions[host]
                    ?: return true

            return execution
                .lifetime()
                .finished()
        }

        /**
         * Queue and start one controlled mapper request using the native
         * Burp RequestExecutionEngine.
         */
        fun executeMapperRequest(
            hostInput: String,
            request: HttpRequest,
            label: String = "mapper-request",
            timeoutMillis: Long = 30_000L
        ): RequestExecution? {

            val host =
                normalizeHostname(hostInput)
                    ?: return null

            if (!queueMapperRequest(
                    hostInput = host,
                    request = request,
                    label = label
                )
            ) {
                return null
            }

            return startMapperRequestExecution(
                hostInput = host,
                timeoutMillis = timeoutMillis
            )
        }

        /**
         * Represents only URI information we need at this layer.
         */
        private data class ParsedUri(
            val scheme: String,
            val host: String,
            val port: Int
        )

        /**
         * ================================================================
         * BLOCK 6 — CANONICAL RECORD / CORRELATION ENGINE
         * ================================================================
         *
         * Every Burp/Montoya observation must pass through this layer.
         *
         * Examples:
         *
         * HTTPHandler
         *      \
         * SiteMap
         *       \
         * Scanner -----> canonical identity ---> merge ---> JSONL
         *       /
         * JavaScript / 
         *
         * The objective is:
         *
         *   SAME application resource
         *       -> ONE canonical record
         *
         * while preserving:
         *
         *   - different HTTP methods
         *   - different resource types
         *   - different parameter sets
         *   - multiple discovery paths
         *   - multiple observed URLs
         *   - multiple line locations
         *   - Burp/native provenance
         *
         * This is NOT unique(URL).
         */
        class HostState(
            val host: String,
            outputRoot: Path,
            private val gson: Gson
        ) : Closeable {

            private val lock =
                Any()

            private val outputDirectory: Path

            private val outputFile: Path

            private val tempFile: Path

            /*
             * Canonical resource store.
             *
             * The key is NOT merely the URL.
             */
            private val records =
                LinkedHashMap<CanonicalIdentity, MutableMap<String, Any?>>()


            /*
             * Number of changes since the last durable snapshot.
             *
             * We snapshot periodically instead of rewriting on every single
             * observation.
             */
            private var changesSinceSnapshot =
                0

            private val snapshotThreshold =
                25


            init {

                outputDirectory =
                    outputRoot
                        .resolve("burp_unauth")
                        .toAbsolutePath()
                        .normalize()

                Files.createDirectories(outputDirectory)

                outputFile =
                    outputDirectory.resolve(
                        safeHostFilename(host) + ".jsonl"
                    )

                /*
                 * Temporary snapshot lives OUTSIDE the permanent output
                 * contract from the user's perspective.
                 *
                 * The final burp_unauth directory contains only the canonical
                 * per-host JSONL.
                 */
                tempFile =
                    outputRoot
                        .resolve(
                            ".burp_unauth_" +
                                safeHostFilename(host) +
                                ".tmp"
                        )
                        .toAbsolutePath()
                        .normalize()
            }


            /**
             * Insert or merge one mapping observation.
             *
             * This is now the ONLY supported path for creating application
             * records.
             */
            fun upsert(
                incoming: Map<String, Any?>
            ) {

                synchronized(lock) {

                    val normalized =
                        normalizeRecord(incoming)

                    val identity =
                        CanonicalIdentity.from(
                            normalized
                        )

                    val existing =
                        records[identity]

                    if (existing == null) {

                        records[identity] =
                            normalized

                    } else {

                        mergeRecord(
                            existing = existing,
                            incoming = normalized
                        )
                    }

                    changesSinceSnapshot++

                    if (changesSinceSnapshot >= snapshotThreshold) {
                        snapshotLocked()
                    }
                }
            }


            /**
             * Force a durable snapshot.
             *
             * The canonical JSONL is rewritten from the merged resource model.
             *
             * This means:
             *
             * HTTP discovers /api/users
             * Site Map discovers /api/users
             * Scanner sees /api/users
             *
             * -> still ONE final JSONL record.
             */
            fun flush() {

                synchronized(lock) {
                    snapshotLocked()
                }
            }


            /**
             * Merge an observation into an existing canonical resource.
             */
            private fun mergeRecord(
                existing: MutableMap<String, Any?>,
                incoming: MutableMap<String, Any?>
            ) {

                /*
                 * ------------------------------------------------------------
                 * URL aggregation
                 * ------------------------------------------------------------
                 *
                 * Keep the canonical URL in "url".
                 *
                 * Additional observed representations are retained in
                 * observed_urls.
                 */
                mergeUrl(
                    existing,
                    incoming
                )


                /*
                 * ------------------------------------------------------------
                 * Provenance
                 * ------------------------------------------------------------
                 */
                mergeProvenance(
                    existing,
                    incoming
                )


                /*
                 * ------------------------------------------------------------
                 * Parameters
                 * ------------------------------------------------------------
                 */
                mergeStringList(
                    existing,
                    incoming,
                    "parameter_names"
                )

                mergeParameterLocations(
                    existing,
                    incoming
                )


                /*
                 * ------------------------------------------------------------
                 * Cookies
                 * ------------------------------------------------------------
                 */
                mergeStringList(
                    existing,
                    incoming,
                    "cookie_names"
                )


                /*
                 * ------------------------------------------------------------
                 * Redirect information
                 * ------------------------------------------------------------
                 */
                mergeNullableString(
                    existing,
                    incoming,
                    "redirect_location"
                )

                mergeStringList(
                    existing,
                    incoming,
                    "redirect_chain"
                )


                /*
                 * ------------------------------------------------------------
                 * Tags
                 * ------------------------------------------------------------
                 */
                mergeStringList(
                    existing,
                    incoming,
                    "burp_tags"
                )


                /*
                 * ------------------------------------------------------------
                 * Passive/audit findings
                 * ------------------------------------------------------------
                 */
                mergeFindingList(
                    existing,
                    incoming
                )


                /*
                 * ------------------------------------------------------------
                 * Generic useful metadata
                 * ------------------------------------------------------------
                 */
                mergeNullableString(
                    existing,
                    incoming,
                    "mime_type"
                )

                mergeNullableLong(
                    existing,
                    incoming,
                    "content_length"
                )

                mergeNullableString(
                    existing,
                    incoming,
                    "content_type"
                )

                mergeNullableString(
                    existing,
                    incoming,
                    "form_action"
                )

                mergeNullableString(
                    existing,
                    incoming,
                    "form_method"
                )

                mergeNullableString(
                    existing,
                    incoming,
                    "parent_url"
                )

                mergeNullableString(
                    existing,
                    incoming,
                    "js_source"
                )

                mergeNullableString(
                    existing,
                    incoming,
                    "api_source"
                )


                /*
                 * ------------------------------------------------------------
                 * Resource type
                 * ------------------------------------------------------------
                 *
                 * Prefer the more specific classification.
                 */
                val incomingResourceType =
                    incoming["resource_type"]
                        ?.toString()
                        ?.takeIf { it.isNotBlank() }

                val existingResourceType =
                    existing["resource_type"]
                        ?.toString()
                        ?.takeIf { it.isNotBlank() }

                if (incomingResourceType != null) {

                    if (existingResourceType == null ||
                        resourceTypePriority(incomingResourceType) >
                        resourceTypePriority(existingResourceType)
                    ) {

                        existing["resource_type"] =
                            incomingResourceType
                    }
                }


                /*
                 * ------------------------------------------------------------
                 * Notes
                 * ------------------------------------------------------------
                 *
                 * Never overwrite useful notes.
                 */
                mergeNotes(
                    existing,
                    incoming
                )


                /*
                 * ------------------------------------------------------------
                 * Execution / Burp metadata
                 * ------------------------------------------------------------
                 *
                 * These are later populated by the relevant integration
                 * blocks. Generic merging is handled here so those integrations
                 * don't create duplicate records.
                 */
                mergeGenericStructuredField(
                    existing,
                    incoming,
                    "burp_response_analysis"
                )

                mergeGenericStructuredField(
                    existing,
                    incoming,
                    "technology"
                )

                mergeGenericStructuredField(
                    existing,
                    incoming,
                    "technology_evidence"
                )

                mergeGenericStructuredField(
                    existing,
                    incoming,
                    "execution"
                )
            }


            /**
             * Normalize one incoming record before it enters the canonical map.
             */
            private fun normalizeRecord(
                input: Map<String, Any?>
            ): MutableMap<String, Any?> {

                val record =
                    LinkedHashMap<String, Any?>()

                /*
                 * Preserve all incoming data.
                 *
                 * The canonicalization layer only normalizes known mapping
                 * structures; it does not silently discard unknown useful data.
                 */
                input.forEach { (key, value) ->
                    record[key] = value
                }


                /*
                 * Required host.
                 */
                record["host"] =
                    record["host"]
                        ?.toString()
                        ?.let {
                            normalizeHostname(it)
                        }
                        ?: host


                /*
                 * URL is required for resource identity.
                 */
                val url =
                    record["url"]
                        ?.toString()
                        ?.trim()

                record["url"] =
                    url


                /*
                 * Normalize source representation.
                 *
                 * Existing single source remains intact.
                 *
                 * Multiple sources are retained under provenance.sources.
                 */
                val source =
                    record["source"]
                        ?.toString()
                        ?.takeIf { it.isNotBlank() }

                record["source"] =
                    source


                /*
                 * Every record can expose structured provenance.
                 */
                if (record["provenance"] == null) {

                    record["provenance"] =
                        linkedMapOf<String, Any?>(
                            "native" to emptyList<String>(),
                            "derived" to emptyList<String>(),
                            "sources" to emptyList<String>(),
                            "parents" to emptyList<String>()
                        )
                }


                /*
                 * Guarantee list fields are present.
                 */
                if (record["parameter_names"] == null) {
                    record["parameter_names"] =
                        emptyList<String>()
                }

                if (record["cookie_names"] == null) {
                    record["cookie_names"] =
                        emptyList<String>()
                }

                if (record["burp_tags"] == null) {
                    record["burp_tags"] =
                        emptyList<String>()
                }

                if (record["passive_findings"] == null) {
                    record["passive_findings"] =
                        emptyList<Any>()
                }

                if (record["redirect_chain"] == null) {
                    record["redirect_chain"] =
                        emptyList<String>()
                }

                /*
                 * Future JS/HTML/API analyzers use this for line aggregation.
                 */
                if (record["source_locations"] == null) {
                    record["source_locations"] =
                        emptyList<Int>()
                }

                /*
                 * Future relationship extraction can add multiple URLs.
                 */
                if (record["observed_urls"] == null) {
                    record["observed_urls"] =
                        emptyList<String>()
                }

                return record
            }


            /**
             * Aggregate URL observations.
             */
            private fun mergeUrl(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>
            ) {

                val canonicalUrl =
                    existing["url"]
                        ?.toString()
                        ?.takeIf { it.isNotBlank() }

                val incomingUrl =
                    incoming["url"]
                        ?.toString()
                        ?.takeIf { it.isNotBlank() }

                val urls =
                    linkedSetOf<String>()

                if (canonicalUrl != null) {
                    urls.add(canonicalUrl)
                }

                if (incomingUrl != null) {
                    urls.add(incomingUrl)
                }

                mergeStringList(
                    existing,
                    incoming,
                    "observed_urls"
                )

                val observed =
                    existing["observed_urls"]
                        .asStringList()
                        .toMutableSet()

                observed.addAll(urls)

                existing["observed_urls"] =
                    observed.sorted()
            }


            /**
             * Merge the structured provenance object.
             */
            private fun mergeProvenance(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>
            ) {

                val existingProvenance =
                    ensureProvenance(
                        existing
                    )

                val incomingProvenance =
                    ensureProvenance(
                        incoming.toMutableMap()
                    )


                /*
                 * Source paths.
                 */
                val sources =
                    linkedSetOf<String>()

                sources.addAll(
                    existingProvenance
                        .getValue("sources")
                        .asStringList()
                )

                sources.addAll(
                    incomingProvenance
                        .getValue("sources")
                        .asStringList()
                )

                incoming["source"]
                    ?.toString()
                    ?.takeIf { it.isNotBlank() }
                    ?.let(sources::add)

                existingProvenance["sources"] =
                    sources.sorted()


                /*
                 * Native / derived.
                 */
                mergeNestedStringSet(
                    existingProvenance,
                    incomingProvenance,
                    "native"
                )

                mergeNestedStringSet(
                    existingProvenance,
                    incomingProvenance,
                    "derived"
                )


                /*
                 * discovered_from / parent_url / js_source / api_source
                 */
                listOf(
                    "discovered_from",
                    "parent_url",
                    "js_source",
                    "api_source"
                ).forEach { field ->

                    val values =
                        linkedSetOf<String>()

                    existing[field]
                        ?.toString()
                        ?.takeIf { it.isNotBlank() }
                        ?.let(values::add)

                    incoming[field]
                        ?.toString()
                        ?.takeIf { it.isNotBlank() }
                        ?.let(values::add)

                    if (values.isNotEmpty()) {

                        /*
                         * Keep the first conventional scalar field.
                         *
                         * All additional paths are preserved in provenance.
                         */
                        if (existing[field] == null) {
                            existing[field] =
                                values.first()
                        }

                        val parents =
                            existingProvenance
                                .getValue("parents")
                                .asStringList()
                                .toMutableSet()

                        parents.addAll(values)

                        existingProvenance["parents"] =
                            parents.sorted()
                    }
                }

                existing["provenance"] =
                    existingProvenance
            }


            /**
             * Ensure structured provenance.
             */
            private fun ensureProvenance(
                record: MutableMap<String, Any?>
            ): MutableMap<String, Any?> {

                val raw =
                    record["provenance"]

                val result =
                    if (raw is Map<*, *>) {
                        LinkedHashMap<String, Any?>().apply {

                            raw.forEach { (key, value) ->

                                if (key is String) {
                                    this[key] = value
                                }
                            }
                        }
                    } else {
                        LinkedHashMap()
                    }

                listOf(
                    "native",
                    "derived",
                    "sources",
                    "parents"
                ).forEach { key ->

                    if (result[key] == null) {
                        result[key] =
                            emptyList<String>()
                    }
                }

                return result
            }


            /**
             * Add native/derived provenance based on the incoming record.
             */
            private fun classifyProvenanceOrigin(
                record: Map<String, Any?>
            ): String {

                return record["provenance_origin"]
                    ?.toString()
                    ?.lowercase(Locale.ROOT)
                    ?: "burp-native"
            }


            /**
             * Merge one string list.
             */
            private fun mergeStringList(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>,
                field: String
            ) {

                val values =
                    linkedSetOf<String>()

                values.addAll(
                    existing[field].asStringList()
                )

                values.addAll(
                    incoming[field].asStringList()
                )

                existing[field] =
                    values
                        .filter { it.isNotBlank() }
                        .sorted()
            }


            /**
             * Merge parameter location mapping.
             */
            private fun mergeParameterLocations(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>
            ) {

                val merged =
                    LinkedHashMap<String, MutableSet<String>>()

                fun consume(value: Any?) {

                    if (value !is Map<*, *>) {
                        return
                    }

                    value.forEach { (key, raw) ->

                        val name =
                            key?.toString()
                                ?: return@forEach

                        val locations =
                            when (raw) {

                                is Collection<*> ->
                                    raw.mapNotNull {
                                        it?.toString()
                                    }

                                else ->
                                    listOf(
                                        raw?.toString()
                                            ?: return@forEach
                                    )
                            }

                        merged
                            .getOrPut(name) {
                                LinkedHashSet()
                            }
                            .addAll(locations)
                    }
                }

                consume(existing["parameter_locations"])
                consume(incoming["parameter_locations"])

                existing["parameter_locations"] =
                    merged.mapValues { (_, values) ->
                        values.sorted()
                    }
            }


            private fun mergeNullableString(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>,
                field: String
            ) {

                if (existing[field] == null &&
                    incoming[field] != null
                ) {
                    existing[field] =
                        incoming[field]
                }
            }


            private fun mergeNullableLong(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>,
                field: String
            ) {

                if (existing[field] == null &&
                    incoming[field] != null
                ) {
                    existing[field] =
                        incoming[field]
                }
            }


            /**
             * Merge passive/audit findings while preventing identical finding
             * objects from being repeated.
             */
            private fun mergeFindingList(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>
            ) {

                val existingFindings =
                    existing["passive_findings"]
                        .asObjectList()

                val incomingFindings =
                    incoming["passive_findings"]
                        .asObjectList()

                val merged =
                    LinkedHashMap<String, MutableMap<String, Any?>>()

                fun addFinding(
                    finding: Map<String, Any?>
                ) {

                    val key =
                        listOf(
                            finding["name"],
                            finding["severity"],
                            finding["confidence"],
                            finding["base_url"]
                        )
                            .joinToString("|")

                    if (key !in merged) {
                        merged[key] =
                            LinkedHashMap(finding)
                    }
                }

                existingFindings.forEach(::addFinding)
                incomingFindings.forEach(::addFinding)

                existing["passive_findings"] =
                    merged.values.toList()
            }


            /**
             * Merge structured metadata without blindly overwriting it.
             *
             * Maps are recursively merged.
             * Collections are unioned.
             * Scalar values prefer the existing value unless missing.
             */
            private fun mergeGenericStructuredField(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>,
                field: String
            ) {

                val oldValue =
                    existing[field]

                val newValue =
                    incoming[field]

                if (newValue == null) {
                    return
                }

                if (oldValue == null) {

                    existing[field] =
                        newValue

                    return
                }

                when {

                    oldValue is Map<*, *> &&
                        newValue is Map<*, *> -> {

                        val merged =
                            LinkedHashMap<String, Any?>()

                        oldValue.forEach { (key, value) ->
                            if (key is String) {
                                merged[key] = value
                            }
                        }

                        newValue.forEach { (key, value) ->

                            if (key !is String) {
                                return@forEach
                            }

                            val existingValue =
                                merged[key]

                            merged[key] =
                                when {
                                    existingValue == null ->
                                        value

                                    existingValue is Collection<*> &&
                                        value is Collection<*> -> {

                                        (existingValue + value)
                                            .distinct()
                                    }

                                    else ->
                                        existingValue
                                }
                        }

                        existing[field] =
                            merged
                    }

                    oldValue is Collection<*> &&
                        newValue is Collection<*> -> {

                        existing[field] =
                            (oldValue + newValue)
                                .distinct()
                    }

                    else -> {
                        /*
                         * Preserve the first observed scalar.
                         */
                    }
                }
            }


            /**
             * Merge notes without destroying existing notes.
             */
            private fun mergeNotes(
                existing: MutableMap<String, Any?>,
                incoming: Map<String, Any?>
            ) {

                val old =
                    existing["notes"]
                        ?.toString()
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }

                val new =
                    incoming["notes"]
                        ?.toString()
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }

                when {

                    old == null && new != null ->
                        existing["notes"] = new

                    old != null && new != null &&
                        old != new -> {

                        existing["notes"] =
                            listOf(old, new)
                                .distinct()
                                .joinToString("\n")
                    }
                }
            }


            /**
             * Resource specificity ranking.
             */
            private fun resourceTypePriority(
                resourceType: String
            ): Int {

                return when (
                    resourceType.lowercase(Locale.ROOT)
                ) {

                    "api-endpoint" -> 100
                    "graphql-endpoint" -> 100
                    "websocket-endpoint" -> 100
                    "javascript" -> 90
                    "html" -> 80
                    "stylesheet" -> 70
                    "font" -> 60
                    "image" -> 50
                    "json" -> 45
                    "xml" -> 40
                    "http" -> 10
                    else -> 1
                }
            }


            /**
             * Create the canonical identity.
             *
             * IMPORTANT:
             *
             * This intentionally does NOT use unique(URL).
             *
             * Method and resource type remain meaningful dimensions.
             */
            data class CanonicalIdentity(
                val host: String,
                val method: String,
                val normalizedUrl: String,
                val resourceType: String
            ) {

                companion object {

                    fun from(
                        record: Map<String, Any?>
                    ): CanonicalIdentity {

                        val host =
                            record["host"]
                                ?.toString()
                                ?.lowercase(Locale.ROOT)
                                ?: ""

                        val method =
                            record["method"]
                                ?.toString()
                                ?.uppercase(Locale.ROOT)
                                ?: ""

                        val resourceType =
                            record["resource_type"]
                                ?.toString()
                                ?.lowercase(Locale.ROOT)
                                ?: "http"

                        val url =
                            normalizeCanonicalUrl(
                                record["url"]?.toString()
                            )

                        return CanonicalIdentity(
                            host = host,
                            method = method,
                            normalizedUrl = url,
                            resourceType = resourceType
                        )
                    }


                    private fun normalizeCanonicalUrl(
                        rawUrl: String?
                    ): String {

                        if (rawUrl.isNullOrBlank()) {
                            return ""
                        }

                        return runCatching {

                            val uri =
                                URI(rawUrl)

                            /*
                             * Fragments never belong to HTTP requests.
                             */
                            URI(
                                uri.scheme,
                                uri.userInfo,
                                uri.host,
                                uri.port,
                                uri.path,
                                uri.query,
                                null
                            )
                                .toString()
                                .lowercase(Locale.ROOT)

                        }.getOrElse {

                            rawUrl
                                .substringBefore('#')
                                .trim()
                                .lowercase(Locale.ROOT)
                        }
                    }
                }
            }


            /**
             * Rewrite the canonical JSONL snapshot atomically.
             *
             * We write the complete merged resource set to a temporary file
             * first. The previous JSONL remains intact until replacement
             * succeeds.
             */
            private fun snapshotLocked() {

                if (records.isEmpty()) {
                    changesSinceSnapshot = 0
                    return
                }

                runCatching {

                    Files.newBufferedWriter(
                        tempFile,
                        StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE,
                        StandardOpenOption.TRUNCATE_EXISTING,
                        StandardOpenOption.WRITE
                    ).use { writer ->

                        records.values.forEach { record ->

                            writer.write(
                                gson.toJson(record)
                            )

                            writer.newLine()
                        }

                        writer.flush()
                    }


                    runCatching {

                        Files.move(
                            tempFile,
                            outputFile,
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                            java.nio.file.StandardCopyOption.ATOMIC_MOVE
                        )

                    }.getOrElse {

                        /*
                         * Filesystem may not support atomic rename.
                         */
                        Files.move(
                            tempFile,
                            outputFile,
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING
                        )
                    }

                    changesSinceSnapshot = 0

                }.onFailure { error ->

                    /*
                     * Most important property:
                     *
                     * failure to rewrite the new snapshot must NOT destroy the
                     * previous valid JSONL.
                     */
                    runCatching {
                        Files.deleteIfExists(tempFile)
                    }

                    throw IOException(
                        "Failed to snapshot canonical JSONL for host=$host",
                        error
                    )
                }
            }


            override fun close() {

                synchronized(lock) {

                    /*
                     * Ensure every merged observation currently in memory is
                     * represented in the final JSONL.
                     */
                    snapshotLocked()

                    runCatching {
                        Files.deleteIfExists(tempFile)
                    }
                }
            }


            companion object {

                private fun safeHostFilename(
                    host: String
                ): String {

                    return host
                        .replace(
                            Regex("[^A-Za-z0-9._-]"),
                            "_"
                        )
                        .trim('.')
                        .ifBlank {
                            "unknown-host"
                        }
                }
            }
        }

        /**
         * Convert arbitrary JSON values into a string list safely.
         */
        private fun Any?.asStringList(): List<String> {

            return when (this) {

                null ->
                    emptyList()

                is Collection<*> ->
                    mapNotNull { value ->
                        value?.toString()
                    }

                is Array<*> ->
                    mapNotNull { value ->
                        value?.toString()
                    }

                else ->
                    listOf(
                        toString()
                    )
            }
        }


        /**
         * Convert arbitrary JSON-compatible collection values to object maps.
         */
        private fun Any?.asObjectList():
            List<Map<String, Any?>> {

            if (this !is Collection<*>) {
                return emptyList()
            }

            return mapNotNull { value ->

                when (value) {

                    is Map<*, *> -> {

                        LinkedHashMap<String, Any?>().also { map ->

                            value.forEach { (key, rawValue) ->

                                if (key is String) {
                                    map[key] = rawValue
                                }
                            }
                        }
                    }

                    else ->
                        null
                }
            }
        }


        /**
         * Merge nested provenance sets.
         */
        private fun mergeNestedStringSet(
            existing: MutableMap<String, Any?>,
            incoming: Map<String, Any?>,
            field: String
        ) {

            val merged =
                linkedSetOf<String>()

            merged.addAll(
                existing[field].asStringList()
            )

            merged.addAll(
                incoming[field].asStringList()
            )

            existing[field] =
                merged
                    .filter { it.isNotBlank() }
                    .sorted()
        }
    }
}

