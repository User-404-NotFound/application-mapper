plugins {
    id("java")
    kotlin("jvm") version "2.0.0"
    application
}

group = "com.user404.applicationmapper"
version = "1.0.0"

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    mavenCentral()
    mavenLocal()
}

dependencies {
    compileOnly(files("../montoya-api-2026.7.jar"))
    implementation("com.google.code.gson:gson:2.11.0")
    implementation(kotlin("stdlib-jdk8"))
    implementation("org.slf4j:slf4j-api:2.0.13")
    
    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.11.0")
    testImplementation("org.mockito:mockito-core:5.12.0")
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs = listOf("-Xjvm-default=all", "-opt-in=kotlin.RequiresOptIn")
    }
}

tasks.withType<Test> {
    useJUnitPlatform()
}

application {
    mainClass.set("com.user404.applicationmapper.ApplicationMapperExtension")
}

tasks.jar {
    manifest {
        attributes(
            "Burp-Extension-Name" to "Application Mapper",
            "Burp-Extension-Version" to "1.0.0",
            "Burp-Extension-Author" to "user404",
            "Implementation-Title" to "Application Mapper",
            "Implementation-Version" to "1.0.0",
            "Main-Class" to "com.user404.applicationmapper.ApplicationMapperExtension"
        )
    }
    from(configurations.runtimeClasspath.get().filter { it.name.endsWith(".jar") }.map { zipTree(it) })
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
}