package com.user404.applicationmapper.observation

import burp.api.montoya.core.ToolSource
import burp.api.montoya.core.ToolType
import burp.api.montoya.http.handler.HttpHandler
import burp.api.montoya.http.handler.HttpRequestToBeSent
import burp.api.montoya.http.handler.HttpResponseReceived
import burp.api.montoya.http.handler.RequestToBeSentAction
import burp.api.montoya.http.handler.ResponseReceivedAction
import burp.api.montoya.http.message.HttpRequestResponse
import burp.api.montoya.http.message.requests.HttpRequest
import burp.api.montoya.http.message.responses.HttpResponse
import com.user404.applicationmapper.core.HostLifecycleManager
import com.user404.applicationmapper.core.HostState
import com.user404.applicationmapper.engine.CanonicalIdentity
import com.user404.applicationmapper.model.MappingRecord
import com.user404.applicationmapper.model.PassiveFinding
import com.user404.applicationmapper.model.ProvenanceInfo
import com.user404.applicationmapper.model.RelationshipInfo
import java.time.Instant
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * HTTP Observer - Core HTTP traffic observation and recording.
 * 
 * This is the primary observation pipeline entry point.
 * All HTTP request/response pairs flow through here.
 * 
 * IMPORTANT: ToolType.PROXY == Burp Proxy, NEVER browser provenance.
 * Browser provenance only when Montoya explicitly exposes it.
 */
class HttpObserver(
    private val lifecycleManager: HostLifecycleManager,
    private val api: burp.api.montoya.MontoyaApi
) : HttpHandler {

    private val harvestedSiteMapKeys = ConcurrentHashMap.newKeySet<String>()
    private val harvestedIssueKeys = ConcurrentHashMap.newKeySet<String>()

    override fun handleHttpRequestToBeSent(
        requestToBeSent: HttpRequestToBeSent
    ): RequestToBeSentAction {
        // We don't modify requests, just observe
        return RequestToBeSentAction.continueWith(requestToBeSent)
    }

    override fun handleHttpResponseReceived(
        responseReceived: HttpResponseReceived
    ): ResponseReceivedAction {
        
        // Process asynchronously to avoid blocking Burp
        api.task().runAsync {
            processObservedResponse(responseReceived)
        }

        return ResponseReceivedAction.continueWith(responseReceived)
    }

    private fun processObservedResponse(responseReceived: HttpResponseReceived) {
        try {
            val request = responseReceived.initiatingRequest()
            val response = responseReceived.response()
            
            val parsed = parseRequestUri(request.url())
                ?: return
            
            val observedHost = normalizeHostname(parsed.host)
                ?: return

            // Check if host is actively being mapped
            val state = lifecycleManager.getHostState(observedHost)
                ?: return

            if (!lifecycleManager.isHostActive(observedHost)) {
                return
            }

            val toolSource = responseReceived.toolSource()
            val record = buildHttpRecord(
                host = observedHost,
                request = request,
                response = response,
                toolSource = toolSource
            )

            state.upsert(record)
            
        } catch (e: Exception) {
            api.logging().logToError("[Application Mapper] HTTP processing failure: ${e.message}")
        }
    }

    private fun buildHttpRecord(
        host: String,
        request: HttpRequest,
        response: HttpResponse,
        toolSource: ToolSource
    ): MappingRecord {
        
        val uri = parseRequestUri(request.url())
        val canonicalId = CanonicalIdentity.generate(
            host = host,
            url = request.url(),
            method = request.method(),
            resourceType = classifyHttpResource(response.header("Content-Type")?.value())
        )

        val builder = MappingRecord.builder()
            .apply {
                this.host = host
                this.url = request.url()
                this.scheme = uri?.scheme
                this.port = effectivePort(uri)
                this.method = request.method()
                this.status = response.statusCode().takeIf { it > 0 }
                
                val contentTypeHeader = response.header("Content-Type")?.value()
                this.mimeType = normalizeMimeType(contentTypeHeader)
                this.contentLength = response.header("Content-Length")?.value()?.toLongOrNull()
                this.contentType = contentTypeHeader
                
                this.redirectLocation = response.header("Location")?.value()
                this.redirectChain = extractRedirectChain(response)
                
                // Parameters
                val parameters = request.parameters()
                parameters.forEach { parameter ->
                    val name = parameter.name()
                    if (name.isNotBlank()) {
                        this.parameterNames.add(name)
                        val location = parameter.type().name.lowercase(Locale.ROOT)
                        this.parameterLocations.getOrPut(name) { ConcurrentHashMap.newKeySet() }.add(location)
                    }
                }
                
                this.formAction = null
                this.formMethod = null
                
                // Cookies
                this.cookieNames.addAll(collectCookieNames(request, response))
                
                // Provenance - ToolType.PROXY is ALWAYS proxy, never browser
                this.source = sourceForNativeTool(toolSource.toolType())
                this.discoveredFrom = null
                this.parentUrl = null
                this.jsSource = null
                this.apiSource = null
                
                this.resourceType = classifyHttpResource(contentTypeHeader)
                this.burpTags = emptyList()
                this.passiveFindings = emptyList()
                this.notes = null
                
                this.canonicalId = canonicalId
                this.firstSeen = Instant.now().toString()
                this.lastSeen = Instant.now().toString()
                this.observationCount = 1
                
                this.provenance = ProvenanceInfo().apply {
                    val toolType = toolSource.toolType().name.lowercase(Locale.ROOT)
                    addToolType(toolType)
                    addDiscoveryMethod(toolType)
                    if (isNativeSource(toolType)) {
                        addNativeSource(toolType)
                    } else {
                        addDerivedSource(toolType)
                    }
                    firstDiscoveredBy = toolType
                    lastDiscoveredBy = toolType
                }
                
                this.relationships = RelationshipInfo()
                
                this.requestMetadata = buildRequestMetadata(request)
                this.responseMetadata = buildResponseMetadata(response)
            }

        return builder.build()
    }

    private fun buildSiteMapRecord(
        host: String,
        request: HttpRequest,
        response: HttpResponse?,
        toolSource: ToolSource
    ): MappingRecord {
        val uri = parseRequestUri(request.url())
        val canonicalId = CanonicalIdentity.generate(
            host = host,
            url = request.url(),
            method = request.method(),
            resourceType = classifyHttpResource(response?.header("Content-Type")?.value())
        )

        val builder = MappingRecord.builder()
            .apply {
                this.host = host
                this.url = request.url()
                this.scheme = uri?.scheme
                this.port = effectivePort(uri)
                this.method = request.method()
                this.status = response?.statusCode()?.takeIf { it > 0 }
                
                val contentTypeHeader = response?.header("Content-Type")?.value()
                this.mimeType = normalizeMimeType(contentTypeHeader)
                this.contentLength = response?.header("Content-Length")?.value()?.toLongOrNull()
                this.redirectLocation = response?.header("Location")?.value()
                this.redirectChain = emptyList()
                
                val parameters = request.parameters()
                parameters.forEach { parameter ->
                    val name = parameter.name()
                    if (name.isNotBlank()) {
                        this.parameterNames.add(name)
                        val location = parameter.type().name.lowercase(Locale.ROOT)
                        this.parameterLocations.getOrPut(name) { ConcurrentHashMap.newKeySet() }.add(location)
                    }
                }
                
                this.formAction = null
                this.formMethod = null
                
                this.cookieNames.addAll(if (response != null) {
                    collectCookieNames(request, response)
                } else {
                    collectRequestCookieNames(request)
                })
                
                this.contentType = contentTypeHeader
                
                // Site Map is a native Burp mapping source
                this.source = "site-map"
                this.discoveredFrom = null
                this.parentUrl = null
                this.jsSource = null
                this.apiSource = null
                
                this.resourceType = classifyHttpResource(contentTypeHeader)
                this.burpTags = emptyList()
                this.passiveFindings = emptyList()
                this.notes = null
                
                this.canonicalId = canonicalId
                this.firstSeen = Instant.now().toString()
                this.lastSeen = Instant.now().toString()
                this.observationCount = 1
                
                this.provenance = ProvenanceInfo().apply {
                    addNativeSource("site-map")
                    addToolType("site-map")
                    addDiscoveryMethod("site-map")
                    firstDiscoveredBy = "site-map"
                    lastDiscoveredBy = "site-map"
                }
                
                this.relationships = RelationshipInfo()
                
                this.requestMetadata = buildRequestMetadata(request)
                this.responseMetadata = response?.let { buildResponseMetadata(it) }
            }

        return builder.build()
    }

    /**
     * Record an audit issue (passive finding).
     */
    fun recordAuditIssue(
        state: HostState,
        issue: burp.api.montoya.scanner.audit.issues.AuditIssue,
        source: String
    ) {
        val baseUrl = issue.baseUrl()
        val uri = parseRequestUri(baseUrl)
        
        val key = baseUrl + "|" + issue.name()
        if (!harvestedIssueKeys.add(key)) return

        val finding = PassiveFinding(
            name = issue.name(),
            severity = issue.severity().name.lowercase(Locale.ROOT),
            confidence = issue.confidence().name.lowercase(Locale.ROOT),
            detail = issue.detail(),
            remediation = issue.remediation(),
            cwe = null,
            source = source,
            baseUrl = baseUrl,
            burpTool = "scanner",
            burpIssue = true
        )

        val canonicalId = CanonicalIdentity.generate(
            host = state.host,
            url = baseUrl,
            method = null,
            resourceType = "audit-issue"
        )

        val record = MappingRecord.builder()
            .apply {
                this.host = state.host
                this.url = baseUrl
                this.scheme = uri?.scheme
                this.port = effectivePort(uri)
                this.method = null
                this.status = null
                this.mimeType = null
                this.contentLength = null
                this.redirectLocation = null
                this.redirectChain = emptyList()
                this.parameterNames = emptyList()
                this.parameterLocations = emptyMap()
                this.formAction = null
                this.formMethod = null
                this.cookieNames = emptyList()
                this.contentType = null
                this.source = source
                this.discoveredFrom = null
                this.parentUrl = null
                this.jsSource = null
                this.apiSource = null
                this.resourceType = "audit-issue"
                this.burpTags = emptyList()
                this.passiveFindings = listOf(finding)
                this.notes = null
                this.canonicalId = canonicalId
                this.firstSeen = Instant.now().toString()
                this.lastSeen = Instant.now().toString()
                this.observationCount = 1
                this.provenance = ProvenanceInfo().apply {
                    addNativeSource("scanner")
                    addToolType("scanner")
                    addDiscoveryMethod("passive-analysis")
                    firstDiscoveredBy = "scanner"
                    lastDiscoveredBy = "scanner"
                }
                this.relationships = RelationshipInfo()
            }
            .build()

        state.upsert(record)
    }

    private fun sourceForNativeTool(toolType: ToolType): String? {
        return when (toolType) {
            ToolType.PROXY -> "proxy"
            ToolType.SCANNER -> "scanner"
            ToolType.REPEATER -> "repeater"
            ToolType.INTRUDER -> "intruder"
            ToolType.EXTENSIONS -> "extension"
            ToolType.TARGET -> "target"
            ToolType.COLLABORATOR -> "collaborator"
            ToolType.SEQUENCER -> "sequencer"
            ToolType.DECODER -> "decoder"
            ToolType.COMPARER -> "comparer"
            ToolType.SPIDER -> "spider"
            ToolType.AUDITOR -> "auditor"
            else -> toolType.name.lowercase(Locale.ROOT)
        }
    }

    private fun isNativeSource(toolType: String): Boolean {
        return toolType in setOf("proxy", "scanner", "repeater", "intruder", "target", "site-map")
    }

    private fun classifyHttpResource(contentType: String?): String {
        val type = contentType
            ?.lowercase(Locale.ROOT)
            ?.substringBefore(';')
            ?.trim()
            ?: return "http"

        return when {
            type.contains("javascript") -> "javascript"
            type == "text/html" || type == "application/xhtml+xml" -> "html"
            type.contains("json") -> "json"
            type.contains("graphql") -> "graphql"
            type.contains("xml") -> "xml"
            type.contains("css") -> "stylesheet"
            type.startsWith("image/") -> "image"
            type.startsWith("font/") -> "font"
            type.contains("websocket") -> "websocket"
            else -> "http"
        }
    }

    private fun normalizeMimeType(contentType: String?): String? {
        return contentType
            ?.substringBefore(';')
            ?.trim()
            ?.takeIf { it.isNotBlank() }
    }

    private fun effectivePort(uri: ParsedUri?): Int? {
        if (uri == null) return null
        if (uri.port > 0) return uri.port
        return when (uri.scheme.lowercase(Locale.ROOT)) {
            "https", "wss" -> 443
            "http", "ws" -> 80
            else -> null
        }
    }

    private fun parseRequestUri(url: String?): ParsedUri? {
        if (url.isNullOrBlank()) return null
        return try {
            val uri = java.net.URI(url)
            val host = uri.host ?: return@try null
            val scheme = uri.scheme ?: return@try null
            ParsedUri(scheme = scheme, host = host, port = uri.port)
        } catch (e: Exception) {
            null
        }
    }

    private fun normalizeHostname(input: String?): String? {
        if (input.isNullOrBlank()) return null
        var host = input.trim().lowercase(Locale.ROOT)
        host = host.removePrefix("https://").removePrefix("http://")
        host = host.substringBefore('/')
        if (host.count { it == ':' } == 1) {
            host = host.substringBefore(':')
        }
        host = host.trim('.')
        return host.takeIf { it.isNotBlank() && !it.contains(' ') }
    }

    private fun collectRequestCookieNames(request: HttpRequest): List<String> {
        val names = ConcurrentHashMap.newKeySet<String>()
        request.headers()
            .filter { it.name().equals("Cookie", ignoreCase = true) }
            .forEach { header ->
                header.value()
                    .split(';')
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .forEach { pair ->
                        val name = pair.substringBefore('=').trim()
                        if (name.isNotEmpty()) names.add(name)
                    }
            }
        return names.toList()
    }

    private fun collectCookieNames(request: HttpRequest, response: HttpResponse): List<String> {
        val names = ConcurrentHashMap.newKeySet<String>()
        names.addAll(collectRequestCookieNames(request))
        response.cookies().forEach { cookie ->
            val name = cookie.name()
            if (name.isNotBlank()) names.add(name)
        }
        return names.toList()
    }

    private fun extractRedirectChain(response: HttpResponse): List<String> {
        // Montoya doesn't directly expose redirect chain
        // We capture the immediate Location header
        val location = response.header("Location")?.value()
        return if (location != null) listOf(location) else emptyList()
    }

    private fun buildRequestMetadata(request: HttpRequest): MappingRecord.RequestMetadata {
        val headers = mutableMapOf<String, MutableList<String>>()
        request.headers().forEach { header ->
            headers.getOrPut(header.name()) { mutableListOf() }.add(header.value())
        }
        val cookies = collectRequestCookieNames(request)
        return MappingRecord.RequestMetadata(
            headers = headers.mapValues { (_, v) -> v.toList() },
            cookies = cookies,
            bodySize = request.body()?.size.toLong(),
            bodyHash = request.body()?.let { computeHash(it) }
        )
    }

    private fun buildResponseMetadata(response: HttpResponse): MappingRecord.ResponseMetadata {
        val headers = mutableMapOf<String, MutableList<String>>()
        response.headers().forEach { header ->
            headers.getOrPut(header.name()) { mutableListOf() }.add(header.value())
        }
        val cookies = response.cookies().map { it.name() }.filter { it.isNotBlank() }.toList()
        return MappingRecord.ResponseMetadata(
            headers = headers.mapValues { (_, v) -> v.toList() },
            cookies = cookies,
            bodySize = response.body()?.size.toLong(),
            bodyHash = response.body()?.let { computeHash(it) },
            encoding = response.header("Content-Encoding")?.value()
        )
    }

    private fun computeHash(bytes: ByteArray): String {
        return java.security.MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }

    /**
     * Harvest Site Map for a host.
     */
    fun harvestSiteMapForHost(host: String) {
        val state = lifecycleManager.getHostState(host) ?: return
        
        val items = api.siteMap().requestResponses()
        
        items.forEach { item ->
            val request = item.request()
            val itemHost = parseRequestUri(request.url())?.host?.let(::normalizeHostname) ?: return@forEach
            
            if (itemHost != host) return@forEach
            
            val key = siteMapIdentity(request.url(), request.method())
            if (!harvestedSiteMapKeys.add(key)) return@forEach
            
            val response = item.response()
            val toolSource = request.toolSource()
            
            val record = buildSiteMapRecord(
                host = host,
                request = request,
                response = response,
                nativeToolSource = toolSource
            )
            
            state.upsert(record)
        }
        
        harvestSiteMapIssuesForHost(host)
    }

    private fun siteMapIdentity(url: String, method: String): String {
        return method.uppercase(Locale.ROOT) + "|" + url
    }

    private fun harvestSiteMapIssuesForHost(host: String) {
        val state = lifecycleManager.getHostState(host) ?: return
        
        val issues = api.siteMap().issues()
        
        issues.forEach { issue ->
            val baseUrl = issue.baseUrl()
            val issueHost = parseRequestUri(baseUrl)?.host?.let(::normalizeHostname) ?: return@forEach
            
            if (issueHost != host) return@forEach
            
            recordAuditIssue(state, issue, "passive-analysis")
        }
    }

    data class ParsedUri(val scheme: String, val host: String, val port: Int)
}