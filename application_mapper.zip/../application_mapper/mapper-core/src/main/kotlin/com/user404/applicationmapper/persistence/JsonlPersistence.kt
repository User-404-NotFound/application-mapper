package com.user404.applicationmapper.persistence

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.user404.applicationmapper.model.MappingRecord
import java.io.BufferedWriter
import java.io.Closeable
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardOpenOption
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.locks.ReentrantReadWriteLock

/**
 * JSONL persistence layer for per-host mapping data.
 * 
 * Features:
 * - One JSONL file per host
 * - Incremental writes (append-only for new records, rewrite for updates)
 * - Crash-safe with atomic writes
 * - Bounded memory via in-memory index with disk-backed storage
 * - Thread-safe concurrent access
 */
class JsonlPersistence(
    private val outputRoot: Path,
    private val gson: Gson = GsonBuilder().disableHtmlEscaping().create()
) : Closeable {

    private val writers = ConcurrentHashMap<String, HostWriter>()
    private val indexes = ConcurrentHashMap<String, HostIndex>()
    private val globalLock = ReentrantReadWriteLock()
    
    init {
        Files.createDirectories(outputRoot.resolve("burp_unauth"))
    }

    /**
     * Upsert a mapping record for a host.
     * Creates/updates the record in the host's JSONL file.
     */
    @Synchronized
    fun upsert(host: String, record: MappingRecord): Boolean {
        val normalizedHost = normalizeHostname(host)
        val writer = getOrCreateWriter(normalizedHost)
        val index = getOrCreateIndex(normalizedHost)
        
        val canonicalId = record.canonicalId
        val existingLine = index.recordPositions[canonicalId]
        
        val json = gson.toJson(record)
        
        if (existingLine != null) {
            // Update existing record - rewrite the file
            return writer.updateRecord(existingLine, json, index)
        } else {
            // Append new record
            val lineNumber = writer.appendRecord(json)
            if (lineNumber >= 0) {
                index.recordPositions[canonicalId] = lineNumber
                return true
            }
            return false
        }
    }

    /**
     * Append multiple records efficiently.
     */
    @Synchronized
    fun upsertBatch(host: String, records: List<MappingRecord>): Int {
        var count = 0
        for (record in records) {
            if (upsert(host, record)) count++
        }
        return count
    }

    /**
     * Get all records for a host.
     */
    fun getAllRecords(host: String): List<MappingRecord> {
        val normalizedHost = normalizeHostname(host)
        val file = getHostFile(normalizedHost)
        
        if (!Files.exists(file)) return emptyList()
        
        return Files.readAllLines(file, StandardCharsets.UTF_8).mapNotNull { line ->
            try {
                gson.fromJson(line, MappingRecord::class.java)
            } catch (e: Exception) {
                null
            }
        }
    }

    /**
     * Get record count for a host.
     */
    fun getRecordCount(host: String): Int {
        val normalizedHost = normalizeHostname(host)
        val index = indexes[normalizedHost]
        return index?.recordPositions?.size ?: 0
    }

    /**
     * Flush all pending writes for a host.
     */
    fun flush(host: String) {
        val normalizedHost = normalizeHostname(host)
        writers[normalizedHost]?.flush()
    }

    /**
     * Flush all hosts.
     */
    fun flushAll() {
        writers.values.forEach { it.flush() }
    }

    /**
     * Close and release resources for a host.
     */
    fun closeHost(host: String) {
        val normalizedHost = normalizeHostname(host)
        writers.remove(normalizedHost)?.close()
        indexes.remove(normalizedHost)
    }

    /**
     * Close all hosts.
     */
    override fun close() {
        writers.values.forEach { it.close() }
        writers.clear()
        indexes.clear()
    }

    private fun getOrCreateWriter(host: String): HostWriter {
        return writers.computeIfAbsent(host) { h ->
            val file = getHostFile(h)
            HostWriter(file, gson)
        }
    }

    private fun getOrCreateIndex(host: String): HostIndex {
        return indexes.computeIfAbsent(host) { h ->
            val file = getHostFile(h)
            HostIndex(file, gson)
        }
    }

    private fun getHostFile(host: String): Path {
        val safeHost = sanitizeFilename(host)
        return outputRoot.resolve("burp_unauth").resolve("$safeHost.jsonl")
    }

    private fun normalizeHostname(host: String): String {
        return host.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore('/')
            .substringBefore(':')
            .trim('.')
    }

    private fun sanitizeFilename(host: String): String {
        return host.replace(Regex("[^a-zA-Z0-9.-]"), "_")
    }

    /**
     * Writer for a single host's JSONL file.
     * Handles atomic appends and updates.
     */
    private class HostWriter(
        private val file: Path,
        private val gson: Gson
    ) : Closeable {
        private var writer: BufferedWriter? = null
        private val lock = ReentrantReadWriteLock()
        
        init {
            Files.createDirectories(file.parent!!)
            if (!Files.exists(file)) {
                Files.createFile(file)
            }
            writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8, StandardOpenOption.APPEND)
        }

        fun appendRecord(json: String): Int {
            lock.writeLock().lock()
            try {
                val lineNumber = countLines() + 1
                writer?.write(json)
                writer?.newLine()
                return lineNumber
            } catch (e: IOException) {
                return -1
            } finally {
                lock.writeLock().unlock()
            }
        }

        fun updateRecord(lineNumber: Int, newJson: String, index: HostIndex): Boolean {
            lock.writeLock().lock()
            try {
                // Read all lines
                val lines = Files.readAllLines(file, StandardCharsets.UTF_8).toMutableList()
                
                if (lineNumber > 0 && lineNumber <= lines.size) {
                    lines[lineNumber - 1] = newJson
                    
                    // Atomic write to temp file then rename
                    val tempFile = file.resolveSibling("${file.name}.tmp")
                    Files.write(tempFile, lines, StandardCharsets.UTF_8)
                    Files.move(tempFile, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING)
                    
                    // Rebuild index
                    index.rebuild()
                    return true
                }
                return false
            } catch (e: IOException) {
                return false
            } finally {
                lock.writeLock().unlock()
            }
        }

        fun flush() {
            lock.writeLock().lock()
            try {
                writer?.flush()
            } finally {
                lock.writeLock().unlock()
            }
        }

        override fun close() {
            lock.writeLock().lock()
            try {
                writer?.close()
                writer = null
            } catch (e: IOException) {
                // Ignore
            } finally {
                lock.writeLock().unlock()
            }
        }

        private fun countLines(): Int {
            return try {
                Files.readAllLines(file, StandardCharsets.UTF_8).size
            } catch (e: IOException) {
                0
            }
        }
    }

    /**
     * In-memory index for a host's JSONL file.
     * Maps canonical_id -> line number for fast updates.
     */
    private class HostIndex(
        private val file: Path,
        private val gson: Gson
    ) {
        val recordPositions = ConcurrentHashMap<String, Int>()
        
        init {
            rebuild()
        }

        fun rebuild() {
            recordPositions.clear()
            if (!Files.exists(file)) return
            
            try {
                var lineNumber = 0
                Files.readAllLines(file, StandardCharsets.UTF_8).forEach { line ->
                    lineNumber++
                    try {
                        val record = gson.fromJson(line, MappingRecord::class.java)
                        if (record.canonicalId.isNotBlank()) {
                            recordPositions[record.canonicalId] = lineNumber
                        }
                    } catch (e: Exception) {
                        // Skip malformed lines
                    }
                }
            } catch (e: IOException) {
                // Ignore
            }
        }
    }
}