package com.user404.applicationmapper.engine

import com.user404.applicationmapper.model.MappingRecord
import com.user404.applicationmapper.model.PassiveFinding
import com.user404.applicationmapper.model.ProvenanceInfo
import com.user404.applicationmapper.model.RelationshipInfo
import com.user404.applicationmapper.model.SourceLocation
import com.user404.applicationmapper.model.TechnologyInfo
import com.user404.applicationmapper.model.Technology

/**
 * Provenance engine for aggregating and merging provenance information
 * from multiple discovery sources.
 */
class ProvenanceEngine {

    /**
     * Merge provenance from a new observation into an existing record.
     */
    fun mergeProvenance(
        existing: MappingRecord,
        newRecord: MappingRecord,
        newSource: String,
        isNative: Boolean
    ): MappingRecord {
        val builder = existing.toBuilder()

        // Merge provenance
        val mergedProvenance = mergeProvenanceInfo(existing.provenance, newRecord.provenance, newSource, isNative)
        builder.provenance = mergedProvenance

        // Merge relationships
        val mergedRelationships = mergeRelationships(existing.relationships, newRecord.relationships)
        builder.relationships = mergedRelationships

        // Merge source locations (line aggregation)
        val mergedLocations = mergeSourceLocations(existing.sourceLocations, newRecord.sourceLocations)
        builder.sourceLocations = mergedLocations

        // Merge technology info
        val mergedTech = mergeTechnologyInfo(existing.technology, newRecord.technology)
        builder.technology = mergedTech

        // Merge passive findings
        val mergedFindings = mergePassiveFindings(existing.passiveFindings, newRecord.passiveFindings)
        builder.passiveFindings = mergedFindings

        // Merge tags
        val mergedTags = (existing.burpTags.toMutableSet() + newRecord.burpTags).toList()
        builder.burpTags = mergedTags

        // Update observation metadata
        builder.observationCount = existing.observationCount + 1
        builder.lastSeen = java.time.Instant.now().toString()

        // Preserve richer data from either record
        preserveRicherData(builder, existing, newRecord)

        return builder.build()
    }

    private fun mergeProvenanceInfo(
        existing: ProvenanceInfo,
        newProv: ProvenanceInfo,
        newSource: String,
        isNative: Boolean
    ): ProvenanceInfo {
        val merged = ProvenanceInfo()
        
        // Union all sets
        merged.nativeSources.addAll(existing.nativeSources)
        merged.nativeSources.addAll(newProv.nativeSources)
        merged.derivedSources.addAll(existing.derivedSources)
        merged.derivedSources.addAll(newProv.derivedSources)
        merged.toolTypes.addAll(existing.toolTypes)
        merged.toolTypes.addAll(newProv.toolTypes)
        merged.discoveryMethods.addAll(existing.discoveryMethods)
        merged.discoveryMethods.addAll(newProv.discoveryMethods)

        // Track current source
        if (isNative) {
            merged.addNativeSource(newSource)
        } else {
            merged.addDerivedSource(newSource)
        }
        merged.addDiscoveryMethod(newSource)

        // Preserve first/last discovered by
        merged.firstDiscoveredBy = existing.firstDiscoveredBy ?: newProv.firstDiscoveredBy ?: newSource
        merged.lastDiscoveredBy = newSource

        return merged
    }

    private fun mergeRelationships(
        existing: RelationshipInfo,
        newRel: RelationshipInfo
    ): RelationshipInfo {
        val merged = RelationshipInfo()
        merged.parents.addAll(existing.parents)
        merged.parents.addAll(newRel.parents)
        merged.children.addAll(existing.children)
        merged.children.addAll(newRel.children)
        merged.redirectsFrom.addAll(existing.redirectsFrom)
        merged.redirectsFrom.addAll(newRel.redirectsFrom)
        merged.redirectsTo.addAll(existing.redirectsTo)
        merged.redirectsTo.addAll(newRel.redirectsTo)
        merged.formsOnPage.addAll(existing.formsOnPage)
        merged.formsOnPage.addAll(newRel.formsOnPage)
        merged.resourcesOnPage.addAll(existing.resourcesOnPage)
        merged.resourcesOnPage.addAll(newRel.resourcesOnPage)
        merged.apiEndpoints.addAll(existing.apiEndpoints)
        merged.apiEndpoints.addAll(newRel.apiEndpoints)
        merged.websocketEndpoints.addAll(existing.websocketEndpoints)
        merged.websocketEndpoints.addAll(newRel.websocketEndpoints)

        // Deduplicate
        merged.parents = merged.parents.distinct()
        merged.children = merged.children.distinct()
        merged.redirectsFrom = merged.redirectsFrom.distinct()
        merged.redirectsTo = merged.redirectsTo.distinct()
        merged.formsOnPage = merged.formsOnPage.distinct()
        merged.resourcesOnPage = merged.resourcesOnPage.distinct()
        merged.apiEndpoints = merged.apiEndpoints.distinct()
        merged.websocketEndpoints = merged.websocketEndpoints.distinct()

        return merged
    }

    private fun mergeSourceLocations(
        existing: List<SourceLocation>,
        newLocations: List<SourceLocation>
    ): List<SourceLocation> {
        val byFile = mutableMapOf<String, MutableSet<Int>>()
        
        for (loc in existing) {
            byFile.getOrPut(loc.file) { mutableSetOf() }.addAll(loc.lines)
        }
        for (loc in newLocations) {
            byFile.getOrPut(loc.file) { mutableSetOf() }.addAll(loc.lines)
        }

        return byFile.map { (file, lines) ->
            SourceLocation(file, lines.toList().sorted(), null)
        }.toList()
    }

    private fun mergeTechnologyInfo(
        existing: TechnologyInfo?,
        newTech: TechnologyInfo?
    ): TechnologyInfo? {
        if (existing == null) return newTech
        if (newTech == null) return existing

        val merged = TechnologyInfo()
        merged.technologies.addAll(existing.technologies)
        merged.technologies.addAll(newTech.technologies)
        
        // Deduplicate technologies by name
        val byName = mutableMapOf<String, Technology>()
        for (tech in merged.technologies) {
            val existingTech = byName[tech.name]
            if (existingTech == null || tech.confidenceWeight() > existingTech.confidenceWeight()) {
                byName[tech.name] = tech
            }
        }
        merged.technologies = byName.values.toList()

        // Preserve non-null values, preferring existing
        merged.server = existing.server ?: newTech.server
        merged.framework = existing.framework ?: newTech.framework
        merged.cms = existing.cms ?: newTech.cms
        merged.language = existing.language ?: newTech.language
        merged.database = existing.database ?: newTech.database
        merged.cdn = existing.cdn ?: newTech.cdn
        merged.waf = existing.waf ?: newTech.waf
        merged.hosting = existing.hosting ?: newTech.hosting

        return merged
    }

    private fun mergePassiveFindings(
        existing: List<PassiveFinding>,
        newFindings: List<PassiveFinding>
    ): List<PassiveFinding> {
        val byKey = mutableMapOf<String, PassiveFinding>()
        
        for (finding in existing + newFindings) {
            val key = "${finding.name}|${finding.baseUrl}|${finding.source}"
            val existingFinding = byKey[key]
            if (existingFinding == null || finding.severityWeight() > existingFinding.severityWeight()) {
                byKey[key] = finding
            }
        }
        
        return byKey.values.toList()
    }

    private fun preserveRicherData(
        builder: MappingRecord.Builder,
        existing: MappingRecord,
        newRecord: MappingRecord
    ) {
        // Preserve non-null values, preferring more informative ones
        builder.status = preferNonNull(existing.status, newRecord.status) { a, b -> 
            // Prefer actual status over null
            if (a == null) b else a 
        }
        
        builder.contentLength = preferNonNull(existing.contentLength, newRecord.contentLength) { a, b ->
            if (a == null) b else a
        }

        builder.mimeType = preferNonNull(existing.mimeType, newRecord.mimeType) { a, b ->
            if (a == null || a == "http") b else a
        }

        builder.contentType = preferNonNull(existing.contentType, newRecord.contentType) { a, b ->
            if (a == null) b else a
        }

        builder.redirectLocation = preferNonNull(existing.redirectLocation, newRecord.redirectLocation) { a, b ->
            if (a == null) b else a
        }

        // Merge redirect chains
        val mergedChain = (existing.redirectChain + newRecord.redirectChain).distinct()
        builder.redirectChain = mergedChain

        // Merge parameter info
        builder.parameterNames.addAll(newRecord.parameterNames)
        for ((name, locations) in newRecord.parameterLocations) {
            builder.parameterLocations.getOrPut(name) { mutableSetOf() }.addAll(locations)
        }

        // Merge cookie names
        builder.cookieNames.addAll(newRecord.cookieNames)

        // Preserve form info if present
        if (newRecord.formAction != null) builder.formAction = newRecord.formAction
        if (newRecord.formMethod != null) builder.formMethod = newRecord.formMethod

        // Preserve JS/API source info
        if (newRecord.jsSource != null) builder.jsSource = newRecord.jsSource
        if (newRecord.apiSource != null) builder.apiSource = newRecord.apiSource

        // Preserve resource type if more specific
        if (newRecord.resourceType != "http") builder.resourceType = newRecord.resourceType

        // Preserve notes if new one has content
        if (newRecord.notes != null && newRecord.notes!.isNotBlank()) {
            builder.notes = newRecord.notes
        }
    }

    private fun <T> preferNonNull(
        existing: T?,
        newVal: T?,
        selector: (T?, T?) -> T?
    ): T? {
        return selector(existing, newVal)
    }
}

private fun PassiveFinding.severityWeight(): Int {
    return when (severity.lowercase()) {
        "critical" -> 4
        "high" -> 3
        "medium" -> 2
        "low" -> 1
        "info" -> 0
        else -> 0
    }
}

private fun Technology.confidenceWeight(): Int {
    return when (confidence.lowercase()) {
        "certain" -> 4
        "high" -> 3
        "medium" -> 2
        "low" -> 1
        else -> 0
    }
}