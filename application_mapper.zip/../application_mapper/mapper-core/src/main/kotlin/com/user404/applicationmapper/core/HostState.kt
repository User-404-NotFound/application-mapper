package com.user404.applicationmapper.core

import com.user404.applicationmapper.engine.CanonicalIdentity
import com.user404.applicationmapper.engine.ProvenanceEngine
import com.user404.applicationmapper.model.MappingRecord
import com.user404.applicationmapper.persistence.JsonlPersistence
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap

/**
 * Per-host runtime state.
 * Isolated from other hosts for strict host isolation.
 */
class HostState(
    val host: String,
    private val persistence: JsonlPersistence,
    private val provenanceEngine: ProvenanceEngine
) : AutoCloseable {

    private val canonicalRecords = ConcurrentHashMap<String, MappingRecord>()
    private val pendingWrites = ConcurrentHashMap<String, MappingRecord>()
    private var closed = false
    private val writeLock = java.util.concurrent.locks.ReentrantLock()

    /**
     * Upsert a record into this host's state.
     * Handles deduplication and provenance aggregation.
     */
    fun upsert(record: MappingRecord): Boolean {
        if (closed) return false
        
        val canonicalId = record.canonicalId
        val existing = canonicalRecords[canonicalId]
        
        val merged = if (existing != null) {
            // Merge with existing record
            provenanceEngine.mergeProvenance(
                existing = existing,
                newRecord = record,
                newSource = record.source ?: "unknown",
                isNative = record.provenance.nativeSources.contains(record.source ?: "")
            )
        } else {
            // New record
            record
        }
        
        canonicalRecords[canonicalId] = merged
        pendingWrites[canonicalId] = merged
        return true
    }

    /**
     * Flush pending writes to persistence.
     */
    fun flush(): Int {
        if (closed) return 0
        
        writeLock.lock()
        try {
            val toWrite = pendingWrites.values.toList()
            pendingWrites.clear()
            
            if (toWrite.isNotEmpty()) {
                return persistence.upsertBatch(host, toWrite)
            }
            return 0
        } finally {
            writeLock.unlock()
        }
    }

    /**
     * Get a canonical record by ID.
     */
    fun getRecord(canonicalId: String): MappingRecord? {
        return canonicalRecords[canonicalId]
    }

    /**
     * Get all canonical records for this host.
     */
    fun getAllRecords(): List<MappingRecord> {
        return canonicalRecords.values.toList()
    }

    /**
     * Get record count.
     */
    fun getRecordCount(): Int {
        return canonicalRecords.size
    }

    /**
     * Check if host state is closed.
     */
    fun isClosed(): Boolean {
        return closed
    }

    override fun close() {
        if (!closed) {
            flush()
            closed = true
            persistence.closeHost(host)
        }
    }
}

/**
 * Host lifecycle states.
 */
enum class HostLifecycleState {
    INITIAL,      // Host is in initial seed list
    QUEUED,       // Host is queued for processing
    ACTIVE,       // Host is actively being mapped
    PROCESSING,   // Host crawl/extraction in progress
    FINALIZING,   // Host crawl complete, final harvesting
    COMPLETED,    // Host mapping complete
    FAILED        // Host mapping failed
}

/**
 * Host lifecycle manager.
 * Manages the complete lifecycle of each host from initial seed to completion.
 */
class HostLifecycleManager(
    private val persistence: JsonlPersistence,
    private val provenanceEngine: ProvenanceEngine
) {
    private val hostStates = ConcurrentHashMap<String, HostState>()
    private val hostLifecycle = ConcurrentHashMap<String, HostLifecycleState>()
    private val lifecycleLock = java.util.concurrent.locks.ReentrantReadWriteLock()

    // Dynamic subdomain frontier
    private val initialHosts = ConcurrentHashMap.newKeySet<String>()
    private val discoveredHosts = ConcurrentHashMap.newKeySet<String>()
    private val queuedHosts = ConcurrentHashMap.newKeySet<String>()
    private val activeHosts = ConcurrentHashMap.newKeySet<String>()
    private val processedHosts = ConcurrentHashMap.newKeySet<String>()
    private val hostQueue = java.util.concurrent.ConcurrentLinkedQueue<String>()

    /**
     * Add an initial hostname from subdomains.txt.
     */
    fun addInitialHost(hostInput: String): Boolean {
        val host = normalizeHostname(hostInput) ?: return false
        
        if (initialHosts.add(host)) {
            discoveredHosts.add(host)
            enqueueHost(host)
            setLifecycleState(host, HostLifecycleState.INITIAL)
            return true
        }
        return false
    }

    /**
     * Add multiple initial hosts.
     */
    fun addInitialHosts(hosts: List<String>): Int {
        var count = 0
        for (host in hosts) {
            if (addInitialHost(host)) count++
        }
        return count
    }

    /**
     * Discover a new subdomain during mapping.
     */
    fun discoverSubdomain(
        applicationHost: String,
        discoveredHost: String,
        source: String,
        discoveredFrom: String
    ): Boolean {
        val appHost = normalizeHostname(applicationHost) ?: return false
        val discHost = normalizeHostname(discoveredHost) ?: return false

        // Verify the application host is in our frontier
        if (!initialHosts.contains(appHost) && !discoveredHosts.contains(appHost)) {
            return false
        }

        // Check if eligible (in Burp scope)
        if (!isEligibleApplicationSubdomain(appHost, discHost)) {
            return false
        }

        val isNew = discoveredHosts.add(discHost)
        if (!isNew) return false

        enqueueHost(discHost)
        setLifecycleState(discHost, HostLifecycleState.INITIAL)
        return true
    }

    /**
     * Begin mapping a host.
     */
    fun beginHost(hostInput: String): HostState? {
        val host = normalizeHostname(hostInput) ?: return null
        
        lifecycleLock.writeLock().lock()
        try {
            if (processedHosts.contains(host) || activeHosts.contains(host)) {
                return null
            }
            
            activeHosts.add(host)
            queuedHosts.remove(host)
            setLifecycleState(host, HostLifecycleState.ACTIVE)
            
            val state = hostStates.computeIfAbsent(host) {
                HostState(host, persistence, provenanceEngine)
            }
            
            return state
        } finally {
            lifecycleLock.writeLock().unlock()
        }
    }

    /**
     * Mark host as processing (crawl/extraction in progress).
     */
    fun setProcessing(host: String) {
        val normalized = normalizeHostname(host) ?: return
        if (activeHosts.contains(normalized)) {
            setLifecycleState(normalized, HostLifecycleState.PROCESSING)
        }
    }

    /**
     * Finalize host mapping (harvest final data).
     */
    fun finalizeHost(host: String): Boolean {
        val normalized = normalizeHostname(host) ?: return false
        
        lifecycleLock.writeLock().lock()
        try {
            if (!activeHosts.contains(normalized)) return false
            
            setLifecycleState(normalized, HostLifecycleState.FINALIZING)
            
            // Flush any pending writes
            hostStates[normalized]?.flush()
            
            activeHosts.remove(normalized)
            processedHosts.add(normalized)
            setLifecycleState(normalized, HostLifecycleState.COMPLETED)
            
            return true
        } finally {
            lifecycleLock.writeLock().unlock()
        }
    }

    /**
     * Mark host as failed.
     */
    fun failHost(host: String) {
        val normalized = normalizeHostname(host) ?: return
        activeHosts.remove(normalized)
        processedHosts.add(normalized)
        setLifecycleState(normalized, HostLifecycleState.FAILED)
    }

    /**
     * Get the next queued host.
     */
    fun nextQueuedHost(): String? {
        return hostQueue.poll()?.let { host ->
            if (!processedHosts.contains(host) && !activeHosts.contains(host)) {
                queuedHosts.add(host)
                setLifecycleState(host, HostLifecycleState.QUEUED)
                host
            } else {
                nextQueuedHost()
            }
        }
    }

    /**
     * Get host state for an active host.
     */
    fun getHostState(host: String): HostState? {
        val normalized = normalizeHostname(host) ?: return null
        return if (activeHosts.contains(normalized)) hostStates[normalized] else null
    }

    /**
     * Check if host is active.
     */
    fun isHostActive(host: String): Boolean {
        val normalized = normalizeHostname(host) ?: return false
        return activeHosts.contains(normalized)
    }

    /**
     * Get lifecycle state.
     */
    fun getLifecycleState(host: String): HostLifecycleState? {
        val normalized = normalizeHostname(host) ?: return null
        return hostLifecycle[normalized]
    }

    /**
     * Get all known hosts.
     */
    fun getKnownHosts(): List<String> {
        return discoveredHosts.toList().sorted()
    }

    /**
     * Get queued host count.
     */
    fun getQueuedCount(): Int {
        return hostQueue.size
    }

    /**
     * Get processed host count.
     */
    fun getProcessedCount(): Int {
        return processedHosts.size
    }

    /**
     * Get active host count.
     */
    fun getActiveCount(): Int {
        return activeHosts.size
    }

    /**
     * Stop all active hosts.
     */
    fun stopAll() {
        activeHosts.toList().forEach { finalizeHost(it) }
    }

    private fun enqueueHost(host: String) {
        if (!queuedHosts.contains(host) && !processedHosts.contains(host) && !activeHosts.contains(host)) {
            queuedHosts.add(host)
            hostQueue.add(host)
        }
    }

    private fun setLifecycleState(host: String, state: HostLifecycleState) {
        hostLifecycle[host] = state
    }

    private fun isEligibleApplicationSubdomain(applicationHost: String, discoveredHost: String): Boolean {
        // Check if discovered host is in Burp scope
        // This would integrate with Burp's scope API
        // For now, accept if it shares the same base domain
        val appDomain = getBaseDomain(applicationHost)
        val discDomain = getBaseDomain(discoveredHost)
        return appDomain == discDomain
    }

    private fun getBaseDomain(host: String): String {
        val parts = host.split(".")
        return if (parts.size >= 2) parts.takeLast(2).joinToString(".") else host
    }

    private fun normalizeHostname(host: String?): String? {
        return host?.trim()?.lowercase()
            ?.removePrefix("https://")
            ?.removePrefix("http://")
            ?.substringBefore('/')
            ?.substringBefore(':')
            ?.trim('.')
            ?.takeIf { it.isNotBlank() && !it.contains(' ') }
    }
}