package com.user404.applicationmapper.core

import burp.api.montoya.BurpExtension
import burp.api.montoya.MontoyaApi
import burp.api.montoya.core.ToolType
import burp.api.montoya.http.handler.HttpHandler
import burp.api.montoya.http.handler.HttpResponseReceived
import burp.api.montoya.scanner.Crawl
import burp.api.montoya.scanner.CrawlConfiguration
import burp.api.montoya.scanner.Scanner
import burp.api.montoya.scanner.audit.AuditIssueHandler
import burp.api.montoya.scanner.audit.issues.AuditIssue
import burp.api.montoya.scope.Scope
import burp.api.montoya.sitemap.SiteMap
import com.user404.applicationmapper.engine.CanonicalIdentity
import com.user404.applicationmapper.engine.ProvenanceEngine
import com.user404.applicationmapper.extraction.HtmlJsExtractor
import com.user404.applicationmapper.observation.HttpObserver
import com.user404.applicationmapper.persistence.JsonlPersistence
import com.user404.applicationmapper.tech.TechnologyDetector
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.Closeable
import java.nio.file.Files
import java.nio.file.Path
import java.time.Instant
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.Executors
import java.util.concurrent.ExecutorService
import java.util.concurrent.atomic.AtomicReference

/**
 * Main Application Mapper Extension.
 * 
 * This is the central orchestrator that integrates:
 * - Burp HTTP observation (Proxy, Scanner, Repeater, etc.)
 * - Burp Site Map harvesting
 * - Burp Scanner audit issues
 * - Native Burp crawling
 * - RequestExecutionEngine for controlled requests
 * - HTML/JS/API extraction
 * - Technology detection
 * - Dynamic subdomain frontier
 * - JSONL persistence
 */
class ApplicationMapperExtension : BurpExtension {

    private lateinit var api: MontoyaApi
    private lateinit var core: MapperCore

    override fun initialize(montoyaApi: MontoyaApi) {
        this.api = montoyaApi
        api.extension().setName("Application Mapper")

        core = MapperCore(api)

        // Register audit issue handler for passive findings
        runCatching {
            api.scanner().registerAuditIssueHandler(core)
        }.onFailure { error ->
            api.logging().logToError(
                "[Application Mapper] Scanner AuditIssueHandler registration " +
                    "failed: ${error.message}"
            )
        }

        // Register HTTP handler for all HTTP traffic observation
        api.http().registerHttpHandler(core)

        api.logging().logToOutput(
            "[Application Mapper] Initialized with Montoya API ${api.burpSuite().version()}"
        )
    }
}

/**
 * Core mapper logic - orchestrates all components.
 */
class MapperCore(
    private val api: MontoyaApi
) : HttpHandler, AuditIssueHandler, Closeable {

    private val gson: Gson = GsonBuilder().disableHtmlEscaping().create()

    // Output directory
    @Volatile
    private var outputRoot: Path =
        Path.of(System.getProperty("user.home"), ".burp_app_mapper")

    // Core components
    private val provenanceEngine = ProvenanceEngine()
    private val persistence = JsonlPersistence(outputRoot, gson)
    private val lifecycleManager = HostLifecycleManager(persistence, provenanceEngine)
    private val httpObserver = HttpObserver(lifecycleManager, api)
    private val htmlJsExtractor = HtmlJsExtractor()
    private val technologyDetector = TechnologyDetector()
    
    // Async executor for background tasks
    private val executorService: ExecutorService = Executors.newFixedThreadPool(10)

    // Burp native components
    private val scanner: Scanner? = runCatching { api.scanner() }.getOrNull()
    private val siteMap: SiteMap = api.siteMap()
    private val burpScope: Scope = api.scope()

    // Crawl management
    private val crawlTasks = ConcurrentHashMap<String, Crawl>()
    private val harvestedSiteMapKeys = ConcurrentHashMap.newKeySet<String>()
    private val harvestedIssueKeys = ConcurrentHashMap.newKeySet<String>()

    // Request execution engines
    private val requestEngines = ConcurrentHashMap<String, burp.api.montoya.http.execution.RequestExecutionEngine>()

    // Host state
    private val hostStates = ConcurrentHashMap<String, HostState>()

    init {
        Files.createDirectories(outputRoot.resolve("burp_unauth"))
    }

    // ================================================================
    // HTTP HANDLER - Main observation pipeline
    // ================================================================

    override fun handleHttpRequestToBeSent(
        requestToBeSent: burp.api.montoya.http.handler.HttpRequestToBeSent
    ): burp.api.montoya.http.handler.RequestToBeSentAction {
        return burp.api.montoya.http.handler.RequestToBeSentAction.continueWith(requestToBeSent)
    }

    override fun handleHttpResponseReceived(
        responseReceived: HttpResponseReceived
    ): burp.api.montoya.http.handler.ResponseReceivedAction {
        
        executorService.submit {
            processObservedResponse(responseReceived)
        }

        return burp.api.montoya.http.handler.ResponseReceivedAction.continueWith(responseReceived)
    }

    private fun processObservedResponse(responseReceived: HttpResponseReceived) {
        try {
            val request = responseReceived.initiatingRequest()
            val response: burp.api.montoya.http.message.responses.HttpResponse = responseReceived
            
            val parsed = parseRequestUri(request.url()) ?: return
            val observedHost = normalizeHostname(parsed.host) ?: return

            val state = lifecycleManager.getHostState(observedHost) ?: return
            if (!lifecycleManager.isHostActive(observedHost)) return

            val toolSource = responseReceived.toolSource()
            val record = buildHttpRecord(
                host = observedHost,
                request = request,
                response = response,
                toolSource = toolSource
            )

            // Enhance with technology detection
            enhanceWithTechnology(record, response)

            // Extract HTML/JS/API resources
            if (shouldExtractContent(record)) {
                val extracted = htmlJsExtractor.extractFromResponse(
                    host = observedHost,
                    baseUrl = request.url(),
                    contentType = response.header("Content-Type")?.value(),
                    body = response.bodyToString() ?: "",
                    source = record.source ?: "http",
                    parentUrl = record.parentUrl
                )
                extracted.forEach { state.upsert(it) }
            }

            state.upsert(record)

        } catch (e: Exception) {
            api.logging().logToError("[Application Mapper] HTTP processing failure: ${e.message}")
        }
    }

    private fun buildHttpRecord(
        host: String,
        request: burp.api.montoya.http.message.requests.HttpRequest,
        response: burp.api.montoya.http.message.responses.HttpResponse,
        toolSource: burp.api.montoya.core.ToolSource
    ): com.user404.applicationmapper.model.MappingRecord {
        
        val uri = parseRequestUri(request.url())
        val canonicalId = CanonicalIdentity.generate(
            host = host,
            url = request.url(),
            method = request.method(),
            resourceType = classifyHttpResource(response.header("Content-Type")?.value())
        )

        return com.user404.applicationmapper.model.MappingRecord.builder()
            .apply {
                this.host = host
                this.url = request.url()
                this.scheme = uri?.scheme
                this.port = effectivePort(uri)
                this.method = request.method()
                this.status = response.statusCode().takeIf { it > 0 }
                
                val contentTypeHeader = response.header("Content-Type")?.value()
                this.mimeType = normalizeMimeType(contentTypeHeader)
                this.contentLength = response.header("Content-Length")?.value()?.toLongOrNull()
                this.contentType = contentTypeHeader
                
                this.redirectLocation = response.header("Location")?.value()
                this.redirectChain = extractRedirectChain(response)
                
                // Parameters
                val parameters = request.parameters()
                parameters.forEach { parameter ->
                    val name = parameter.name()
                    if (name.isNotBlank()) {
                        this.parameterNames.add(name)
                        val location = parameter.type().name.lowercase(Locale.ROOT)
                        this.parameterLocations.getOrPut(name) { java.util.concurrent.ConcurrentHashMap.newKeySet() }.add(location)
                    }
                }
                
                this.formAction = null
                this.formMethod = null
                
                // Cookies
                this.cookieNames.addAll(collectCookieNames(request, response))
                
                // Provenance
                this.source = sourceForNativeTool(toolSource.toolType())
                this.discoveredFrom = null
                this.parentUrl = null
                this.jsSource = null
                this.apiSource = null
                
                this.resourceType = classifyHttpResource(contentTypeHeader)
                this.burpTags = emptyList()
                this.passiveFindings = emptyList()
                this.notes = null
                
                this.canonicalId = canonicalId
                this.firstSeen = Instant.now().toString()
                this.lastSeen = Instant.now().toString()
                this.observationCount = 1
                
                this.provenance = com.user404.applicationmapper.model.ProvenanceInfo().apply {
                    val toolType = toolSource.toolType().name.lowercase(Locale.ROOT)
                    addToolType(toolType)
                    addDiscoveryMethod(toolType)
                    if (isNativeSource(toolType)) addNativeSource(toolType) else addDerivedSource(toolType)
                    firstDiscoveredBy = toolType
                    lastDiscoveredBy = toolType
                }
                
                this.relationships = com.user404.applicationmapper.model.RelationshipInfo()
                
                this.requestMetadata = buildRequestMetadata(request)
                this.responseMetadata = buildResponseMetadata(response)
            }
            .build()
    }

    // ================================================================
    // AUDIT ISSUE HANDLER - Passive findings
    // ================================================================

    override fun handleNewAuditIssue(auditIssue: AuditIssue) {
        val baseUrl = auditIssue.baseUrl()
        val issueHost = parseRequestUri(baseUrl)?.host?.let(::normalizeHostname) ?: return

        val state = lifecycleManager.getHostState(issueHost) ?: return
        if (!lifecycleManager.isHostActive(issueHost)) return

        recordAuditIssue(state, auditIssue, "passive-analysis")
    }

    private fun recordAuditIssue(
        state: HostState,
        issue: AuditIssue,
        source: String
    ) {
        val baseUrl = issue.baseUrl()
        val uri = parseRequestUri(baseUrl)

        val key = baseUrl + "|" + issue.name()
        if (!harvestedIssueKeys.add(key)) return

        val finding = com.user404.applicationmapper.model.PassiveFinding(
            name = issue.name(),
            severity = issue.severity().name.lowercase(Locale.ROOT),
            confidence = issue.confidence().name.lowercase(Locale.ROOT),
            detail = issue.detail(),
            remediation = issue.remediation(),
            cwe = null,
            source = source,
            baseUrl = baseUrl,
            burpTool = "scanner",
            burpIssue = true
        )

        val canonicalId = CanonicalIdentity.generate(
            host = state.host,
            url = baseUrl,
            method = null,
            resourceType = "audit-issue"
        )

        val record = com.user404.applicationmapper.model.MappingRecord.builder()
            .apply {
                this.host = state.host
                this.url = baseUrl
                this.scheme = uri?.scheme
                this.port = effectivePort(uri)
                this.method = null
                this.status = null
                this.mimeType = null
                this.contentLength = null
                this.redirectLocation = null
                this.redirectChain = emptyList()
                this.parameterNames = emptyList()
                this.parameterLocations = emptyMap()
                this.formAction = null
                this.formMethod = null
                this.cookieNames = emptyList()
                this.contentType = null
                this.source = source
                this.discoveredFrom = null
                this.parentUrl = null
                this.jsSource = null
                this.apiSource = null
                this.resourceType = "audit-issue"
                this.burpTags = emptyList()
                this.passiveFindings = listOf(finding)
                this.notes = null
                this.canonicalId = canonicalId
                this.firstSeen = Instant.now().toString()
                this.lastSeen = Instant.now().toString()
                this.observationCount = 1
                this.provenance = com.user404.applicationmapper.model.ProvenanceInfo().apply {
                    addNativeSource("scanner")
                    addToolType("scanner")
                    addDiscoveryMethod("passive-analysis")
                    firstDiscoveredBy = "scanner"
                    lastDiscoveredBy = "scanner"
                }
                this.relationships = com.user404.applicationmapper.model.RelationshipInfo()
            }
            .build()

        state.upsert(record)
    }

    // ================================================================
    // NATIVE BURP CRAWLING
    // ================================================================

    /**
     * Start Burp's native Scanner crawl for a host.
     */
    fun startNativeCrawl(hostInput: String): Crawl? {
        val host = normalizeHostname(hostInput) ?: return null

        if (!lifecycleManager.isHostActive(host)) {
            api.logging().logToOutput("[Application Mapper] Cannot start crawl; host not active: $host")
            return null
        }

        val existing = crawlTasks[host]
        if (existing != null) return existing

        val seedUrl = "https://$host/"
        val configuration = CrawlConfiguration.crawlConfiguration(seedUrl)

        val scannerInstance = scanner ?: run {
            api.logging().logToError("[Application Mapper] Burp Scanner API unavailable")
            return null
        }

        val crawl = runCatching {
            scannerInstance.startCrawl(configuration)
        }.onFailure { error ->
            api.logging().logToError("[Application Mapper] Failed to start native crawl for $host: ${error.message}")
        }.getOrNull() ?: return null

        crawlTasks[host] = crawl

        api.logging().logToOutput("[Application Mapper] NATIVE CRAWL STARTED: host=$host seed=$seedUrl")

        // Initial Site Map harvest
        harvestSiteMapForHost(host)

        return crawl
    }

    /**
     * Harvest Site Map for a host.
     */
    fun harvestSiteMapForHost(hostInput: String) {
        val host = normalizeHostname(hostInput) ?: return
        val state = lifecycleManager.getHostState(host) ?: return

        val items = siteMap.requestResponses()
        var added = 0

        items.forEach { item ->
            val request = item.request()
            val itemHost = parseRequestUri(request.url())?.host?.let(::normalizeHostname) ?: return@forEach

            if (itemHost != host) return@forEach

            val key = siteMapIdentity(request.url(), request.method())
            if (!harvestedSiteMapKeys.add(key)) return@forEach

            val response = item.response()
            val toolSource = request.toolSource()

            val record = buildSiteMapRecord(host, request, response, toolSource)
            state.upsert(record)
            added++
        }

        api.logging().logToOutput("[Application Mapper] SITE MAP HARVEST: host=$host added=$added")
        harvestSiteMapIssuesForHost(host)
    }

    private fun buildSiteMapRecord(
        host: String,
        request: burp.api.montoya.http.message.requests.HttpRequest,
        response: burp.api.montoya.http.message.responses.HttpResponse?,
        toolSource: burp.api.montoya.core.ToolSource
    ): com.user404.applicationmapper.model.MappingRecord {
        val uri = parseRequestUri(request.url())
        val canonicalId = CanonicalIdentity.generate(
            host = host,
            url = request.url(),
            method = request.method(),
            resourceType = classifyHttpResource(response?.header("Content-Type")?.value())
        )

        return com.user404.applicationmapper.model.MappingRecord.builder()
            .apply {
                this.host = host
                this.url = request.url()
                this.scheme = uri?.scheme
                this.port = effectivePort(uri)
                this.method = request.method()
                this.status = response?.statusCode()?.takeIf { it > 0 }

                val contentTypeHeader = response?.header("Content-Type")?.value()
                this.mimeType = normalizeMimeType(contentTypeHeader)
                this.contentLength = response?.header("Content-Length")?.value()?.toLongOrNull()
                this.redirectLocation = response?.header("Location")?.value()
                this.redirectChain = emptyList()

                val parameters = request.parameters()
                parameters.forEach { parameter ->
                    val name = parameter.name()
                    if (name.isNotBlank()) {
                        this.parameterNames.add(name)
                        val location = parameter.type().name.lowercase(Locale.ROOT)
                        this.parameterLocations.getOrPut(name) { java.util.concurrent.ConcurrentHashMap.newKeySet() }.add(location)
                    }
                }

                this.formAction = null
                this.formMethod = null

                this.cookieNames.addAll(if (response != null) {
                    collectCookieNames(request, response)
                } else {
                    collectRequestCookieNames(request)
                })

                this.contentType = contentTypeHeader
                this.source = "site-map"
                this.discoveredFrom = null
                this.parentUrl = null
                this.jsSource = null
                this.apiSource = null
                this.resourceType = classifyHttpResource(contentTypeHeader)
                this.burpTags = emptyList()
                this.passiveFindings = emptyList()
                this.notes = null
                this.canonicalId = canonicalId
                this.firstSeen = Instant.now().toString()
                this.lastSeen = Instant.now().toString()
                this.observationCount = 1
                this.provenance = com.user404.applicationmapper.model.ProvenanceInfo().apply {
                    addNativeSource("site-map")
                    addToolType("site-map")
                    addDiscoveryMethod("site-map")
                    firstDiscoveredBy = "site-map"
                    lastDiscoveredBy = "site-map"
                }
                this.relationships = com.user404.applicationmapper.model.RelationshipInfo()
                this.requestMetadata = buildRequestMetadata(request)
                this.responseMetadata = response?.let { buildResponseMetadata(it) }
            }
            .build()
    }

    private fun harvestSiteMapIssuesForHost(hostInput: String) {
        val host = normalizeHostname(hostInput) ?: return
        val state = lifecycleManager.getHostState(host) ?: return

        val issues = siteMap.issues()
        issues.forEach { issue ->
            val baseUrl = issue.baseUrl()
            val issueHost = parseRequestUri(baseUrl)?.host?.let(::normalizeHostname) ?: return@forEach

            if (issueHost != host) return@forEach

            recordAuditIssue(state, issue, "passive-analysis")
        }
    }

    private fun siteMapIdentity(url: String, method: String): String {
        return method.uppercase(Locale.ROOT) + "|" + url
    }

    // ================================================================
    // REQUEST EXECUTION ENGINE
    // ================================================================

    fun isRequestExecutionEngineAvailable(): Boolean {
        return try {
            api.http().createRequestEngine()
            api.logging().logToOutput("[Application Mapper] RequestExecutionEngine AVAILABLE")
            true
        } catch (e: NoSuchMethodError) {
            api.logging().logToError("[Application Mapper] RequestExecutionEngine NOT available in current Burp runtime")
            false
        } catch (e: UnsupportedOperationException) {
            api.logging().logToError("[Application Mapper] RequestExecutionEngine not supported: ${e.message}")
            false
        } catch (e: RuntimeException) {
            api.logging().logToError("[Application Mapper] RequestExecutionEngine failed to initialize: ${e.message}")
            false
        }
    }

    fun queueMapperRequest(hostInput: String, request: burp.api.montoya.http.message.requests.HttpRequest, label: String = ""): Boolean {
        val host = normalizeHostname(hostInput) ?: return false

        if (!lifecycleManager.isHostActive(host)) {
            api.logging().logToOutput("[Application Mapper] REQUEST REJECTED: host not active: $host")
            return false
        }

        val requestHost = parseRequestUri(request.url())?.host?.let(::normalizeHostname) ?: return false
        val requestScopeUrl = "https://$requestHost/"

        if (!isBurpInScope(requestScopeUrl)) {
            api.logging().logToOutput("[Application Mapper] THIRD-PARTY REQUEST REJECTED: ${request.url()}")
            return false
        }

        val engine = requestEngines.computeIfAbsent(host) {
            createMapperRequestEngine(host)
        } ?: return false

        runCatching {
            engine.queue(request, label)
        }.onFailure { error ->
            api.logging().logToError("[Application Mapper] Failed to queue request: ${error.message}")
            return@runCatching false
        }

        api.logging().logToOutput("[Application Mapper] REQUEST QUEUED: host=$host label=$label url=${request.url()}")
        return true
    }

    fun startMapperRequestExecution(hostInput: String, timeoutMillis: Long = 30_000L): burp.api.montoya.http.execution.RequestExecution? {
        val host = normalizeHostname(hostInput) ?: return null
        if (!lifecycleManager.isHostActive(host)) return null

        val engine = requestEngines[host] ?: return null

        val execution = try {
            engine.sendAll(
                { result, liveExecution ->
                    handleMapperRequestResult(host, result, liveExecution)
                    burp.api.montoya.http.execution.Retention.KEEP
                },
                java.time.Duration.ofMillis(timeoutMillis)
            )
        } catch (e: IllegalStateException) {
            api.logging().logToError("[Application Mapper] RequestExecutionEngine already started for $host: ${e.message}")
            requestEngines.remove(host)
            return null
        } catch (e: RuntimeException) {
            api.logging().logToError("[Application Mapper] RequestExecutionEngine failed for $host: ${e.message}")
            requestEngines.remove(host)
            return null
        }

        execution.lifetime().onComplete { finalResult ->
            api.logging().logToOutput("[Application Mapper] REQUEST ENGINE FINISHED: host=$host results=${finalResult.results().size}")
            requestEngines.remove(host)
        }

        return execution
    }

    private fun createMapperRequestEngine(host: String): burp.api.montoya.http.execution.RequestExecutionEngine? {
        val resourcePool = burp.api.montoya.http.execution.ResourcePool.resourcePool()
            .withConcurrentRequestLimit(10)
            .withMaxRetries(1)
            .withThrottle(java.time.Duration.ZERO)

        val options = burp.api.montoya.http.execution.RequestEngineOptions.requestEngineOptions()
            .withName("Application Mapper - $host")
            .withResourcePool(resourcePool)

        return try {
            api.http().createRequestEngine(options)
        } catch (e: NoSuchMethodError) {
            api.logging().logToError("[Application Mapper] Current Burp runtime does not provide RequestExecutionEngine(RequestEngineOptions)")
            null
        } catch (e: RuntimeException) {
            api.logging().logToError("[Application Mapper] Failed to create RequestExecutionEngine for $host: ${e.message}")
            null
        }
    }

    private fun handleMapperRequestResult(
        host: String,
        result: burp.api.montoya.http.execution.RequestResult,
        execution: burp.api.montoya.http.execution.RequestExecution
    ) {
        val status = result.status()
        val label = result.label()

        when (status) {
            burp.api.montoya.http.execution.RequestStatus.RESPONDED -> {
                api.logging().logToOutput("[Application Mapper] REQUEST COMPLETED: host=$host label=$label")
            }
            else -> {
                api.logging().logToOutput("[Application Mapper] REQUEST RESULT: host=$host label=$label status=$status")
            }
        }
    }

    // ================================================================
    // HOST LIFECYCLE MANAGEMENT
    // ================================================================

    fun startHost(hostInput: String) {
        val host = normalizeHostname(hostInput) ?: return
        if (!lifecycleManager.addInitialHost(host)) return
        api.logging().logToOutput("[Application Mapper] INITIAL HOST QUEUED: $host")
    }

    fun startHosts(hosts: List<String>) {
        hosts.forEach { startHost(it) }
    }

    fun processNextHost(): Boolean {
        val host = lifecycleManager.nextQueuedHost() ?: return false
        
        val state = lifecycleManager.beginHost(host) ?: return false
        lifecycleManager.setProcessing(host)

        val crawl = startNativeCrawl(host)
        if (crawl == null) {
            lifecycleManager.failHost(host)
            return false
        }

        return true
    }

    fun finalizeHost(hostInput: String): Boolean {
        val host = normalizeHostname(hostInput) ?: return false
        
        // Final Site Map harvest
        harvestSiteMapForHost(host)
        
        val result = lifecycleManager.finalizeHost(host)
        
        // Flush persistence
        lifecycleManager.getHostState(host)?.flush()
        
        return result
    }

    fun stopAll() {
        lifecycleManager.stopAll()
        crawlTasks.values.forEach { it.cancel() }
        requestEngines.values.forEach { it.close() }
        persistence.close()
    }

    // ================================================================
    // OUTPUT DIRECTORY MANAGEMENT
    // ================================================================

    fun setOutputDirectory(path: String) {
        val normalized = Path.of(path).toAbsolutePath().normalize()
        if (normalized == outputRoot) return

        hostStates.values.forEach { runCatching { it.close() } }
        hostStates.clear()

        outputRoot = normalized
        // Reinitialize persistence with new root
        // Note: In practice, you'd recreate the persistence object
    }

    // ================================================================
    // UTILITY METHODS
    // ================================================================

    private fun shouldExtractContent(record: com.user404.applicationmapper.model.MappingRecord): Boolean {
        val ct = record.contentType?.lowercase(Locale.ROOT) ?: ""
        return ct.contains("html") || ct.contains("javascript") || ct.contains("json") || ct.contains("css") || ct.contains("xml")
    }

    private fun enhanceWithTechnology(record: com.user404.applicationmapper.model.MappingRecord, response: burp.api.montoya.http.message.responses.HttpResponse) {
        val techInfo = technologyDetector.detectFromResponse(record)
        if (techInfo != null) {
            // We need to merge this back - for now, just log
            if (techInfo.technologies.isNotEmpty()) {
                api.logging().logToOutput("[Application Mapper] Technology detected for ${record.url}: ${techInfo.technologies.map { it.name }.joinToString(", ")}")
            }
        }
    }

    private fun sourceForNativeTool(toolType: ToolType): String? {
        return when (toolType) {
            ToolType.PROXY -> "proxy"
            ToolType.SCANNER -> "scanner"
            ToolType.REPEATER -> "repeater"
            ToolType.INTRUDER -> "intruder"
            ToolType.EXTENSIONS -> "extension"
            ToolType.TARGET -> "target"
            ToolType.LOGGER -> "logger"
            ToolType.SEQUENCER -> "sequencer"
            ToolType.DECODER -> "decoder"
            ToolType.COMPARER -> "comparer"
            ToolType.ORGANIZER -> "organizer"
            ToolType.RECORDED_LOGIN_REPLAYER -> "recorded-login-replayer"
            ToolType.BURP_AI -> "burp-ai"
            ToolType.SUITE -> "suite"
            else -> toolType.name.lowercase(Locale.ROOT)
        }
    }

    private fun isNativeSource(toolType: String): Boolean {
        return toolType in setOf("proxy", "scanner", "repeater", "intruder", "target", "site-map", "extension")
    }

    private fun classifyHttpResource(contentType: String?): String {
        val type = contentType?.lowercase(Locale.ROOT)?.substringBefore(';')?.trim() ?: return "http"
        return when {
            type.contains("javascript") -> "javascript"
            type == "text/html" || type == "application/xhtml+xml" -> "html"
            type.contains("json") -> "json"
            type.contains("graphql") -> "graphql"
            type.contains("xml") -> "xml"
            type.contains("css") -> "stylesheet"
            type.startsWith("image/") -> "image"
            type.startsWith("font/") -> "font"
            type.contains("websocket") -> "websocket"
            else -> "http"
        }
    }

    private fun normalizeMimeType(contentType: String?): String? {
        return contentType?.substringBefore(';')?.trim()?.takeIf { it.isNotBlank() }
    }

    private fun effectivePort(uri: ParsedUri?): Int? {
        if (uri == null) return null
        if (uri.port > 0) return uri.port
        return when (uri.scheme.lowercase(Locale.ROOT)) {
            "https", "wss" -> 443
            "http", "ws" -> 80
            else -> null
        }
    }

    private fun parseRequestUri(url: String?): ParsedUri? {
        if (url.isNullOrBlank()) return null
        return try {
            val uri = java.net.URI(url)
            val host = uri.host ?: return@try null
            val scheme = uri.scheme ?: return@try null
            ParsedUri(scheme = scheme, host = host, port = uri.port)
        } catch (e: Exception) { null }
    }

    private fun normalizeHostname(input: String?): String? {
        return input?.trim()?.lowercase(Locale.ROOT)
            ?.removePrefix("https://")?.removePrefix("http://")
            ?.substringBefore('/')
            ?.substringBefore(':')
            ?.trim('.')
            ?.takeIf { it.isNotBlank() && !it.contains(' ') }
    }

    private fun collectRequestCookieNames(request: burp.api.montoya.http.message.requests.HttpRequest): List<String> {
        val names = ConcurrentHashMap.newKeySet<String>()
        request.headers()
            .filter { it.name().equals("Cookie", ignoreCase = true) }
            .forEach { header ->
                header.value()
                    .split(';')
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .forEach { pair ->
                        val name = pair.substringBefore('=').trim()
                        if (name.isNotEmpty()) names.add(name)
                    }
            }
        return names.toList()
    }

    private fun collectCookieNames(
        request: burp.api.montoya.http.message.requests.HttpRequest,
        response: burp.api.montoya.http.message.responses.HttpResponse
    ): List<String> {
        val names = ConcurrentHashMap.newKeySet<String>()
        names.addAll(collectRequestCookieNames(request))
        response.cookies().forEach { cookie ->
            val name = cookie.name()
            if (name.isNotBlank()) names.add(name)
        }
        return names.toList()
    }

    private fun extractRedirectChain(response: burp.api.montoya.http.message.responses.HttpResponse): List<String> {
        val location = response.header("Location")?.value()
        return if (location != null) listOf(location) else emptyList()
    }

    private fun buildRequestMetadata(request: burp.api.montoya.http.message.requests.HttpRequest): com.user404.applicationmapper.model.MappingRecord.RequestMetadata {
        val headers = mutableMapOf<String, MutableList<String>>()
        request.headers().forEach { header ->
            headers.getOrPut(header.name()) { mutableListOf() }.add(header.value())
        }
        val cookies = collectRequestCookieNames(request)
        return com.user404.applicationmapper.model.MappingRecord.RequestMetadata(
            headers = headers.mapValues { (_, v) -> v.toList() },
            cookies = cookies,
            bodySize = request.body()?.size.toLong(),
            bodyHash = request.body()?.let { computeHash(it) }
        )
    }

    private fun buildResponseMetadata(response: burp.api.montoya.http.message.responses.HttpResponse): com.user404.applicationmapper.model.MappingRecord.ResponseMetadata {
        val headers = mutableMapOf<String, MutableList<String>>()
        response.headers().forEach { header ->
            headers.getOrPut(header.name()) { mutableListOf() }.add(header.value())
        }
        val cookies = response.cookies().map { it.name() }.filter { it.isNotBlank() }.toList()
        return com.user404.applicationmapper.model.MappingRecord.ResponseMetadata(
            headers = headers.mapValues { (_, v) -> v.toList() },
            cookies = cookies,
            bodySize = response.body()?.size.toLong(),
            bodyHash = response.body()?.let { computeHash(it) },
            encoding = response.header("Content-Encoding")?.value()
        )
    }

    private fun computeHash(bytes: ByteArray): String {
        return java.security.MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }

    private fun isBurpInScope(url: String): Boolean {
        return runCatching { burpScope.isInScope(url) }.getOrDefault(false)
    }

    override fun close() {
        stopAll()
        executorService.shutdown()
    }

    data class ParsedUri(val scheme: String, val host: String, val port: Int)
}