package com.user404.applicationmapper.ui

import burp.api.montoya.MontoyaApi
import burp.api.montoya.ui.UserInterface
import burp.api.montoya.ui.contextmenu.ContextMenuItemsProvider
import burp.api.montoya.ui.contextmenu.InvocationSource
import burp.api.montoya.ui.contextmenu.InvocationType
import burp.api.montoya.ui.editor.extension.EditorCreationContext
import burp.api.montoya.ui.editor.extension.ExtensionProvidedHttpRequestEditor
import burp.api.montoya.ui.editor.extension.HttpRequestEditorProvider
import burp.api.montoya.ui.menu.Menu
import burp.api.montoya.ui.menu.MenuBar
import burp.api.montoya.ui.menu.MenuItem
import burp.api.montoya.ui.settings.SettingsPanel
import burp.api.montoya.ui.settings.SettingsPanelBuilder
import burp.api.montoya.ui.swing.SwingUtils
import com.user404.applicationmapper.core.MapperCore
import javax.swing.*
import java.awt.*
import java.awt.event.ActionEvent
import java.nio.file.Path
import java.nio.file.Paths
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Application Mapper UI.
 * 
 * Provides:
 * - Main configuration panel
 * - Host management (add/remove/process hosts)
 * - Real-time statistics
 * - Output directory configuration
 * - Context menu integration
 * - Settings persistence
 */
class MapperUI(
    private val api: MontoyaApi,
    private val core: MapperCore
) {

    private val panel: JPanel = JPanel(BorderLayout())
    private val statsPanel: JPanel = JPanel(GridLayout(0, 2, 5, 5))
    private val logArea: JTextArea = JTextArea()
    private val hostListModel: DefaultListModel<String> = DefaultListModel()
    private val hostList: JList<String> = JList(hostListModel)
    private val outputDirField: JTextField = JTextField()
    private val isProcessing = AtomicBoolean(false)
    private var updateTimer: javax.swing.Timer? = null

    init {
        buildUI()
        registerUI()
        startStatusUpdates()
    }

    private fun buildUI() {
        panel.border = BorderFactory.createEmptyBorder(10, 10, 10, 10)

        // Top: Configuration
        val configPanel = buildConfigPanel()
        
        // Center: Host management
        val hostPanel = buildHostPanel()
        
        // Bottom: Statistics and Log
        val bottomPanel = buildBottomPanel()

        val splitPane = JSplitPane(JSplitPane.VERTICAL_SPLIT, hostPanel, bottomPanel)
        splitPane.resizeWeight = 0.6
        splitPane.dividerLocation = 400

        panel.add(configPanel, BorderLayout.NORTH)
        panel.add(splitPane, BorderLayout.CENTER)
    }

    private fun buildConfigPanel(): JPanel {
        val configPanel = JPanel()
        configPanel.layout = BoxLayout(configPanel, BoxLayout.Y_AXIS)
        configPanel.border = BorderFactory.createTitledBorder("Configuration")

        // Output directory
        val dirPanel = JPanel(FlowLayout(FlowLayout.LEFT))
        dirPanel.add(JLabel("Output Directory:"))
        outputDirField.text = core.outputRoot.toString()
        outputDirField.columns = 40
        outputDirField.isEditable = false
        dirPanel.add(outputDirField)
        
        val browseBtn = JButton("Browse...")
        browseBtn.addActionListener { chooseOutputDirectory() }
        dirPanel.add(browseBtn)
        
        val applyBtn = JButton("Apply")
        applyBtn.addActionListener { applyOutputDirectory() }
        dirPanel.add(applyBtn)

        configPanel.add(dirPanel)

        // Subdomain seed file
        val seedPanel = JPanel(FlowLayout(FlowLayout.LEFT))
        seedPanel.add(JLabel("Subdomains File:"))
        val seedField = JTextField(30)
        seedField.isEditable = false
        seedPanel.add(seedField)
        
        val seedBrowseBtn = JButton("Load subdomains.txt")
        seedBrowseBtn.addActionListener { loadSubdomainsFile(seedField) }
        seedPanel.add(seedBrowseBtn)
        
        configPanel.add(seedPanel)

        return configPanel
    }

    private fun buildHostPanel(): JPanel {
        val hostPanel = JPanel(BorderLayout())
        hostPanel.border = BorderFactory.createTitledBorder("Host Management")

        // Toolbar
        val toolbar = JToolBar()
        toolbar.floatable = false

        val addHostBtn = JButton("Add Host")
        addHostBtn.addActionListener { addHostDialog() }
        toolbar.add(addHostBtn)

        val removeHostBtn = JButton("Remove Host")
        removeHostBtn.addActionListener { removeSelectedHost() }
        toolbar.add(removeHostBtn)

        val processBtn = JButton("Process Next")
        processBtn.addActionListener { processNextHost() }
        toolbar.add(processBtn)

        val processAllBtn = JButton("Process All Queued")
        processAllBtn.addActionListener { processAllQueued() }
        toolbar.add(processAllBtn)

        val stopBtn = JButton("Stop All")
        stopBtn.addActionListener { stopAll() }
        toolbar.add(stopBtn)

        toolbar.addSeparator()

        val refreshBtn = JButton("Refresh")
        refreshBtn.addActionListener { refreshHostList() }
        toolbar.add(refreshBtn)

        hostPanel.add(toolbar, BorderLayout.NORTH)

        // Host list
        hostList.selectionMode = ListSelectionModel.MULTIPLE_INTERVAL_SELECTION
        val scrollPane = JScrollPane(hostList)
        scrollPane.preferredSize = Dimension(400, 300)
        hostPanel.add(scrollPane, BorderLayout.CENTER)

        // Status bar
        val statusPanel = JPanel(FlowLayout(FlowLayout.LEFT))
        val statusLabel = JLabel("Ready")
        statusPanel.add(statusLabel)
        hostPanel.add(statusPanel, BorderLayout.SOUTH)

        // Load existing hosts
        refreshHostList()

        return hostPanel
    }

    private fun buildBottomPanel(): JPanel {
        val bottomPanel = JPanel(BorderLayout())

        // Statistics
        statsPanel.border = BorderFactory.createTitledBorder("Statistics")
        bottomPanel.add(statsPanel, BorderLayout.NORTH)

        // Log area
        val logPanel = JPanel(BorderLayout())
        logPanel.border = BorderFactory.createTitledBorder("Activity Log")
        logArea.isEditable = false
        logArea.font = Font(Font.MONOSPACED, Font.PLAIN, 11)
        val logScroll = JScrollPane(logArea)
        logScroll.preferredSize = Dimension(400, 200)
        logPanel.add(logScroll, BorderLayout.CENTER)
        bottomPanel.add(logPanel, BorderLayout.CENTER)

        return bottomPanel
    }

    private fun registerUI() {
        // Register settings panel
        val settingsPanel = buildSettingsPanel()
        api.userInterface().registerSettingsPanel(settingsPanel)

        // Register menu bar items
        api.userInterface().registerMenuBar(buildMenuBar())

        // Register context menu items
        api.userInterface().registerContextMenuItemsProvider(MapperContextMenuProvider(core))
    }

    private fun buildSettingsPanel(): SettingsPanel {
        return SettingsPanelBuilder.settingsPanel()
            .withTitle("Application Mapper")
            .withComponent(panel)
            .build()
    }

    private fun buildMenuBar(): MenuBar {
        return MenuBar.menuBar()
            .withMenu(
                Menu.menu("Application Mapper")
                    .withItem(MenuItem.item("Add Host...").withActionListener { addHostDialog() })
                    .withItem(MenuItem.item("Load subdomains.txt...").withActionListener { loadSubdomainsFile(JTextField()) })
                    .withSeparator()
                    .withItem(MenuItem.item("Process Next Host").withActionListener { processNextHost() })
                    .withItem(MenuItem.item("Process All Queued").withActionListener { processAllQueued() })
                    .withSeparator()
                    .withItem(MenuItem.item("Stop All").withActionListener { stopAll() })
                    .withSeparator()
                    .withItem(MenuItem.item("Open Output Directory").withActionListener { openOutputDirectory() })
            )
            .build()
    }

    private fun chooseOutputDirectory() {
        val chooser = JFileChooser()
        chooser.fileSelectionMode = JFileChooser.DIRECTORIES_ONLY
        chooser.currentDirectory = core.outputRoot.toFile()
        if (chooser.showOpenDialog(panel) == JFileChooser.APPROVE_OPTION) {
            val selected = chooser.selectedFile.toPath()
            outputDirField.text = selected.toString()
        }
    }

    private fun applyOutputDirectory() {
        val path = Paths.get(outputDirField.text.trim())
        if (Files.exists(path) && Files.isDirectory(path)) {
            core.setOutputDirectory(path.toString())
            log("Output directory changed to: $path")
        } else {
            JOptionPane.showMessageDialog(panel, "Invalid directory", "Error", JOptionPane.ERROR_MESSAGE)
        }
    }

    private fun loadSubdomainsFile(seedField: JTextField) {
        val chooser = JFileChooser()
        chooser.fileFilter = javax.swing.filechooser.FileNameExtensionFilter("Text files", "txt")
        if (chooser.showOpenDialog(panel) == JFileChooser.APPROVE_OPTION) {
            val file = chooser.selectedFile
            seedField.text = file.absolutePath
            loadSubdomainsFromFile(file.toPath())
        }
    }

    private fun loadSubdomainsFromFile(path: Path) {
        try {
            val lines = Files.readAllLines(path)
            val hosts = lines.map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("#") }
            core.startHosts(hosts)
            log("Loaded ${hosts.size} hosts from $path")
            refreshHostList()
        } catch (e: Exception) {
            log("Failed to load subdomains: ${e.message}")
            JOptionPane.showMessageDialog(panel, "Failed to load subdomains: ${e.message}", "Error", JOptionPane.ERROR_MESSAGE)
        }
    }

    private fun addHostDialog() {
        val dialog = JDialog(SwingUtilities.getWindowAncestor(panel), "Add Host", true)
        dialog.layout = BorderLayout()
        dialog.setSize(400, 150)
        dialog.locationRelativeTo = panel

        val inputPanel = JPanel(BorderLayout(5, 5))
        inputPanel.border = BorderFactory.createEmptyBorder(10, 10, 10, 10)
        inputPanel.add(JLabel("Hostname (e.g., example.com):"), BorderLayout.NORTH)
        
        val hostField = JTextField()
        inputPanel.add(hostField, BorderLayout.CENTER)

        val buttonPanel = JPanel(FlowLayout(FlowLayout.RIGHT))
        val okBtn = JButton("Add")
        okBtn.addActionListener {
            val host = hostField.text.trim()
            if (host.isNotBlank()) {
                core.startHost(host)
                log("Added host: $host")
                refreshHostList()
                dialog.dispose()
            }
        }
        val cancelBtn = JButton("Cancel")
        cancelBtn.addActionListener { dialog.dispose() }
        buttonPanel.add(okBtn)
        buttonPanel.add(cancelBtn)

        dialog.add(inputPanel, BorderLayout.CENTER)
        dialog.add(buttonPanel, BorderLayout.SOUTH)
        dialog.isVisible = true
    }

    private fun removeSelectedHost() {
        val selected = hostList.selectedValuesList()
        if (selected.isEmpty()) return

        val confirm = JOptionPane.showConfirmDialog(
            panel,
            "Remove ${selected.size} selected host(s)?",
            "Confirm Removal",
            JOptionPane.YES_NO_OPTION
        )
        if (confirm == JOptionPane.YES_OPTION) {
            // Note: We can't actually remove from processed set, but we can remove from queue
            selected.forEach { host ->
                // Would need to add removeHost method to lifecycle manager
                log("Host removal requested: $host (not fully implemented)")
            }
            refreshHostList()
        }
    }

    private fun processNextHost() {
        if (isProcessing.getAndSet(true)) return
        
        api.task().runAsync {
            try {
                val result = core.processNextHost()
                SwingUtils.invokeLater {
                    if (result) {
                        log("Started processing next host")
                    } else {
                        log("No queued hosts to process")
                    }
                    refreshHostList()
                    updateStatistics()
                }
            } finally {
                isProcessing.set(false)
            }
        }
    }

    private fun processAllQueued() {
        if (isProcessing.getAndSet(true)) return

        api.task().runAsync {
            try {
                var processed = 0
                while (core.lifecycleManager.queuedHostCount() > 0) {
                    val result = core.processNextHost()
                    if (!result) break
                    processed++
                    Thread.sleep(1000) // Small delay between hosts
                }
                SwingUtils.invokeLater {
                    log("Processed $processed hosts")
                    refreshHostList()
                    updateStatistics()
                }
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            } finally {
                isProcessing.set(false)
            }
        }
    }

    private fun stopAll() {
        core.stopAll()
        log("Stopped all active hosts")
        refreshHostList()
        updateStatistics()
    }

    private fun refreshHostList() {
        SwingUtils.invokeLater {
            hostListModel.clear()
            val hosts = core.lifecycleManager.getKnownHosts()
            hosts.forEach { host ->
                val state = core.lifecycleManager.getLifecycleState(host)
                val prefix = when (state) {
                    com.user404.applicationmapper.core.HostLifecycleState.ACTIVE -> "[ACTIVE] "
                    com.user404.applicationmapper.core.HostLifecycleState.PROCESSING -> "[PROCESSING] "
                    com.user404.applicationmapper.core.HostLifecycleState.QUEUED -> "[QUEUED] "
                    com.user404.applicationmapper.core.HostLifecycleState.COMPLETED -> "[DONE] "
                    com.user404.applicationmapper.core.HostLifecycleState.FAILED -> "[FAILED] "
                    else -> ""
                }
                hostListModel.addElement("$prefix$host")
            }
        }
    }

    private fun updateStatistics() {
        SwingUtils.invokeLater {
            statsPanel.removeAll()
            
            val queued = core.lifecycleManager.getQueuedCount()
            val active = core.lifecycleManager.getActiveCount()
            val processed = core.lifecycleManager.getProcessedCount()
            val discovered = core.lifecycleManager.discoveredHostCount()
            
            addStatRow("Queued Hosts", queued.toString())
            addStatRow("Active Hosts", active.toString())
            addStatRow("Processed Hosts", processed.toString())
            addStatRow("Discovered Hosts", discovered.toString())
            
            // Total records across all hosts
            var totalRecords = 0
            core.lifecycleManager.getKnownHosts().forEach { host ->
                core.lifecycleManager.getHostState(host)?.let { state ->
                    totalRecords += state.getRecordCount()
                }
            }
            addStatRow("Total Records", totalRecords.toString())
            
            statsPanel.revalidate()
            statsPanel.repaint()
        }
    }

    private fun addStatRow(label: String, value: String) {
        statsPanel.add(JLabel(label)).apply { horizontalAlignment = SwingConstants.RIGHT }
        statsPanel.add(JLabel(value)).apply { 
            horizontalAlignment = SwingConstants.LEFT
            font = Font(Font.MONOSPACED, Font.BOLD, 12)
        }
    }

    private fun startStatusUpdates() {
        updateTimer = javax.swing.Timer(5000) { _ ->
            updateStatistics()
        }
        updateTimer.start()
    }

    private fun openOutputDirectory() {
        try {
            java.awt.Desktop.getDesktop().open(core.outputRoot.toFile())
        } catch (e: Exception) {
            log("Failed to open output directory: ${e.message}")
        }
    }

    fun log(message: String) {
        SwingUtils.invokeLater {
            val timestamp = java.time.LocalTime.now().toString().substring(0, 8)
            logArea.append("[$timestamp] $message\n")
            logArea.setCaretPosition(logArea.document.length)
        }
    }

    fun shutdown() {
        updateTimer?.stop()
    }
}

/**
 * Context menu provider for right-click integration.
 */
class MapperContextMenuProvider(
    private val core: MapperCore
) : ContextMenuItemsProvider {

    override fun provideMenuItems(invocationSource: InvocationSource): List<MenuItem> {
        return when (invocationSource.invocationType()) {
            InvocationType.PROXY_HISTORY,
            InvocationType.TARGET_SITE_MAP_TABLE,
            InvocationType.MESSAGE_EDITOR_REQUEST,
            InvocationType.REPEATER_REQUEST -> {
                val items = mutableListOf<MenuItem>()
                
                items.add(MenuItem.item("Map with Application Mapper").withActionListener {
                    // Get selected requests and add their hosts to mapping
                    invocationSource.selectedMessages().forEach { message ->
                        val request = message.request()
                        if (request != null) {
                            val host = java.net.URI(request.url()).host
                            if (host != null) {
                                core.startHost(host)
                            }
                        }
                    }
                })
                
                items.add(MenuItem.item("Add Host to Mapping Queue").withActionListener {
                    invocationSource.selectedMessages().forEach { message ->
                        val request = message.request()
                        if (request != null) {
                            val host = java.net.URI(request.url()).host
                            if (host != null) {
                                core.startHost(host)
                            }
                        }
                    }
                })
                
                items
            }
            else -> emptyList()
        }
    }
}