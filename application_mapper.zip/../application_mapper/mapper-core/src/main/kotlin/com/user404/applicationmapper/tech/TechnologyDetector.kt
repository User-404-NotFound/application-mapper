package com.user404.applicationmapper.tech

import com.user404.applicationmapper.model.MappingRecord
import com.user404.applicationmapper.model.Technology
import com.user404.applicationmapper.model.TechnologyInfo
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Pattern

/**
 * Technology detection engine.
 * 
 * Integrates with BurpMax's passive detection capabilities and adds
 * additional fingerprinting based on HTTP headers, cookies, body content.
 * 
 * Only records technology when there is evidence - no guessing.
 */
class TechnologyDetector {

    // Server headers
    private val serverPatterns = mapOf(
        "Apache" to Pattern.compile("(?i)Apache"),
        "nginx" to Pattern.compile("(?i)nginx"),
        "IIS" to Pattern.compile("(?i)Microsoft-IIS"),
        "Tomcat" to Pattern.compile("(?i)Tomcat"),
        "Jetty" to Pattern.compile("(?i)Jetty"),
        "Node.js" to Pattern.compile("(?i)Express|node\\.js"),
        "Caddy" to Pattern.compile("(?i)Caddy"),
        "Cloudflare" to Pattern.compile("(?i)cloudflare"),
        "AWS ELB" to Pattern.compile("(?i)awselb|elastic load balancer"),
        "Google GFE" to Pattern.compile("(?i)gfe|google frontend"),
        "Envoy" to Pattern.compile("(?i)envoy"),
        "Varnish" to Pattern.compile("(?i)Varnish"),
        "HAProxy" to Pattern.compile("(?i)HAProxy"),
        "Traefik" to Pattern.compile("(?i)traefik")
    )

    // X-Powered-By patterns
    private val poweredByPatterns = mapOf(
        "PHP" to Pattern.compile("(?i)PHP/"),
        "ASP.NET" to Pattern.compile("(?i)ASP\\.NET"),
        "Spring" to Pattern.compile("(?i)Spring"),
        "Django" to Pattern.compile("(?i)Django"),
        "Express" to Pattern.compile("(?i)Express"),
        "Next.js" to Pattern.compile("(?i)Next\\.js"),
        "Nuxt.js" to Pattern.compile("(?i)Nuxt"),
        "Laravel" to Pattern.compile("(?i)Laravel"),
        "Symfony" to Pattern.compile("(?i)Symfony"),
        "CodeIgniter" to Pattern.compile("(?i)CodeIgniter"),
        "Ruby on Rails" to Pattern.compile("(?i)Rails|Ruby"),
        "Flask" to Pattern.compile("(?i)Flask"),
        "FastAPI" to Pattern.compile("(?i)FastAPI"),
        "Gin" to Pattern.compile("(?i)Gin"),
        "Echo" to Pattern.compile("(?i)Echo"),
        "Fiber" to Pattern.compile("(?i)Fiber"),
        "Actix" to Pattern.compile("(?i)Actix"),
        "Axum" to Pattern.compile("(?i)Axum")
    )

    // Cookie patterns
    private val cookiePatterns = mapOf(
        "PHP" to Pattern.compile("(?i)PHPSESSID"),
        "Java/JSP" to Pattern.compile("(?i)JSESSIONID"),
        "ASP.NET" to Pattern.compile("(?i)ASP\\.NET_SessionId"),
        "Django" to Pattern.compile("(?i)csrftoken|sessionid"),
        "Rails" to Pattern.compile("(?i)_.*_session"),
        "Laravel" to Pattern.compile("(?i)laravel_session"),
        "Symfony" to Pattern.compile("(?i)PHPSESSID|symfony"),
        "CodeIgniter" to Pattern.compile("(?i)ci_session"),
        "Express" to Pattern.compile("(?i)connect\\.sid|express:sess"),
        "WordPress" to Pattern.compile("(?i)wordpress_|wp-"),
        "Drupal" to Pattern.compile("(?i)SSESS|DRUPAL_UID"),
        "Joomla" to Pattern.compile("(?i)joomla_|jf_"),
        "Magento" to Pattern.compile("(?i)mage-|magento"),
        "PrestaShop" to Pattern.compile("(?i)PrestaShop"),
        "OpenCart" to Pattern.compile("(?i)OCSESSID"),
        "Shopify" to Pattern.compile("(?i)shopify_|_shopify_"),
        "Salesforce" to Pattern.compile("(?i)sid|oauth_token"),
        "Google Cloud" to Pattern.compile("(?i)GCLB|GAE"),
        "AWS" to Pattern.compile("(?i)AWSELB|AWSALB")
    )

    // Body content patterns
    private val bodyPatterns = mapOf(
        "WordPress" to Pattern.compile("(?i)wp-content|wp-includes|WordPress"),
        "Drupal" to Pattern.compile("(?i)Drupal\\.settings|drupal\\.js|/sites/default/"),
        "Joomla" to Pattern.compile("(?i)Joomla!|/media/system/js/|/templates/.*?/css/"),
        "Magento" to Pattern.compile("(?i)Mage\\.Cookies|/skin/frontend/|/js/mage/"),
        "Shopify" to Pattern.compile("(?i)Shopify\\.theme|shopify\\.com|/cdn/shop/"),
        "React" to Pattern.compile("(?i)react\\.js|react-dom|__REACT_DEVTOOLS__|data-reactroot"),
        "Vue.js" to Pattern.compile("(?i)Vue\\.js|vue\\.js|__VUE__|data-v-"),
        "Angular" to Pattern.compile("(?i)ng-version|angular\\.js|angular\\.min\\.js"),
        "Next.js" to Pattern.compile("(?i)_next/static|__NEXT_DATA__|next\\.js"),
        "Nuxt.js" to Pattern.compile("(?i)_nuxt/|__NUXT__"),
        "Svelte" to Pattern.compile("(?i)svelte\\.js|__SVELTE__"),
        "jQuery" to Pattern.compile("(?i)jquery[.-]"),
        "Bootstrap" to Pattern.compile("(?i)bootstrap[.-]"),
        "Font Awesome" to Pattern.compile("(?i)font-?awesome"),
        "Google Analytics" to Pattern.compile("(?i)google-analytics|gtag\\(|ga\\(|_gaq"),
        "Google Tag Manager" to Pattern.compile("(?i)googletagmanager|GTM-"),
        "reCAPTCHA" to Pattern.compile("(?i)recaptcha|grecaptcha"),
        "Cloudflare" to Pattern.compile("(?i)__cfduid|cf-ray|cloudflare"),
        "Akamai" to Pattern.compile("(?i)akamai"),
        "Fastly" to Pattern.compile("(?i)fastly"),
        "Vercel" to Pattern.compile("(?i)vercel|__vercel"),
        "Netlify" to Pattern.compile("(?i)netlify"),
        "Firebase" to Pattern.compile("(?i)firebase|__firebase"),
        "GraphQL" to Pattern.compile("(?i)__typename|__schema|graphql"),
        "Apollo" to Pattern.compile("(?i)apollo|apollographql"),
        "Prisma" to Pattern.compile("(?i)prisma"),
        "TypeORM" to Pattern.compile("(?i)typeorm"),
        "Sequelize" to Pattern.compile("(?i)sequelize"),
        "Mongoose" to Pattern.compile("(?i)mongoose"),
        "SQLAlchemy" to Pattern.compile("(?i)sqlalchemy"),
        "Hibernate" to Pattern.compile("(?i)hibernate"),
        "Entity Framework" to Pattern.compile("(?i)entityframework|ef core"),
        "Redis" to Pattern.compile("(?i)redis"),
        "Memcached" to Pattern.compile("(?i)memcached"),
        "PostgreSQL" to Pattern.compile("(?i)postgresql|postgres"),
        "MySQL" to Pattern.compile("(?i)mysql"),
        "MongoDB" to Pattern.compile("(?i)mongodb|mongo"),
        "Elasticsearch" to Pattern.compile("(?i)elasticsearch"),
        "Kafka" to Pattern.compile("(?i)kafka"),
        "RabbitMQ" to Pattern.compile("(?i)rabbitmq"),
        "Docker" to Pattern.compile("(?i)docker"),
        "Kubernetes" to Pattern.compile("(?i)kubernetes|k8s"),
        "OpenShift" to Pattern.compile("(?i)openshift"),
        "Istio" to Pattern.compile("(?i)istio"),
        "Envoy" to Pattern.compile("(?i)envoy"),
        "Linkerd" to Pattern.compile("(?i)linkerd")
    )

    // WAF/CDN detection patterns
    private val wafPatterns = mapOf(
        "Cloudflare" to Pattern.compile("(?i)cf-ray|__cfduid|cloudflare"),
        "Akamai" to Pattern.compile("(?i)akamai"),
        "Incapsula" to Pattern.compile("(?i)incapsula|visid_incap"),
        "Sucuri" to Pattern.compile("(?i)sucuri"),
        "AWS WAF" to Pattern.compile("(?i)awswaf|x-amzn-waf"),
        "ModSecurity" to Pattern.compile("(?i)mod_security|modsecurity"),
        "F5 BIG-IP" to Pattern.compile("(?i)bigip|f5"),
        "Imperva" to Pattern.compile("(?i)imperva"),
        "Barracuda" to Pattern.compile("(?i)barracuda"),
        "FortiWeb" to Pattern.compile("(?i)fortiweb"),
        "Citrix NetScaler" to Pattern.compile("(?i)netscaler|citrix"),
        "Radware" to Pattern.compile("(?i)radware"),
        "Wallarm" to Pattern.compile("(?i)wallarm")
    )

    // CMS detection patterns (more specific)
    private val cmsPatterns = mapOf(
        "WordPress" to Pattern.compile("(?i)wp-content|wp-includes|WordPress|/wp-json/"),
        "Drupal" to Pattern.compile("(?i)Drupal\\.settings|drupal\\.js|/sites/default/files/|/core/"),
        "Joomla" to Pattern.compile("(?i)Joomla!|/media/system/|/templates/.*?/html/|option=com_"),
        "Magento" to Pattern.compile("(?i)Mage\\.Cookies|/skin/frontend/|/js/mage/|/media/catalog/"),
        "Shopify" to Pattern.compile("(?i)Shopify\\.theme|shopify\\.com|/cdn/shop/|myshopify\\.com"),
        "PrestaShop" to Pattern.compile("(?i)PrestaShop|/themes/.*?/css/|/modules/"),
        "OpenCart" to Pattern.compile("(?i)OpenCart|/catalog/view/theme/|/system/library/"),
        "TYPO3" to Pattern.compile("(?i)TYPO3|/typo3/|/typo3conf/"),
        "Concrete5" to Pattern.compile("(?i)concrete5|/concrete/|/application/files/"),
        "Ghost" to Pattern.compile("(?i)Ghost|/ghost/|/content/themes/"),
        "Gatsby" to Pattern.compile("(?i)gatsby|___gatsby|/page-data/"),
        "Hugo" to Pattern.compile("(?i)hugo|/hugo/|generator.*hugo"),
        "Jekyll" to Pattern.compile("(?i)jekyll|/assets/.*?/jekyll/"),
        "Hexo" to Pattern.compile("(?i)hexo|/css/.*?hexo/"),
        "Strapi" to Pattern.compile("(?i)strapi|/admin/.*?strapi/|/uploads/")
    )

    /**
     * Detect technologies from an HTTP response.
     * Returns TechnologyInfo with all detected technologies.
     */
    fun detectFromResponse(record: MappingRecord): TechnologyInfo? {
        val headers = record.responseMetadata?.headers ?: record.requestMetadata?.headers ?: return null
        val cookies = record.cookieNames
        val body = "" // We don't have body in the record, would need to be passed separately
        
        val technologies = mutableListOf<Technology>()
        val techInfo = TechnologyInfo()

        // Detect from Server header
        headers["server"]?.forEach { value ->
            serverPatterns.forEach { (name, pattern) ->
                if (pattern.matcher(value).find()) {
                    technologies.add(Technology(name, "server", extractVersion(value), "high", listOf("Server header: $value")))
                }
            }
        }

        // Detect from X-Powered-By
        headers["x-powered-by"]?.forEach { value ->
            poweredByPatterns.forEach { (name, pattern) ->
                if (pattern.matcher(value).find()) {
                    technologies.add(Technology(name, "framework", extractVersion(value), "high", listOf("X-Powered-By header: $value")))
                }
            }
        }

        // Detect from cookies
        cookies.forEach { cookie ->
            cookiePatterns.forEach { (name, pattern) ->
                if (pattern.matcher(cookie).find()) {
                    technologies.add(Technology(name, cookieCategory(name), null, "medium", listOf("Cookie: $cookie")))
                }
            }
        }

        // Detect WAF/CDN
        headers.forEach { (name, values) ->
            values.forEach { value ->
                wafPatterns.forEach { (wafName, pattern) ->
                    if (pattern.matcher(value).find() || pattern.matcher(name).find()) {
                        techInfo.waf = wafName
                        technologies.add(Technology(wafName, "waf", null, "high", listOf("Header $name: $value")))
                    }
                }
            }
        }

        // Detect CDN
        headers["via"]?.forEach { value ->
            if (value.contains("cloudflare")) techInfo.cdn = "Cloudflare"
            else if (value.contains("akamai")) techInfo.cdn = "Akamai"
            else if (value.contains("fastly")) techInfo.cdn = "Fastly"
            else if (value.contains("vercel")) techInfo.cdn = "Vercel"
            else if (value.contains("netlify")) techInfo.cdn = "Netlify"
        }

        // Hosting/platform hints
        headers["x-served-by"]?.forEach { value ->
            if (value.contains("github")) techInfo.hosting = "GitHub Pages"
            else if (value.contains("netlify")) techInfo.hosting = "Netlify"
            else if (value.contains("vercel")) techInfo.hosting = "Vercel"
        }

        // Deduplicate technologies
        val byName = ConcurrentHashMap<String, Technology>()
        technologies.forEach { tech ->
            val existing = byName[tech.name]
            if (existing == null || tech.confidenceWeight() > existing.confidenceWeight()) {
                byName[tech.name] = tech
            }
        }
        
        techInfo.technologies = byName.values.toList()
        
        // Set categorized fields
        categorizeTechnologies(techInfo)

        return if (techInfo.technologies.isNotEmpty() || techInfo.server != null || techInfo.framework != null || techInfo.cms != null || techInfo.waf != null || techInfo.cdn != null || techInfo.hosting != null) {
            techInfo
        } else {
            null
        }
    }

    /**
     * Detect technologies from response body (for HTML/JS responses).
     */
    fun detectFromBody(record: MappingRecord, body: String): TechnologyInfo? {
        val techInfo = detectFromResponse(record) ?: TechnologyInfo()
        val technologies = techInfo.technologies.toMutableList()

        // Body content patterns
        bodyPatterns.forEach { (name, pattern) ->
            if (pattern.matcher(body).find()) {
                technologies.add(Technology(name, technologyCategory(name), null, "medium", listOf("Body content match")))
            }
        }

        // CMS patterns
        cmsPatterns.forEach { (name, pattern) ->
            if (pattern.matcher(body).find()) {
                techInfo.cms = name
                technologies.add(Technology(name, "cms", null, "high", listOf("CMS detection")))
            }
        }

        // Deduplicate
        val byName = ConcurrentHashMap<String, Technology>()
        technologies.forEach { tech ->
            val existing = byName[tech.name]
            if (existing == null || tech.confidenceWeight() > existing.confidenceWeight()) {
                byName[tech.name] = tech
            }
        }

        techInfo.technologies = byName.values.toList()
        categorizeTechnologies(techInfo)

        return if (techInfo.technologies.isNotEmpty() || techInfo.server != null || techInfo.framework != null || techInfo.cms != null) {
            techInfo
        } else {
            null
        }
    }

    private fun categorizeTechnologies(techInfo: TechnologyInfo) {
        techInfo.technologies.forEach { tech ->
            when (tech.category.lowercase()) {
                "server" -> techInfo.server = tech.name
                "framework" -> techInfo.framework = tech.name
                "cms" -> techInfo.cms = tech.name
                "language" -> techInfo.language = tech.name
                "database" -> techInfo.database = tech.name
                "waf" -> techInfo.waf = tech.name
                "cdn" -> techInfo.cdn = tech.name
                "hosting" -> techInfo.hosting = tech.name
            }
        }
    }

    private fun cookieCategory(techName: String): String {
        return when (techName.lowercase()) {
            "php" -> "language"
            "java/jsp" -> "language"
            "asp.net" -> "framework"
            "django" -> "framework"
            "rails" -> "framework"
            "laravel" -> "framework"
            "symfony" -> "framework"
            "codeigniter" -> "framework"
            "express" -> "framework"
            "wordpress" -> "cms"
            "drupal" -> "cms"
            "joomla" -> "cms"
            "magento" -> "cms"
            "prestashop" -> "cms"
            "opencart" -> "cms"
            "shopify" -> "cms"
            "salesforce" -> "platform"
            "google cloud" -> "platform"
            "aws" -> "platform"
            else -> "session"
        }
    }

    private fun technologyCategory(techName: String): String {
        return when (techName.lowercase()) {
            "wordpress", "drupal", "joomla", "magento", "shopify", "prestashop", "opencart", "typo3", "concrete5", "ghost", "gatsby", "hugo", "jekyll", "hexo", "strapi" -> "cms"
            "react", "vue.js", "angular", "next.js", "nuxt.js", "svelte", "jquery", "bootstrap", "font awesome" -> "library"
            "google analytics", "google tag manager", "recaptcha" -> "analytics"
            "cloudflare", "akamai", "fastly", "vercel", "netlify", "firebase" -> "platform"
            "graphql", "apollo", "prisma", "typeorm", "sequelize", "mongoose", "sqlalchemy", "hibernate", "entity framework" -> "api"
            "redis", "memcached", "postgresql", "mysql", "mongodb", "elasticsearch" -> "database"
            "kafka", "rabbitmq" -> "messaging"
            "docker", "kubernetes", "openshift", "istio", "envoy", "linkerd" -> "infrastructure"
            else -> "technology"
        }
    }

    private fun extractVersion(value: String): String? {
        // Extract version from strings like "Apache/2.4.41" or "PHP/7.4.3"
        val versionPattern = Pattern.compile("(?i)([a-z]+)[/\\s]([\\d.]+)")
        val matcher = versionPattern.matcher(value)
        if (matcher.find()) {
            return matcher.group(2)
        }
        return null
    }
}

private fun Technology.confidenceWeight(): Int {
    return when (confidence.lowercase()) {
        "certain" -> 4
        "high" -> 3
        "medium" -> 2
        "low" -> 1
        else -> 0
    }
}