package com.user404.applicationmapper.extraction

import com.user404.applicationmapper.engine.CanonicalIdentity
import com.user404.applicationmapper.model.MappingRecord
import com.user404.applicationmapper.model.JsSourceInfo
import com.user404.applicationmapper.model.ApiSourceInfo
import com.user404.applicationmapper.model.ProvenanceInfo
import com.user404.applicationmapper.model.RelationshipInfo
import com.user404.applicationmapper.model.SourceLocation
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Pattern

/**
 * Lightweight HTML/JS/API resource extraction.
 * 
 * Extracts:
 * - HTML links, forms, scripts, stylesheets, images, resources
 * - JavaScript endpoints (fetch, XHR, axios, router paths, imports)
 * - API definitions (OpenAPI, Swagger, GraphQL)
 * - CSS URLs
 * - Comments containing paths
 * 
 * Does NOT perform:
 * - AST analysis
 * - Source-map analysis
 * - Deep reverse engineering
 * - Advanced deobfuscation
 */
class HtmlJsExtractor {

    // HTML attribute patterns
    private val htmlAttrPattern = Pattern.compile(
        "(?:href|src|action|formaction|data-url|data-href|data-src|data-action|data-endpoint|data-api)\\s*=\\s*[\"']([^\"'#?][^\"']*)[\"']",
        Pattern.CASE_INSENSITIVE
    )

    // HTML form pattern (captures method and action)
    private val formPattern = Pattern.compile(
        "<form[^>]*\\bmethod\\s*=\\s*[\"']?([a-zA-Z]+)[\"']?[^>]*\\baction\\s*=\\s*[\"']([^\"']+)[\"']" +
        "|<form[^>]*\\baction\\s*=\\s*[\"']([^\"']+)[\"'][^>]*\\bmethod\\s*=\\s*[\"']?([a-zA-Z]+)[\"']?",
        Pattern.CASE_INSENSITIVE
    )

    // Meta refresh
    private val metaRefreshPattern = Pattern.compile(
        "<meta[^>]+http-equiv=[\"']?refresh[\"']?[^>]+content=[\"'][^;]*;\\s*url=([^\"'\\s>]+)",
        Pattern.CASE_INSENSITIVE
    )

    // JavaScript fetch/axios/XHR patterns
    private val jsFetchPattern = Pattern.compile(
        "(?:fetch|axios\\.(?:get|post|put|delete|patch|request)|\\$\\.(?:get|post|ajax)|" +
        "XMLHttpRequest[^(]*\\.open\\(['\"]\\w+['\"],\\s*|" +
        "this\\.(?:http|Http)\\.(?:get|post|put|delete|patch)\\(|" +
        "request\\.(?:get|post|put|delete)|" +
        "superagent\\.(?:get|post|put|delete))\\s*\\(?[\"']([^\"'\\s\\)]+)[\"']",
        Pattern.CASE_INSENSITIVE
    )

    // Router patterns (React, Vue, Next.js)
    private val routerPattern = Pattern.compile(
        "(?:router\\.(?:push|replace)|useRouter\\(\\)\\.push|Link\\s+to|Route\\s+path|" +
        "path\\s*:|to\\s*:)\\s*[\"'`]([/][^\"'`\\s]+)[\"'`]",
        Pattern.CASE_INSENSITIVE
    )

    // API path string literals
    private val apiPathPattern = Pattern.compile(
        "[\"'`](/(?:api|rest|graphql|v\\d+|gql|service|services|endpoint|endpoints|" +
        "data|resources?|internal|admin|management|actuator|swagger|openapi|health|" +
        "metrics|auth|login|logout|user|users|account|accounts|profile|search|query|" +
        "report|reports|export|import|upload|download|webhook|webhooks|callback|" +
        "token|refresh|verify|validate|confirm)(?:/[A-Za-z0-9_\\-\\.~%@!$&'()*+,;:=]+)*" +
        "(?:\\?[A-Za-z0-9_\\-=&%+.]*)?)[\"'`]",
        Pattern.CASE_INSENSITIVE
    )

    // JS imports/requires
    private val jsImportPattern = Pattern.compile(
        "(?:require|import)\\s*\\(?\\s*[\"']([./][^\"']+)[\"']",
        Pattern.CASE_INSENSITIVE
    )

    // JSON path values
    private val jsonPathPattern = Pattern.compile(
        "\"(?:href|url|uri|endpoint|path|action|src|link|location|redirect|next|prev|self)\"\\s*:\\s*\"(/[a-zA-Z0-9_\\-/\\.]+(?:\\?[a-zA-Z0-9_\\-=&%+.]*)?)\"",
        Pattern.CASE_INSENSITIVE
    )

    // HAL/JSON-API links
    private val halLinksPattern = Pattern.compile(
        "\"href\"\\s*:\\s*\"(https?://[^\"]+|/[^\"]+)\"",
        Pattern.CASE_INSENSITIVE
    )

    // HTML/JS comments with paths
    private val commentPathPattern = Pattern.compile(
        "(?:<!--|/\\*|//)[^\\n>]*?(/(?:api|rest|v\\d+|admin|internal|graphql)(?:/[A-Za-z0-9_\\-]+)+)(?:\\s|\\n|-->|\\*/|$)",
        Pattern.CASE_INSENSITIVE
    )

    // CSS url() and @import
    private val cssUrlPattern = Pattern.compile(
        "(?:url\\s*\\(\\s*[\"']?|@import\\s+[\"'])(/[^\"'\\s\\)]+)",
        Pattern.CASE_INSENSITIVE
    )

    // OpenAPI/Swagger detection
    private val openApiPattern = Pattern.compile(
        "(?i)(\"swagger\"\\s*:|\"openapi\"\\s*:|swagger\\.json|openapi\\.json|swagger\\.yaml|openapi\\.yaml)"
    )

    // GraphQL detection
    private val graphqlPattern = Pattern.compile(
        "(?i)(/__schema|\"__typename\"|query\\s+\\w+|mutation\\s+\\w+|fragment\\s+\\w+)"
    )

    /**
     * Extract mapping records from an HTTP response body.
     * Returns discovered resources with proper provenance.
     */
    fun extractFromResponse(
        host: String,
        baseUrl: String,
        contentType: String?,
        body: String,
        source: String,
        parentUrl: String?
    ): List<MappingRecord> {
        val records = mutableListOf<MappingRecord>()
        val ct = contentType?.lowercase(Locale.ROOT) ?: ""
        
        val isHtml = ct.contains("html")
        val isJs = ct.contains("javascript") || ct.contains("ecmascript")
        val isJson = ct.contains("json")
        val isCss = ct.contains("css")
        val isXml = ct.contains("xml")

        val baseUri = try { URL(baseUrl) } catch (e: Exception) { return records }
        val seenUrls = ConcurrentHashMap.newKeySet<String>()

        // Extract based on content type
        if (isHtml) {
            records.addAll(extractFromHtml(baseUri, body, source, parentUrl, seenUrls))
        }
        if (isJs) {
            records.addAll(extractFromJavaScript(baseUri, body, source, parentUrl, seenUrls))
        }
        if (isJson) {
            records.addAll(extractFromJson(baseUri, body, source, parentUrl, seenUrls))
        }
        if (isCss) {
            records.addAll(extractFromCss(baseUri, body, source, parentUrl, seenUrls))
        }
        if (isXml) {
            records.addAll(extractFromXml(baseUri, body, source, parentUrl, seenUrls))
        }

        // Cross-cutting patterns (apply to HTML, JS, unknown)
        if (!isJson && !isCss) {
            records.addAll(extractApiPaths(baseUri, body, source, parentUrl, seenUrls))
            records.addAll(extractFromComments(baseUri, body, source, parentUrl, seenUrls))
        }

        // Check for API definitions
        if (isJson && (openApiPattern.matcher(body).find() || body.contains("openapi") || body.contains("swagger"))) {
            records.add(buildApiDefinitionRecord(host, baseUrl, "openapi", source, parentUrl))
        }
        if (isJson && graphqlPattern.matcher(body).find()) {
            records.add(buildApiDefinitionRecord(host, baseUrl, "graphql", source, parentUrl))
        }

        return records
    }

    private fun extractFromHtml(
        baseUri: URL,
        body: String,
        source: String,
        parentUrl: String?,
        seenUrls: ConcurrentHashMap<String, Boolean>
    ): List<MappingRecord> {
        val records = mutableListOf<MappingRecord>()

        // HTML attributes (href, src, action, data-*)
        extractMatches(htmlAttrPattern, body, 1) { url ->
            val resolved = resolveUrl(url, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = classifyResourceType(url),
                    source = "html-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = emptyList(), context = "html-attribute", extractionMethod = "regex")
                ))
            }
        }

        // Meta refresh
        extractMatches(metaRefreshPattern, body, 1) { url ->
            val resolved = resolveUrl(url, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "html",
                    source = "html-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = emptyList(), context = "meta-refresh", extractionMethod = "regex")
                ))
            }
        }

        // Forms
        val formMatcher = formPattern.matcher(body)
        while (formMatcher.find()) {
            val method = (formMatcher.group(1) ?: formMatcher.group(4))?.uppercase(Locale.ROOT) ?: "GET"
            val action = formMatcher.group(2) ?: formMatcher.group(3)
            
            if (action != null) {
                val resolved = resolveUrl(action, baseUri)
                if (resolved != null) {
                    val canonicalId = CanonicalIdentity.generate(
                        host = baseUri.host,
                        url = resolved,
                        method = method,
                        resourceType = "form"
                    )
                    
                    val record = MappingRecord.builder()
                        .apply {
                            this.host = baseUri.host
                            this.url = resolved
                            this.scheme = baseUri.protocol
                            this.port = if (baseUri.port > 0) baseUri.port else if (baseUri.protocol == "https") 443 else 80
                            this.method = method
                            this.status = null
                            this.mimeType = null
                            this.contentLength = null
                            this.redirectLocation = null
                            this.redirectChain = emptyList()
                            this.parameterNames = emptyList()
                            this.parameterLocations = emptyMap()
                            this.formAction = resolved
                            this.formMethod = method
                            this.cookieNames = emptyList()
                            this.contentType = null
                            this.source = "html-extraction"
                            this.discoveredFrom = source
                            this.parentUrl = parentUrl
                            this.jsSource = JsSourceInfo(sourceFile = baseUrl, lines = emptyList(), context = "html-form", extractionMethod = "regex")
                            this.apiSource = null
                            this.resourceType = "form"
                            this.burpTags = emptyList()
                            this.passiveFindings = emptyList()
                            this.notes = "Form extracted from HTML"
                            this.canonicalId = canonicalId
                            this.provenance = ProvenanceInfo().apply {
                                addDerivedSource("html-extraction")
                                addDiscoveryMethod("form-extraction")
                                firstDiscoveredBy = "html-extraction"
                                lastDiscoveredBy = "html-extraction"
                            }
                            this.relationships = RelationshipInfo().apply {
                                if (parentUrl != null) parents.add(parentUrl)
                            }
                        }
                        .build()
                    
                    records.add(record)
                }
            }
        }

        return records
    }

    private fun extractFromJavaScript(
        baseUri: URL,
        body: String,
        source: String,
        parentUrl: String?,
        seenUrls: ConcurrentHashMap<String, Boolean>
    ): List<MappingRecord> {
        val records = mutableListOf<MappingRecord>()
        val lineMap = buildLineMap(body)

        // JS fetch/XHR/axios
        extractMatchesWithLines(jsFetchPattern, body, 1, lineMap) { url, line ->
            val resolved = resolveUrl(url, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "javascript",
                    source = "js-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = listOf(line), context = "js-fetch", extractionMethod = "regex")
                ))
            }
        }

        // Router paths
        extractMatchesWithLines(routerPattern, body, 1, lineMap) { path, line ->
            val resolved = resolveUrl(path, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "javascript",
                    source = "js-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = listOf(line), context = "router", extractionMethod = "regex")
                ))
            }
        }

        // JS imports/requires
        extractMatchesWithLines(jsImportPattern, body, 1, lineMap) { path, line ->
            val resolved = resolveUrl(path, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "javascript",
                    source = "js-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = listOf(line), context = "import", extractionMethod = "regex")
                ))
            }
        }

        return records
    }

    private fun extractFromJson(
        baseUri: URL,
        body: String,
        source: String,
        parentUrl: String?,
        seenUrls: ConcurrentHashMap<String, Boolean>
    ): List<MappingRecord> {
        val records = mutableListOf<MappingRecord>()

        // JSON path values
        extractMatches(jsonPathPattern, body, 1) { url ->
            val resolved = resolveUrl(url, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "json",
                    source = "json-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = emptyList(), context = "json-path", extractionMethod = "regex"),
                    apiSource = ApiSourceInfo(definitionUrl = baseUrl, definitionType = "json", path = url)
                ))
            }
        }

        // HAL links
        extractMatches(halLinksPattern, body, 1) { url ->
            val resolved = if (url.startsWith("http")) url else resolveUrl(url, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "api",
                    source = "json-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = emptyList(), context = "hal-link", extractionMethod = "regex"),
                    apiSource = ApiSourceInfo(definitionUrl = baseUrl, definitionType = "hal", path = url)
                ))
            }
        }

        return records
    }

    private fun extractFromCss(
        baseUri: URL,
        body: String,
        source: String,
        parentUrl: String?,
        seenUrls: ConcurrentHashMap<String, Boolean>
    ): List<MappingRecord> {
        val records = mutableListOf<MappingRecord>()

        extractMatches(cssUrlPattern, body, 1) { url ->
            val resolved = resolveUrl(url, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "stylesheet",
                    source = "css-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = emptyList(), context = "css-url", extractionMethod = "regex")
                ))
            }
        }

        return records
    }

    private fun extractFromXml(
        baseUri: URL,
        body: String,
        source: String,
        parentUrl: String?,
        seenUrls: ConcurrentHashMap<String, Boolean>
    ): List<MappingRecord> {
        // Basic XML href/src extraction
        val records = mutableListOf<MappingRecord>()
        val xmlAttrPattern = Pattern.compile("(?:href|src|xlink:href)\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
        
        extractMatches(xmlAttrPattern, body, 1) { url ->
            val resolved = resolveUrl(url, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "xml",
                    source = "xml-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = emptyList(), context = "xml-attribute", extractionMethod = "regex")
                ))
            }
        }

        return records
    }

    private fun extractApiPaths(
        baseUri: URL,
        body: String,
        source: String,
        parentUrl: String?,
        seenUrls: ConcurrentHashMap<String, Boolean>
    ): List<MappingRecord> {
        val records = mutableListOf<MappingRecord>()
        val lineMap = buildLineMap(body)

        extractMatchesWithLines(apiPathPattern, body, 1, lineMap) { path, line ->
            val resolved = resolveUrl(path, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "api",
                    source = "js-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = listOf(line), context = "api-path", extractionMethod = "regex"),
                    apiSource = ApiSourceInfo(definitionUrl = baseUrl, definitionType = "inferred", path = path)
                ))
            }
        }

        return records
    }

    private fun extractFromComments(
        baseUri: URL,
        body: String,
        source: String,
        parentUrl: String?,
        seenUrls: ConcurrentHashMap<String, Boolean>
    ): List<MappingRecord> {
        val records = mutableListOf<MappingRecord>()
        val lineMap = buildLineMap(body)

        extractMatchesWithLines(commentPathPattern, body, 1, lineMap) { path, line ->
            val resolved = resolveUrl(path, baseUri)
            if (resolved != null && seenUrls.putIfAbsent(resolved, true) == null) {
                records.add(buildResourceRecord(
                    host = baseUri.host,
                    url = resolved,
                    resourceType = "discovered",
                    source = "comment-extraction",
                    discoveredFrom = source,
                    parentUrl = parentUrl,
                    jsSource = JsSourceInfo(sourceFile = baseUrl, lines = listOf(line), context = "comment", extractionMethod = "regex")
                ))
            }
        }

        return records
    }

    private fun buildApiDefinitionRecord(
        host: String,
        baseUrl: String,
        definitionType: String,
        source: String,
        parentUrl: String?
    ): MappingRecord {
        val canonicalId = CanonicalIdentity.generate(
            host = host,
            url = baseUrl,
            method = null,
            resourceType = "api-definition:$definitionType"
        )

        return MappingRecord.builder()
            .apply {
                this.host = host
                this.url = baseUrl
                this.scheme = try { URL(baseUrl).protocol } catch (e: Exception) { "https" }
                this.port = try { URL(baseUrl).port.takeIf { it > 0 } ?: (if (this.scheme == "https") 443 else 80) } catch (e: Exception) { 443 }
                this.method = null
                this.status = null
                this.mimeType = "application/json"
                this.contentLength = null
                this.redirectLocation = null
                this.redirectChain = emptyList()
                this.parameterNames = emptyList()
                this.parameterLocations = emptyMap()
                this.formAction = null
                this.formMethod = null
                this.cookieNames = emptyList()
                this.contentType = "application/json"
                this.source = "api-definition"
                this.discoveredFrom = source
                this.parentUrl = parentUrl
                this.jsSource = null
                this.apiSource = ApiSourceInfo(definitionUrl = baseUrl, definitionType = definitionType)
                this.resourceType = "api-definition:$definitionType"
                this.burpTags = emptyList()
                this.passiveFindings = emptyList()
                this.notes = "$definitionType definition discovered"
                this.canonicalId = canonicalId
                this.provenance = ProvenanceInfo().apply {
                    addDerivedSource("api-definition-extraction")
                    addDiscoveryMethod("api-definition")
                    firstDiscoveredBy = "api-definition-extraction"
                    lastDiscoveredBy = "api-definition-extraction"
                }
                this.relationships = RelationshipInfo().apply {
                    if (parentUrl != null) parents.add(parentUrl)
                }
            }
            .build()
    }

    private fun buildResourceRecord(
        host: String,
        url: String,
        resourceType: String,
        source: String,
        discoveredFrom: String,
        parentUrl: String?,
        jsSource: JsSourceInfo? = null,
        apiSource: ApiSourceInfo? = null
    ): MappingRecord {
        val canonicalId = CanonicalIdentity.generate(
            host = host,
            url = url,
            method = "GET",
            resourceType = resourceType
        )

        return MappingRecord.builder()
            .apply {
                this.host = host
                this.url = url
                this.scheme = try { URL(url).protocol } catch (e: Exception) { "https" }
                this.port = try { URL(url).port.takeIf { it > 0 } ?: (if (this.scheme == "https") 443 else 80) } catch (e: Exception) { 443 }
                this.method = "GET"
                this.status = null
                this.mimeType = null
                this.contentLength = null
                this.redirectLocation = null
                this.redirectChain = emptyList()
                this.parameterNames = mutableListOf()
                this.parameterLocations = mutableMapOf()
                this.formAction = null
                this.formMethod = null
                this.cookieNames = mutableListOf()
                this.contentType = null
                this.source = source
                this.discoveredFrom = discoveredFrom
                this.parentUrl = parentUrl
                this.jsSource = jsSource
                this.apiSource = apiSource
                this.resourceType = resourceType
                this.burpTags = mutableListOf()
                this.passiveFindings = mutableListOf()
                this.notes = "Discovered via $source from $discoveredFrom"
                this.canonicalId = canonicalId
                this.provenance = ProvenanceInfo().apply {
                    addDerivedSource(source)
                    addDiscoveryMethod(source)
                }
                this.relationships = RelationshipInfo().apply {
                    if (parentUrl != null) parents.add(parentUrl)
                }
            }
            .build()
    }

    private fun resolveUrl(raw: String, base: URL): String? {
        if (raw.isNullOrBlank()) return null
        val lower = raw.lowercase(Locale.ROOT)
        
        // Skip non-http schemes and fragments
        if (lower.startsWith("data:") || lower.startsWith("javascript:") 
            || lower.startsWith("mailto:") || lower.startsWith("tel:")
            || lower.startsWith("blob:") || raw.startsWith("#")
            || raw.startsWith("{") || raw.startsWith("$")) {
            return null
        }

        try {
            return when {
                raw.startsWith("http://") || raw.startsWith("https://") -> normalizeUrl(raw)
                raw.startsWith("//") -> normalizeUrl(base.protocol + ":" + raw)
                raw.startsWith("/") -> {
                    val port = if (base.port > 0 && base.port != 80 && base.port != 443) ":${base.port}" else ""
                    normalizeUrl("${base.protocol}://${base.host}$port$raw")
                }
                else -> normalizeUrl(URL(base, raw).toString())
            }
        } catch (e: Exception) {
            return null
        }
    }

    private fun normalizeUrl(url: String): String {
        var normalized = url
        val hash = normalized.indexOf('#')
        if (hash >= 0) normalized = normalized.substring(0, hash)
        if (normalized.endsWith("/") && normalized.length > 8) {
            normalized = normalized.substring(0, normalized.length - 1)
        }
        return normalized
    }

    private fun classifyResourceType(url: String): String {
        val lower = url.lowercase(Locale.ROOT)
        return when {
            lower.endsWith(".js") -> "javascript"
            lower.endsWith(".css") -> "stylesheet"
            lower.matches(".*\\.(png|jpg|jpeg|gif|ico|svg|webp|avif)$") -> "image"
            lower.matches(".*\\.(woff|woff2|ttf|eot|otf)$") -> "font"
            lower.endsWith(".html") || lower.endsWith(".htm") -> "html"
            lower.endsWith(".json") -> "json"
            lower.endsWith(".xml") -> "xml"
            lower.contains("/api/") || lower.contains("/rest/") || lower.contains("/graphql") -> "api"
            else -> "http"
        }
    }

    private fun extractMatches(pattern: Pattern, body: String, group: Int, callback: (String) -> Unit) {
        val matcher = pattern.matcher(body)
        while (matcher.find()) {
            val value = matcher.group(group)
            if (value != null && value.isNotBlank()) {
                callback(value)
            }
        }
    }

    private fun extractMatchesWithLines(
        pattern: Pattern, 
        body: String, 
        group: Int, 
        lineMap: IntArray,
        callback: (String, Int) -> Unit
    ) {
        val matcher = pattern.matcher(body)
        while (matcher.find()) {
            val value = matcher.group(group)
            if (value != null && value.isNotBlank()) {
                val start = matcher.start(group)
                val line = if (start < lineMap.size) lineMap[start] else 1
                callback(value, line)
            }
        }
    }

    private fun buildLineMap(body: String): IntArray {
        val lineMap = IntArray(body.length)
        var line = 1
        for (i in body.indices) {
            lineMap[i] = line
            if (body[i] == '\n') line++
        }
        return lineMap
    }
}