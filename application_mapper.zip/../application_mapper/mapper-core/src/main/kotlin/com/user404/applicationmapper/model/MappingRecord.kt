package com.user404.applicationmapper.model

import com.google.gson.annotations.SerializedName
import java.time.Instant

/**
 * Core mapping record representing a single canonical application resource.
 * This is the primary JSONL output format.
 */
data class MappingRecord(
    // Core identity fields
    @SerializedName("host") val host: String,
    @SerializedName("url") val url: String,
    @SerializedName("scheme") val scheme: String?,
    @SerializedName("port") val port: Int?,
    @SerializedName("method") val method: String?,
    @SerializedName("status") val status: Int?,
    @SerializedName("mime_type") val mimeType: String?,
    @SerializedName("content_length") val contentLength: Long?,
    @SerializedName("redirect_location") val redirectLocation: String?,
    @SerializedName("redirect_chain") val redirectChain: List<String>,

    // Parameter information
    @SerializedName("parameter_names") val parameterNames: List<String>,
    @SerializedName("parameter_locations") val parameterLocations: Map<String, List<String>>,
    @SerializedName("form_action") val formAction: String?,
    @SerializedName("form_method") val formMethod: String?,

    // Cookie information
    @SerializedName("cookie_names") val cookieNames: List<String>,
    @SerializedName("content_type") val contentType: String?,

    // Provenance and discovery
    @SerializedName("source") val source: String?,
    @SerializedName("discovered_from") val discoveredFrom: String?,
    @SerializedName("parent_url") val parentUrl: String?,
    @SerializedName("js_source") val jsSource: JsSourceInfo?,
    @SerializedName("api_source") val apiSource: ApiSourceInfo?,

    // Classification
    @SerializedName("resource_type") val resourceType: String,
    @SerializedName("burp_tags") val burpTags: List<String>,
    @SerializedName("passive_findings") val passiveFindings: List<PassiveFinding>,
    @SerializedName("notes") val notes: String?,

    // Extended fields
    @SerializedName("canonical_id") val canonicalId: String,
    @SerializedName("first_seen") val firstSeen: String,
    @SerializedName("last_seen") val lastSeen: String,
    @SerializedName("observation_count") val observationCount: Long,
    @SerializedName("provenance") val provenance: ProvenanceInfo,
    @SerializedName("relationships") val relationships: RelationshipInfo,
    @SerializedName("technology") val technology: TechnologyInfo?,
    @SerializedName("source_locations") val sourceLocations: List<SourceLocation>,
    @SerializedName("request_metadata") val requestMetadata: RequestMetadata?,
    @SerializedName("response_metadata") val responseMetadata: ResponseMetadata?,
    @SerializedName("websocket_info") val websocketInfo: WebSocketInfo?
) {
    fun toBuilder(): Builder {
        val builder = Builder()
        builder.host = this.host
        builder.url = this.url
        builder.scheme = this.scheme
        builder.port = this.port
        builder.method = this.method
        builder.status = this.status
        builder.mimeType = this.mimeType
        builder.contentLength = this.contentLength
        builder.redirectLocation = this.redirectLocation
        builder.redirectChain = this.redirectChain.toMutableList()
        builder.parameterNames = this.parameterNames.toMutableSet()
        builder.parameterLocations = this.parameterLocations.mapValues { (k, v) -> v.toMutableSet() }.toMutableMap()
        builder.formAction = this.formAction
        builder.formMethod = this.formMethod
        builder.cookieNames = this.cookieNames.toMutableSet()
        builder.contentType = this.contentType
        builder.source = this.source
        builder.discoveredFrom = this.discoveredFrom
        builder.parentUrl = this.parentUrl
        builder.jsSource = this.jsSource
        builder.apiSource = this.apiSource
        builder.resourceType = this.resourceType
        builder.burpTags = this.burpTags.toMutableSet()
        builder.passiveFindings = this.passiveFindings.toMutableList()
        builder.notes = this.notes
        builder.canonicalId = this.canonicalId
        builder.firstSeen = this.firstSeen
        builder.lastSeen = this.lastSeen
        builder.observationCount = this.observationCount
        builder.provenance = this.provenance
        builder.relationships = this.relationships
        builder.technology = this.technology
        builder.sourceLocations = this.sourceLocations.toMutableList()
        builder.requestMetadata = this.requestMetadata
        builder.responseMetadata = this.responseMetadata
        builder.websocketInfo = this.websocketInfo
        return builder
    }
    companion object {
        fun builder(): Builder = Builder()
    }

    data class Builder(
        var host: String = "",
        var url: String = "",
        var scheme: String? = null,
        var port: Int? = null,
        var method: String? = null,
        var status: Int? = null,
        var mimeType: String? = null,
        var contentLength: Long? = null,
        var redirectLocation: String? = null,
        var redirectChain: MutableList<String> = mutableListOf(),
        var parameterNames: MutableSet<String> = LinkedHashSet(),
        var parameterLocations: MutableMap<String, MutableSet<String>> = LinkedHashMap(),
        var formAction: String? = null,
        var formMethod: String? = null,
        var cookieNames: MutableSet<String> = LinkedHashSet(),
        var contentType: String? = null,
        var source: String? = null,
        var discoveredFrom: String? = null,
        var parentUrl: String? = null,
        var jsSource: JsSourceInfo? = null,
        var apiSource: ApiSourceInfo? = null,
        var resourceType: String = "http",
        var burpTags: MutableSet<String> = LinkedHashSet(),
        var passiveFindings: MutableList<PassiveFinding> = mutableListOf(),
        var notes: String? = null,
        var canonicalId: String = "",
        var firstSeen: String = Instant.now().toString(),
        var lastSeen: String = Instant.now().toString(),
        var observationCount: Long = 1,
        var provenance: ProvenanceInfo = ProvenanceInfo(),
        var relationships: RelationshipInfo = RelationshipInfo(),
        var technology: TechnologyInfo? = null,
        var sourceLocations: MutableList<SourceLocation> = mutableListOf(),
        var requestMetadata: RequestMetadata? = null,
        var responseMetadata: ResponseMetadata? = null,
        var websocketInfo: WebSocketInfo? = null
    ) {
        fun build(): MappingRecord {
            return MappingRecord(
                host = host,
                url = url,
                scheme = scheme,
                port = port,
                method = method,
                status = status,
                mimeType = mimeType,
                contentLength = contentLength,
                redirectLocation = redirectLocation,
                redirectChain = redirectChain.toList(),
                parameterNames = parameterNames.toList(),
                parameterLocations = parameterLocations.mapValues { (_, v) -> v.toList() },
                formAction = formAction,
                formMethod = formMethod,
                cookieNames = cookieNames.toList(),
                contentType = contentType,
                source = source,
                discoveredFrom = discoveredFrom,
                parentUrl = parentUrl,
                jsSource = jsSource,
                apiSource = apiSource,
                resourceType = resourceType,
                burpTags = burpTags.toList(),
                passiveFindings = passiveFindings.toList(),
                notes = notes,
                canonicalId = canonicalId,
                firstSeen = firstSeen,
                lastSeen = lastSeen,
                observationCount = observationCount,
                provenance = provenance,
                relationships = relationships,
                technology = technology,
                sourceLocations = sourceLocations.toList(),
                requestMetadata = requestMetadata,
                responseMetadata = responseMetadata,
                websocketInfo = websocketInfo
            )
        }
    }
}

/**
 * JavaScript source information for mapper-derived endpoint discovery.
 */
data class JsSourceInfo(
    @SerializedName("source_file") val sourceFile: String,
    @SerializedName("lines") val lines: List<Int>,
    @SerializedName("context") val context: String? = null,
    @SerializedName("extraction_method") val extractionMethod: String? = null
)

/**
 * API definition source information.
 */
data class ApiSourceInfo(
    @SerializedName("definition_url") val definitionUrl: String,
    @SerializedName("definition_type") val definitionType: String, // openapi, graphql, swagger
    @SerializedName("operation_id") val operationId: String? = null,
    @SerializedName("path") val path: String? = null
)

/**
 * Passive finding information.
 */
data class PassiveFinding(
    @SerializedName("name") val name: String,
    @SerializedName("severity") val severity: String,
    @SerializedName("confidence") val confidence: String,
    @SerializedName("detail") val detail: String?,
    @SerializedName("remediation") val remediation: String?,
    @SerializedName("cwe") val cwe: String?,
    @SerializedName("source") val source: String,
    @SerializedName("base_url") val baseUrl: String,
    @SerializedName("burp_tool") val burpTool: String,
    @SerializedName("burp_issue") val burpIssue: Boolean
)

/**
 * Provenance tracking information.
 */
data class ProvenanceInfo(
    @SerializedName("native_sources") val nativeSources: MutableSet<String> = LinkedHashSet(),
    @SerializedName("derived_sources") val derivedSources: MutableSet<String> = LinkedHashSet(),
    @SerializedName("tool_types") val toolTypes: MutableSet<String> = LinkedHashSet(),
    @SerializedName("discovery_methods") val discoveryMethods: MutableSet<String> = LinkedHashSet(),
    @SerializedName("first_discovered_by") val firstDiscoveredBy: String? = null,
    @SerializedName("last_discovered_by") val lastDiscoveredBy: String? = null
) {
    fun addNativeSource(source: String) = nativeSources.add(source)
    fun addDerivedSource(source: String) = derivedSources.add(source)
    fun addToolType(toolType: String) = toolTypes.add(toolType)
    fun addDiscoveryMethod(method: String) = discoveryMethods.add(method)
}

/**
 * Resource relationship information.
 */
data class RelationshipInfo(
    @SerializedName("parents") val parents: MutableList<String> = mutableListOf(),
    @SerializedName("children") val children: MutableList<String> = mutableListOf(),
    @SerializedName("redirects_from") val redirectsFrom: MutableList<String> = mutableListOf(),
    @SerializedName("redirects_to") val redirectsTo: MutableList<String> = mutableListOf(),
    @SerializedName("forms_on_page") val formsOnPage: MutableList<String> = mutableListOf(),
    @SerializedName("resources_on_page") val resourcesOnPage: MutableList<String> = mutableListOf(),
    @SerializedName("api_endpoints") val apiEndpoints: MutableList<String> = mutableListOf(),
    @SerializedName("websocket_endpoints") val websocketEndpoints: MutableList<String> = mutableListOf()
)

/**
 * Technology detection information.
 */
data class TechnologyInfo(
    @SerializedName("technologies") val technologies: MutableList<Technology> = mutableListOf(),
    @SerializedName("server") val server: String? = null,
    @SerializedName("framework") val framework: String? = null,
    @SerializedName("cms") val cms: String? = null,
    @SerializedName("language") val language: String? = null,
    @SerializedName("database") val database: String? = null,
    @SerializedName("cdn") val cdn: String? = null,
    @SerializedName("waf") val waf: String? = null,
    @SerializedName("hosting") val hosting: String? = null
)

data class Technology(
    @SerializedName("name") val name: String,
    @SerializedName("category") val category: String,
    @SerializedName("version") val version: String?,
    @SerializedName("confidence") val confidence: String,
    @SerializedName("evidence") val evidence: List<String>
)

/**
 * Source code location information for line aggregation.
 */
data class SourceLocation(
    @SerializedName("file") val file: String,
    @SerializedName("lines") val lines: List<Int>,
    @SerializedName("context") val context: String? = null
)

/**
 * HTTP request metadata.
 */
data class RequestMetadata(
    @SerializedName("headers") val headers: Map<String, List<String>>,
    @SerializedName("cookies") val cookies: List<String>,
    @SerializedName("body_size") val bodySize: Long?,
    @SerializedName("body_hash") val bodyHash: String?
)

/**
 * HTTP response metadata.
 */
data class ResponseMetadata(
    @SerializedName("headers") val headers: Map<String, List<String>>,
    @SerializedName("cookies") val cookies: List<String>,
    @SerializedName("body_size") val bodySize: Long?,
    @SerializedName("body_hash") val bodyHash: String?,
    @SerializedName("encoding") val encoding: String?
)

/**
 * WebSocket mapping information.
 */
data class WebSocketInfo(
    @SerializedName("url") val url: String,
    @SerializedName("protocol") val protocol: String?,
    @SerializedName("handshake_request") val handshakeRequest: String?,
    @SerializedName("handshake_response") val handshakeResponse: String?,
    @SerializedName("messages_sent") val messagesSent: Int,
    @SerializedName("messages_received") val messagesReceived: Int
)