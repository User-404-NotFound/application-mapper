package com.user404.applicationmapper.engine

import com.user404.applicationmapper.model.MappingRecord

/**
 * Canonical identity for application resources.
 * 
 * Identity is based on:
 * - Normalized host
 * - Normalized URL (path + query parameters sorted)
 * - HTTP method
 * - Resource type
 * 
 * This ensures GET /api/users and POST /api/users are different canonical records,
 * but the same endpoint discovered via Proxy, Site Map, Scanner, etc. correlate to one record.
 */
class CanonicalIdentity {

    companion object {
        /**
         * Generate a canonical identity key for a mapping record.
         * This key is used for deduplication and correlation.
         */
        fun generate(record: MappingRecord): String {
            val normalizedUrl = normalizeUrl(record.url)
            val normalizedMethod = record.method?.uppercase() ?: "UNKNOWN"
            val normalizedResourceType = record.resourceType.lowercase()
            
            return "${record.host}|$normalizedMethod|$normalizedUrl|$normalizedResourceType"
        }

        /**
         * Generate canonical identity from raw components.
         */
        fun generate(
            host: String,
            url: String,
            method: String?,
            resourceType: String
        ): String {
            val normalizedUrl = normalizeUrl(url)
            val normalizedMethod = method?.uppercase() ?: "UNKNOWN"
            val normalizedResourceType = resourceType.lowercase()
            
            return "$host|$normalizedMethod|$normalizedUrl|$normalizedResourceType"
        }

        /**
         * Normalize a URL for identity purposes.
         * - Removes fragment
        . - Sorts query parameters
        . - Normalizes path (removes duplicate slashes, resolves . and ..)
         */
        private fun normalizeUrl(url: String): String {
            return try {
                val uri = java.net.URI(url)
                val scheme = uri.scheme?.lowercase() ?: "http"
                val host = uri.host?.lowercase() ?: ""
                val port = when {
                    uri.port > 0 -> uri.port
                    scheme == "https" || scheme == "wss" -> 443
                    else -> 80
                }
                val path = normalizePath(uri.path ?: "/")
                val query = normalizeQuery(uri.query)
                
                val portSuffix = when {
                    (scheme == "http" && port == 80) || (scheme == "https" && port == 443) -> ""
                    else -> ":$port"
                }
                
                "$scheme://$host$portSuffix$path${if (query.isNotEmpty()) "?$query" else ""}"
            } catch (e: Exception) {
                // Fallback: basic normalization
                url.lowercase().let { u ->
                    val withoutFragment = u.substringBefore('#')
                    val (path, query) = withoutFragment.split("?", limit = 2)
                    val normalizedPath = normalizePath(path)
                    val normalizedQuery = if (query.isNotEmpty()) normalizeQuery(query) else ""
                    "$normalizedPath${if (normalizedQuery.isNotEmpty()) "?$normalizedQuery" else ""}"
                }
            }
        }

        private fun normalizePath(path: String): String {
            if (path.isEmpty()) return "/"
            val parts = mutableListOf<String>()
            for (part in path.split("/")) {
                when (part) {
                    "", "." -> {}
                    ".." -> { if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex) }
                    else -> parts.add(part)
                }
            }
            return "/" + parts.joinToString("/")
        }

        private fun normalizeQuery(query: String?): String {
            if (query == null || query.isBlank()) return ""
            val params = mutableListOf<Pair<String, String>>()
            for (pair in query.split("&")) {
                val (key, value) = pair.split("=", limit = 2).let { (it.firstOrNull() ?: "", it.getOrElse(1) { "" }) }
                params.add(key to value)
            }
            params.sortBy { it.first }
            return params.map { "${it.first}=${it.second}" }.joinToString("&")
        }
    }
}

/**
 * Canonical identity with additional dimensions for specialized resources.
 */
sealed class ResourceIdentity {
    data class Http(
        val host: String,
        val normalizedUrl: String,
        val method: String,
        val resourceType: String
    ) : ResourceIdentity() {
        override fun toString(): String = "$host|$method|$normalizedUrl|$resourceType"
    }

    data class WebSocket(
        val host: String,
        val normalizedUrl: String,
        val protocol: String?
    ) : ResourceIdentity() {
        override fun toString(): String = "$host|WS|$normalizedUrl|${protocol ?: "unknown"}"
    }

    data class ApiEndpoint(
        val host: String,
        val path: String,
        val method: String,
        val apiType: String
    ) : ResourceIdentity() {
        override fun toString(): String = "$host|$method|$path|api:$apiType"
    }

    data class Form(
        val host: String,
        val actionUrl: String,
        val method: String
    ) : ResourceIdentity() {
        override fun toString(): String = "$host|FORM:$method|$actionUrl|form"
    }

    data class Finding(
        val host: String,
        val baseUrl: String,
        val findingName: String
    ) : ResourceIdentity() {
        override fun toString(): String = "$host|FINDING|$baseUrl|$findingName"
    }
}