plugins {
    kotlin("jvm") version "2.0.0" apply false
}

group = "com.user404.applicationmapper"
version = "1.0.0"

repositories {
    mavenCentral()
    mavenLocal()
    gradlePluginPortal()
}